import 'package:client_1/model/cart_model/cart_model.dart';
import 'package:hive_flutter/hive_flutter.dart';

late Box<CartModel> _box;

class CartHive {
  static String key = "cart_hive";

  Future<void> _openBox() async {
    if (!Hive.isBoxOpen(key)) {
      await Hive.openBox<CartModel>(key);
    }
    _box = Hive.box(key);
  }

  Future<void> deleteAll() async {
    await _openBox();
    await _box.clear();
  }

  Future<void> addData(List<CartModel> model) async {
    await _openBox();
    await Future.forEach(model, (e) async {
      await _box.put(e.unit_id, e);
    });
  }

  Future<void> delete(CartModel model) async {
    await _openBox();
    await _box.delete(model.unit_id);
  }

  Future<List<CartModel>> getdata() async {
    await _openBox();

    List<CartModel> like = [];
    for (var i = 0; i < _box.length; i++) {
      var res = _box.getAt(i);
      if (res != null) like.add(res);
    }
    return like;
  }
}
