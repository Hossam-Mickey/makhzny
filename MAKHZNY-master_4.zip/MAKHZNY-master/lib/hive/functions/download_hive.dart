import 'package:hive_flutter/hive_flutter.dart';
import 'package:localstore/localstore.dart';
import 'package:synchronized/synchronized.dart';

import '../../model/download_model/download_model.dart';

final _lock = Lock();

late Box<DownloadModel> _box;

class DownloadHive {
  final db = Localstore.instance.collection("downloads");

  static String key = "download_hive";

  Future<void> _openBox() async {
    await _lock.synchronized(() async {
      // if (!Hive.isBoxOpen(key)) {
      //   await Hive.openBox<DownloadModel>(key);
      // }
      // _box = Hive.box(key);
    });
  }

  Future<void> deleteAll() async {
    await _lock.synchronized(() async {
      await _openBox();
      await _box.clear();
    });
  }

  Future<void> addData(List<DownloadModel> model) async {
    _lock.synchronized(() async {
      // await _openBox();
      await Future.forEach(model, (e) async {
        await db.doc(e.id).set(e.toJson());
        // _box.put(e.id, e);
      });
    });
  }

  Future<void> delete(DownloadModel model) async {
    await _lock.synchronized(() async {
      // await _openBox();
      // await _box.delete(model.id);
      await db.doc(model.id).delete();
    });
  }

  Future<List<DownloadModel>> getdata() async {
    await _openBox();
    List<DownloadModel> like = [];
    var data = await db.get();
    if (data == null) return [];
    var finalData = List<Map<String, dynamic>>.from(data.values.toList());
    for (var i = 0; i < finalData.length; i++) {
      like.add(DownloadModel.fromJson(finalData[i]));
    }
    // for (var i = 0; i < _box.length; i++) {
    //   var res = _box.getAt(i);
    //   if (res != null) like.add(res);
    // }
    return like;
  }
}
