import 'package:client_1/model/cart_model/cart_model.dart';
import 'package:client_1/model/download_model/download_model.dart';
import 'package:hive_flutter/adapters.dart';

Future<void> mainHive() async {
  await Hive.initFlutter();
  Hive
    ..registerAdapter(CartModelAdapter())
    ..registerAdapter(DownloadModelAdapter())
    ..registerAdapter(DownloadStatusAdapter());
}
// next 6
