import 'package:client_1/constants/string.dart';
import 'package:client_1/provider/splash_init_pro.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../constants/colors.dart';
import '../../constants/image.dart';
import '../../provider/lang_pro/lang_pro.dart';
import '../../widgets/app_image.dart';

class SplashScreen extends StatefulWidget {
  final String? path;
  const SplashScreen({super.key, this.path});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    init();
    super.initState();
  }

  Future<void> init() async {
    context.read<SplashInitPro>().init();
    await Future.delayed(2.seconds);
    if (!mounted) return;
    var path = widget.path;
    if (path == "/") path = null;
    context.pushReplacement(path ?? "/home");
    context.go(path ?? "/home");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Center(
              child: Transform.translate(
                offset: const Offset(-12, 0),
                child: AppImage(
                  height: MediaQuery.of(context).size.height / 2,
                  width: MediaQuery.of(context).size.width / 2,
                  image: MyImage.logo,
                ),
              ),
            ),
            Consumer<LangPro>(builder: (_, v, w) {
              return Align(
                alignment: Alignment.bottomCenter,
                child: AppText(
                  "${v.lang.version} ${MyString.version}",
                  fontSize: 13,
                  padding: const EdgeInsets.all(12),
                  color: MyColor.grey,
                ),
              );
            })
          ],
        ),
      ),
    );
  }
}
