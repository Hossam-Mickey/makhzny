import 'package:client_1/constants/colors.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/constants/string.dart';
import 'package:client_1/main.dart';
import 'package:client_1/provider/home_elevation_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/screen/home_screen/widgets/chat_button.dart';
import 'package:client_1/screen/home_screen/widgets/home_web_top.dart';
import 'package:client_1/screen/home_screen/widgets/web_drawer.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/rtl_layout.dart';
import 'package:floating_draggable_widget/floating_draggable_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:universal_platform/universal_platform.dart';

import 'widgets/bottom_nav.dart';
import 'widgets/home_child.dart';

final controller = ScrollController();
GlobalKey<ScaffoldState> home_scaffold_key = GlobalKey<ScaffoldState>();

class HomeScreen extends StatefulWidget {
  final Widget? child;
  const HomeScreen(this.child, {super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    home_scaffold_key = GlobalKey<ScaffoldState>();
    setState(() {});
  }

  bool showElevation = false;
  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.sizeOf(context);
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        systemNavigationBarColor: Theme.of(context).scaffoldBackgroundColor,
      ),
      child: FloatingDraggableWidget(
        floatingWidget: const ChatButton(),
        screenHeight: MediaQuery.sizeOf(context).height,
        screenWidth: MediaQuery.sizeOf(context).width,
        floatingWidgetHeight: 50,
        floatingWidgetWidth: 50,
        mainScreenWidget: RTLLayout(
          child: NotificationListener<ScrollNotification>(
            onNotification: (v) {
              var direction = v.metrics.axisDirection;
              bool axis1 = direction == AxisDirection.down;
              bool axis2 = direction == AxisDirection.up;
              if (!UniversalPlatform.isWeb) return false;
              if (axis1 || axis2) {
                if (v.metrics.pixels > 100.h) {
                  context.read<HomeElevationPro>().set(true);
                } else {
                  context.read<HomeElevationPro>().set(false);
                }
              }
              return true;
            },
            child: Scaffold(
              key: home_scaffold_key,
              endDrawer: UniversalPlatform.isWeb ? const WebDrawer() : null,
              appBar: !UniversalPlatform.isWeb
                  ? null
                  : PreferredSize(
                      preferredSize: Size(double.infinity, 100.h),
                      child: Consumer<HomeElevationPro>(
                        builder: (_, v, w) {
                          return const HomeWebTop()
                              .animate(target: v.show ? 1 : 0)
                              .elevation();
                        },
                      ),
                    ),
              bottomNavigationBar: UniversalPlatform.isWeb
                  ? null
                  : media.width > MyString.webWidth
                      ? const SizedBox()
                      : const BottomNav(),
              body: SafeArea(
                // child: MainViewScreen(),
                child: Row(
                  children: [
                    if (media.width > MyString.webWidth &&
                        !UniversalPlatform.isWeb)
                      const BottomNav(),
                    Expanded(child: widget.child ?? const HomeChild()),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MainViewScreen extends StatefulWidget {
  const MainViewScreen({
    super.key,
  });

  @override
  State<MainViewScreen> createState() => _MainViewScreenState();
}

class _MainViewScreenState extends State<MainViewScreen> {
  double pos = 0;
  @override
  void initState() {
    controller.addListener(() {
      pos = controller.offset;
      setState(() {});
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    var media = MediaQuery.sizeOf(context);
    return Scaffold(
      body: SingleChildScrollView(
        controller: controller,
        child: Column(
          children: [
            sizedBoxH20,
            SizedBox(
              width: double.infinity,
              child: Wrap(
                alignment: WrapAlignment.spaceAround,
                runAlignment: WrapAlignment.center,
                spacing: 20,
                runSpacing: 20,
                children: [
                  Transform.translate(
                    offset: Offset(0, -pos),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: media.width < 850 ? media.width : 200.w,
                          child: AppText(
                            "Store with us\n",
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            text2: "${lang.first_since}\n",
                            text3:
                                "time to get organized we have a place for everything",
                            maxLines: 10,
                            maxLines2: 10,
                            fontWeight: FontWeight.w500,
                            fontWeight2: FontWeight.w900,
                            fontWeight3: FontWeight.w500,
                            fontSize: 18.spMin,
                            fontSize2: 20.spMin,
                            fontSize3: 18.spMin,
                            color: MyColor.btnColor,
                            color2: MyColor.primary,
                          ),
                        ),
                        sizedBoxH20,
                        AppButton(
                          width: 210.wMin,
                          fontWeight: FontWeight.bold,
                          fontSize: 16.spMin,
                          margin: const EdgeInsets.symmetric(horizontal: 20),
                          buttonColor: Theme.of(context).primaryColor,
                          borderRadius: BorderRadius.circular(20),
                          text: "Request a quote",
                          onPressed: () {},
                        )
                      ],
                    ),
                  ),
                  Transform.translate(
                    offset: Offset(0, -pos),
                    child: Container(
                      constraints: BoxConstraints(
                        maxWidth: media.width < 850 ? media.width : 400,
                        maxHeight: 300,
                      ),
                      color: Colors.red,
                    ),
                  ),
                ],
              ),
            ),
            sizedBoxH40,
            Container(
              constraints: BoxConstraints(
                maxWidth: media.width < 850 ? media.width : 400,
                maxHeight: 300,
              ),
              color: Colors.black,
            ),
            sizedBoxH40,
            Container(
              constraints: BoxConstraints(
                maxWidth: media.width < 850 ? media.width : 400,
                maxHeight: 300,
              ),
              color: Colors.black,
            ),
            sizedBoxH40,
            Container(
              constraints: BoxConstraints(
                maxWidth: media.width < 850 ? media.width : 400,
                maxHeight: 300,
              ),
              color: Colors.black,
            ),
          ],
        ),
      ),
    );
  }
}
