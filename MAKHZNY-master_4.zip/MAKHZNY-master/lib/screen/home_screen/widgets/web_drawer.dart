import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/main.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/screen/home_screen/widgets/web_top_button.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class WebDrawer extends StatelessWidget {
  const WebDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return Drawer(
      child: SingleChildScrollView(
        child: Column(
          children: [
            sizedBoxH20,
            WebHomeTopButtn(
              pop: true,
              name: lang.home.firstLetterCap(),
              path: "/home",
            ),
            sizedBoxH20,
            WebHomeTopButtn(
              pop: true,
              name: lang.rent_now.firstLetterCap(),
              path: "/store",
            ),
            sizedBoxH20,
            WebHomeTopButtn(
              pop: true,
              name: lang.my_storage.firstLetterCap(),
              path: "/storage",
            ),
            sizedBoxH20,
            WebHomeTopButtn(
              pop: true,
              name: lang.settings.firstLetterCap(),
              path: "/settings",
            ),
            sizedBoxH20,
            WebHomeTopButtn(
              pop: true,
              name: lang.request_quote.firstLetterCap(),
              path: "/quote",
            ),
            sizedBoxH20,
          ],
        ),
      ),
    );
  }
}
