import 'package:client_1/screen/home_screen/widgets/product_card_shimner.dart';
import 'package:flutter/material.dart';

class HomeProductLoader extends StatelessWidget {
  const HomeProductLoader({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 250,
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        itemCount: 10,
        shrinkWrap: true,
        scrollDirection: Axis.horizontal,
        itemBuilder: (_, i) => const ProductCardShimner(),
      ),
    );
  }
}
