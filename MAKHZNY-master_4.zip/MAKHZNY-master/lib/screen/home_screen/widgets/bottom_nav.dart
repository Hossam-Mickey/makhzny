import 'package:client_1/constants/image.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/constants/string.dart';
import 'package:client_1/main.dart';
import 'package:client_1/model/lang_model/lang_model.dart';
import 'package:client_1/provider/current_route_pro/current_route_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

bool _expand = false;

enum Location {
  expand(0),
  storage(1),
  store(2),
  home(3),
  // ignore: constant_identifier_names
  gate_access(4),
  settings(5);

  final int pos;

  const Location(this.pos);

  static Location fromIndex(int index) {
    for (Location loc in Location.values) {
      if (loc.index == index) {
        return loc;
      }
    }
    return Location.home;
  }

  static Location current(String l) {
    for (Location loc in Location.values) {
      if ("/${loc.name}" == l) {
        return loc;
      }
    }
    return Location.home;
  }
}

class BottomNav extends StatefulWidget {
  const BottomNav({
    super.key,
  });

  @override
  State<BottomNav> createState() => _BottomNavState();
}

class _BottomNavState extends State<BottomNav> {
  @override
  Widget build(BuildContext context) {
    var media = MediaQuery.sizeOf(context);

    return media.width > MyString.webWidth
        ? SingleChildScrollView(
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: media.height),
              child: IntrinsicHeight(
                child: Consumer2<CurrentRoutePro, LangPro>(
                  builder: (_, v, v2, w) {
                    var lang = v2.lang;
                    return NavigationRail(
                      extended: _expand,
                      selectedIconTheme: IconThemeData(
                        color: Theme.of(context).primaryColor,
                      ),
                      onDestinationSelected: (_) {
                        if (_ == 0) {
                          _expand = !_expand;
                          setState(() {});
                          return;
                        }
                        var loc = Location.fromIndex(_);
                        if (v.loc == "/${loc.name}") return;
                        context.go("/${loc.name}");
                      },
                      destinations: railItems(lang),
                      selectedIndex: Location.current(v.loc).pos,
                    );
                  },
                ),
              ),
            ),
          )
        : Container(
            height: 60,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Theme.of(context).scaffoldBackgroundColor,
              boxShadow: [
                BoxShadow(
                  color: (Theme.of(context).brightness == Brightness.dark
                          ? Colors.white
                          : Colors.black)
                      .withOpacity(0.1),
                  spreadRadius: 1,
                  blurRadius: 20,
                  blurStyle: BlurStyle.outer,
                )
              ],
            ),
            padding: const EdgeInsets.only(top: 5),
            child: Consumer<LangPro>(
              builder: (_, v, w) {
                var lang = v.lang;
                return Row(
                  children: [
                    sizedBoxW5,
                    bottomChild(MyImage.my_storage, lang.my_storage, "storage"),
                    bottomChild(MyImage.store, lang.store, "store"),
                    bottomChild(MyImage.home, lang.home, "home"),
                    bottomChild(
                        MyImage.gate_access, lang.gate_access, "gate_access"),
                    bottomChild(MyImage.settings, lang.settings, "settings"),
                    sizedBoxW5,
                  ],
                );
              },
            ),
          );
  }

  List<NavigationRailDestination> railItems(LangModel lang) {
    return [
      rialChild(
        Icon(
          _expand
              ? Icons.keyboard_arrow_left_rounded
              : Icons.keyboard_arrow_right_outlined,
        ),
        "",
        _expand ? "Shrink" : "Expand",
      ),
      rialChild(MyImage.my_storage, lang.my_storage),
      rialChild(MyImage.store, lang.store),
      rialChild(MyImage.home, lang.home),
      rialChild(MyImage.gate_access, lang.gate_access),
      rialChild(MyImage.settings, lang.settings),
    ];
  }

  NavigationRailDestination rialChild(dynamic icon, String name,
      [String? tooltip]) {
    return NavigationRailDestination(
      icon: Tooltip(
        excludeFromSemantics: true,
        message: tooltip ?? (_expand ? "" : name),
        textStyle: Theme.of(context).textTheme.bodySmall,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(6),
          color: Theme.of(context).brightness == Brightness.dark
              ? const Color.fromARGB(255, 50, 49, 49)
              : Colors.grey.shade100,
        ),
        child: icon is String ? AppImage(image: icon) : icon,
      ),
      label: AppText(
        name,
        fontSize: 10.spMin,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget bottomChild(
    String image,
    String text,
    String loc,
  ) {
    var context = messangerKey.currentContext!;
    return Expanded(
      child: Consumer<CurrentRoutePro>(
        builder: (_, v, w) {
          var color = v.loc == "/$loc"
              ? Theme.of(context).primaryColor
              : messangerKey.currentContext!.read<ThemePro>().grey;
          return InkWell(
            onTap: () {
              if (v.loc == "/$loc") return;
              _.go("/$loc");
            },
            child: Container(
              color: Colors.transparent,
              height: 50,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  AppImage(
                    image: image,
                    color: color,
                  ),
                  sizedBoxH5,
                  AppText(
                    text,
                    fontSize: 10.spMin,
                    color: color,
                    fontWeight: FontWeight.w600,
                  )
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
