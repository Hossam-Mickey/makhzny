import 'package:client_1/constants/image.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class HomeNoData extends StatelessWidget {
  const HomeNoData({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      height: 250,
      width: double.infinity,
      child: Column(
        children: [
          sizedBoxH20,
          AppImage(
            image: MyImage.no_storage_data,
            height: 180.spMin,
          ),
          sizedBoxH10,
          const Expanded(
            child: AppText(
              "Sorry, no data to display at the moment! 🌟",
              maxLines: 4,
              textAlign: TextAlign.center,
              fontWeight: FontWeight.w600,
            ),
          ),
          sizedBoxH20,
        ],
      ),
    );
  }
}
