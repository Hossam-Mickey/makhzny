import 'package:client_1/constants/colors.dart';
import 'package:client_1/provider/user_pro/user_pro.dart';
import 'package:client_1/route.dart';
import 'package:client_1/widgets/mouse_cursor.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:universal_platform/universal_platform.dart';

class ChatButton extends StatelessWidget {
  const ChatButton({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return !UniversalPlatform.isWeb
        ? const SizedBox()
        : Tooltip(
            message: "Chat with agent",
            child: GestureDetector(
              onTap: () {
                context.read<UserPro>();
                // if (!user.isLogin) return user.notLoginDialog();
                var loc = GoRouter.of(context).location();
                context.go("$loc/message");
              },
              child: CusMouseCursor(
                child: CircleAvatar(
                  radius: 30.r,
                  backgroundColor: MyColor.primary.withOpacity(0.7),
                  child: SvgPicture.string(
                    """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M2 8.99374C2 5.68349 4.67654 3 8.00066 3H15.9993C19.3134 3 22 5.69478 22 8.99374V21H8.00066C4.68659 21 2 18.3052 2 15.0063V8.99374ZM20 19V8.99374C20 6.79539 18.2049 5 15.9993 5H8.00066C5.78458 5 4 6.78458 4 8.99374V15.0063C4 17.2046 5.79512 19 8.00066 19H20ZM14 11H16V13H14V11ZM8 11H10V13H8V11Z"></path></svg>""",
                    // ignore: deprecated_member_use
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          );
  }
}
