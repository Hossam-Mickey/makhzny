import 'package:client_1/get_it.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/my_units_pro/my_units_pro.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../functions/connectivity_check.dart';
import 'home_error_screen.dart';
import 'home_loader.dart';
import 'home_no_data.dart';
import 'product_card.dart';

class HomeLastBooked extends StatelessWidget {
  const HomeLastBooked({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    return Consumer<MyUnitsPro>(
      child: const HomeProductLoader(),
      builder: (_, v, w) {
        // if (!context.read<UserPro>().isLogin) {
        //   return const SizedBox(
        //     height: 400,
        //     child: NoLoginScreen(),
        //   );
        // }

        if (v.non_filter_units.isEmpty &&
            v.loading == false &&
            v.hasError == false) return const SizedBox();

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: AppText(
                lang.last_booked,
                fontWeight: FontWeight.w600,
                fontSize: 16,
              ),
            ),
            Builder(
              builder: (_) {
                if (v.loading) return w!;
                if (v.hasError) {
                  return HomeErrorScreen(
                    sub: v.errorMes,
                    onTap: () async {
                      var connectCheck = getIt<ConnectivityCheck>();
                      var network = await connectCheck.getCurrentState();
                      if (!network) return;
                      v.getUnits();
                    },
                  );
                }
                if (v.non_filter_units.isEmpty) {
                  return const HomeNoData();
                } else {
                  return SizedBox(
                    height: 250,
                    child: ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      itemCount: v.non_filter_units.length,
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (_, i) {
                        var model = v.non_filter_units[i];
                        return ProductCard(model: model,rented:true);
                      },
                    ),
                  );
                }
              },
            )
          ],
        );
      },
    );
  }
}
