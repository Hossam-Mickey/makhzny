import 'package:client_1/constants/image.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/main.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/screen/home_screen/home_screen.dart';
import 'package:client_1/screen/home_screen/widgets/web_top_button.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class HomeWebTop extends StatelessWidget {
  const HomeWebTop({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    var lang = context.watch<LangPro>().lang;
    var width = MediaQuery.sizeOf(context).width;
    return Container(
      color: Theme.of(context).scaffoldBackgroundColor,
      child: Row(
        children: [
          sizedBoxW10,
          Padding(
            padding: const EdgeInsets.all(10),
            child: AppImage(
              image: MyImage.logo_vert,
              height: 150,
              width: 150,
            ),
          ),
          if (width < 700)
            Expanded(
              child: Row(
                children: [
                  const Spacer(),
                  IconButton(
                    onPressed: () {
                      home_scaffold_key.currentState?.openEndDrawer();
                    },
                    icon: const Icon(Icons.menu),
                  ),
                ],
              ),
            )
          else
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  WebHomeTopButtn(
                    name: lang.home.firstLetterCap(),
                    path: "/home",
                  ),
                  WebHomeTopButtn(
                    name: lang.rent_now.firstLetterCap(),
                    path: "/store",
                  ),
                  WebHomeTopButtn(
                    name: lang.my_storage.firstLetterCap(),
                    path: "/storage",
                  ),
                  WebHomeTopButtn(
                    name: lang.settings.firstLetterCap(),
                    path: "/settings",
                  ),
                  WebHomeTopButtn(
                    name: lang.request_quote.firstLetterCap(),
                    path: "/quote",
                  ),
                ],
              ),
            ),
          sizedBoxW10,
        ],
      ),
    );
  }
}
