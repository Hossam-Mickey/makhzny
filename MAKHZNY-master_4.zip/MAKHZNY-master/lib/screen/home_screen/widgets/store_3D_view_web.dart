import 'package:client_1/widgets/cus_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

final keepAlive = InAppWebViewKeepAlive();

class Store3DViewWebView extends StatelessWidget {
  const Store3DViewWebView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            const CusAppbar(title: ""),
            Expanded(
              child: InAppWebView(
                keepAlive: keepAlive,
                initialUrlRequest: URLRequest(
                  url: WebUri("https://my.matterport.com/show/?m=p6WpreqSkWH"),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
