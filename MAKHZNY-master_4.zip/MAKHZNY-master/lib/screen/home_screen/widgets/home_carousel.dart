import 'package:carousel_slider/carousel_slider.dart';
import 'package:client_1/functions/connectivity_check.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/provider/carousel_pro/carousel_pro.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/screen/home_screen/widgets/home_error_screen.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/container_shimner.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class HomeCarousel extends StatelessWidget {
  const HomeCarousel({super.key});

  @override
  Widget build(BuildContext context) {
    var grey = context.read<ThemePro>().grey;

    return Consumer<CarouselPro>(
      builder: (_, v, w) {
        if (v.hasError) {
          return AspectRatio(
            aspectRatio: 24 / 10,
            child: HomeErrorScreen(
              sub: v.errorMes,
              onTap: () async {
                var connectCheck = getIt<ConnectivityCheck>();
                var network = await connectCheck.getCurrentState();
                if (!network) return;
                v.getCarousel();
              },
            ),
          );
        } else {
          // return Padding(
          //   padding: const EdgeInsets.symmetric(horizontal: 20),
          //   child: AspectRatio(
          //     aspectRatio: 24 / 10,
          //     child: CarouselView(
          //       itemSnapping: true,
          //       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
          //       // padding: EdgeInsets.all(10),
          //       itemExtent: MediaQuery.sizeOf(context).width - 90,
          //       children: List.generate(
          //         v.carousel.length,
          //         (i) {
          //           return AppImage(
          //             width: double.infinity,
          //             image: v.carousel[i],
          //             fit: BoxFit.fill,
          //           );
          //         },
          //       ),
          //     ),
          //   ),
          // );
          return CarouselSlider.builder(
            itemCount: v.loading ? 3 : v.carousel.length,
            itemBuilder: (_, i, i2) {
              return v.loading
                  ? ContainerShimner(
                      width: double.infinity,
                      height: double.infinity,
                      borderRadius: BorderRadius.circular(6),
                    )
                  : ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: Container(
                        color: grey,
                        child: AppImage(
                          width: double.infinity,
                          // image: v.carousel[i].urlWithBase,
                          image: v.carousel[i],
                          fit: BoxFit.cover,
                        ),
                      ),
                    );
            },
            options: CarouselOptions(
              autoPlay: true,
              aspectRatio: 24 / 10,
              enlargeCenterPage: true,
              viewportFraction: 0.7,
              onPageChanged: (i, r) {},
              // aspectRatio: 2.0,
            ),
          );
        }
      },
    );
  }
}
