import 'package:client_1/constants/image.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:universal_platform/universal_platform.dart';

import '../../../constants/colors.dart';

class HomeTop extends StatelessWidget {
  const HomeTop({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: UniversalPlatform.isWeb
          ? const SizedBox()
          : Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20).copyWith(top: 10),
              child: Row(
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      AppImage(
                        image: MyImage.welcome_frnd_bg,
                        height: 45,
                        width: 45,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.grey.shade800
                            : null,
                      ),
                      AppImage(
                        image: MyImage.welcome_frnd,
                        height: 45,
                        width: 45,
                      ),
                    ],
                  ),
                  sizedBoxW10,
                  Expanded(
                    child: Consumer<LangPro>(
                      builder: (_, v, w) {
                        var lang = v.lang;
                        return Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            AppText(
                              lang.welcome_frnd,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              maxLines: 2,
                            ),
                            AppText(
                              lang.it_is_time_to_get_origanized,
                              color: MyColor.primary,
                              maxLines: 2,
                              fontSize: 11,
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}


