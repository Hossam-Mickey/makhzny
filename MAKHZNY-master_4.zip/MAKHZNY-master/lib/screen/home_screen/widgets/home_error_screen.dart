import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

class HomeErrorScreen extends StatelessWidget {
  final Function onTap;
  final String? sub;
  const HomeErrorScreen({
    super.key,
    required this.onTap,
    this.sub,
  });

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    return Container(
      height: 250,
      alignment: Alignment.center,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (sub != null && sub!.isNotEmpty)
            AppText(
              sub!,
              fontWeight: FontWeight.bold,
              fontSize: 16.spMin,
              maxLines: 3,
            ),
          AppText(
            lang.something_went_wrong,
            fontWeight: FontWeight.w500,
          ),
          sizedBoxH10,
          AppButton(
            height: 50.h > 50 ? 50 : 50.h,
            width: 100.w > 100 ? 100 : 100.w,
            borderRadius: BorderRadius.circular(8),
            text: lang.retry,
            onPressed: () => onTap(),
          ),
        ],
      ),
    );
  }
}
