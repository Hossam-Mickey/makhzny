import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/widgets/container_shimner.dart';
import 'package:client_1/widgets/cus_elevation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../provider/theme_pro/theme_pro.dart';

class ProductCardShimner extends StatelessWidget {
  const ProductCardShimner({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return CustomElevation(
      shape: BoxShape.rectangle,
      color: Colors.grey.shade600,
      spread: -35,
      blur: 30,
      offset: const Offset(0, 15),
      child: Container(
        width: 170,
        margin: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: context.read<ThemePro>().cardColor,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ContainerShimner(
              height: 90,
              width: double.infinity,
              margin: const EdgeInsets.all(10),
              borderRadius: BorderRadius.circular(8),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        flex: 4,
                        child: ContainerShimner(),
                      ),
                      sizedBoxW10,
                      Expanded(child: ContainerShimner())
                    ],
                  ),
                  sizedBoxH5,
                  ContainerShimner(margin: EdgeInsets.only(right: 50.w)),
                  sizedBoxH10,
                ],
              ),
            ),
            const Spacer(),
            const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                sizedBoxW10,
                Expanded(
                  flex: 4,
                  child: ContainerShimner(),
                ),
                sizedBoxW5,
                Expanded(child: SizedBox()),
              ],
            ),
            const Spacer(),
            const ContainerShimner(
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(10),
                bottomRight: Radius.circular(10),
              ),
              height: 30,
              width: double.infinity,
            )
          ],
        ),
      ),
    );
  }
}
