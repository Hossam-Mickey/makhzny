import 'package:client_1/constants/colors.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/carousel_pro/carousel_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/my_units_pro/my_units_pro.dart';
import 'package:client_1/provider/riyadh_units_pro/riyadh_units_pro.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:universal_platform/universal_platform.dart';

import 'home_card_info.dart';
import 'home_carousel.dart';
import 'home_category.dart';
import 'home_last_booked.dart';
import 'home_top.dart';
import 'store_3D_view.dart';

class HomeChild extends StatelessWidget {
  const HomeChild({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    return RefreshIndicator(
      backgroundColor: MyColor.refreshColor,
      onRefresh: () {
        return Future.wait([
          context.read<RiyadhUnitsPro>().getProduct(),
          // context.read<NewUnitsPro>().getProduct(),
          context.read<MyUnitsPro>().getUnits(),
          context.read<CarouselPro>().getCarousel(),
        ]);
      },
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const HomeTop(),
            sizedBoxH20,
            const HomeCarousel(),
            sizedBoxH20,
            const HomeCardInfo(),
            sizedBoxH20,
            if (UniversalPlatform.isAndroid || UniversalPlatform.isIOS) ...[
              const Store3DView(),
              sizedBoxH20,
            ],

            Consumer<RiyadhUnitsPro>(
              builder: (_, v, w) {
                var non_filter_product = v.non_filter_product;
                non_filter_product.sort((a, b) => a.price.compareTo(b.price));
                return HomeCategory(
                  title: lang.trending_now,
                  loading: v.loading,
                  hasError: v.hasError,
                  product: non_filter_product,
                  onError: () => v.getProduct(),
                );
              },
            ),
            sizedBoxH20,
            // Consumer<NewUnitsPro>(
            //   builder: (_, v, w) {
            //     return HomeCategory(
            //       title: lang.new_units,
            //       loading: v.loading,
            //       hasError: v.hasError,
            //       product: v.non_filter_product,
            //       onError: () => v.getProduct(),
            //     );
            //   },
            // ),
            // sizedBoxH20,
            const HomeLastBooked(),
            sizedBoxH20,
          ],
        ),
      ),
    );
  }
}
