import 'package:client_1/provider/carousel_pro/carousel_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

class HomeAdDialog extends StatelessWidget {
  const HomeAdDialog({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    return Dialog(
      child: Material(
        type: MaterialType.transparency,
        child: SizedBox(
          height: 300,
          width: double.infinity,
          child: Stack(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(10.r),
                child: AppImage(
                  width: double.infinity,
                  height: double.infinity,
                  image: context.read<CarouselPro>().carousel.last,
                  fit: BoxFit.fill,
                ),
              ),
              Align(
                alignment: Alignment.topRight,
                child: IconButton(
                  padding: const EdgeInsets.all(20),
                  onPressed: () => context.pop(),
                  icon: const Icon(
                    Icons.close_rounded,
                    color: Colors.black,
                  ),
                ),
              ),
              Align(
                alignment: Alignment.bottomRight,
                child: AppButton(
                  width: 120,
                  margin: const EdgeInsets.all(20),
                  buttonColor: const Color(0xfff99734).withOpacity(0.3),
                  border: Border.all(
                    color: const Color(0xfff99734),
                    width: 1.5,
                  ),
                  text: lang.rent_now,
                  height: 30,
                  fontColor: Colors.black,
                  fontSize: 12.spMin,
                  fontWeight: FontWeight.w600,
                  onPressed: () {
                    context.pop();
                    context.go("/store");
                  },
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Future<void> showCarouselAd() async {
  // var context = navigatorKey.currentContext!;
  // var lastShow = await Preference.getLastAdShown();
  // if (lastShow.difference(DateTime.now()).inHours.abs() < 6) return;
  // Preference.setLastAdShown(DateTime.now());
  // await Future.delayed(2.seconds);
  // showDialog(
  //   barrierDismissible: false,
  //   // ignore: use_build_context_synchronously
  //   context: context,
  //   builder: (_) => const HomeAdDialog(),
  // );
}
