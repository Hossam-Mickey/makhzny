import 'package:client_1/constants/api.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/functions/print_c.dart';
import 'package:client_1/functions/show_snakbar.dart';
import 'package:client_1/model/product_model/product_model.dart';
import 'package:client_1/provider/add_cart_pro/add_cart_pro.dart';
import 'package:client_1/provider/company_pro/company_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/provider/user_pro/user_pro.dart';
import 'package:client_1/route.dart';
import 'package:client_1/screen/add_cart_dialog/add_cart_dialog.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../constants/colors.dart';
import '../../../widgets/cus_elevation.dart';

class ProductCard extends StatelessWidget {
  final ProductModel? model;
  final bool rented;
  const ProductCard({super.key, this.rented = false, this.model});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    var grey = context.read<ThemePro>().grey;

    String area() {
      var af = model?.area ?? 12;
      double fp = af - af.floor();
      if (fp == 0) return af.floor().toString();
      return af.toString();
    }

    return CustomElevation(
      shape: BoxShape.rectangle,
      color: Colors.grey.shade600,
      spread: -35,
      blur: 30,
      offset: const Offset(0, 15),
      child: Container(
        width: 170,
        // height: 230,
        margin: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: context.read<ThemePro>().cardColor,
          // boxShadow: [
          // BoxShadow(
          //   color: Colors.grey.shade900.withOpacity(0.1),
          boxShadow: const [
            // BoxShadow(
            //   color: Colors.red.withOpacity(0.5),
            //   // spreadRadius: -5,
            //   blurRadius: 10,
            //   // offset: Offset(0, -20),
            //   blurStyle: BlurStyle.outer,
            // )
          ],
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 90,
              margin: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: grey.withOpacity(0.5),
                borderRadius: BorderRadius.circular(8),
              ),
              child: model != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: AppImage(
                        image: API.baseUrl + model!.image,
                        fit: BoxFit.cover,
                        height: double.infinity,
                        width: double.infinity,
                      ),
                    )
                  : null,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                // mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: AppText(
                          model?.title ?? "Small A-18",
                          fontSize: 14.spMin,
                          fontWeight: FontWeight.w600,
                          maxLines: 2,
                        ),
                      ),
                      AppText(
                        "${area()} M²",
                        fontSize: 14.spMin,
                        fontWeight: FontWeight.w500,
                      ),
                    ],
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(
                        Icons.location_pin,
                        color: MyColor.grey,
                        size: 14,
                      ),
                      sizedBoxW5,
                      Expanded(
                        child: Transform.translate(
                          offset: const Offset(0, -2),
                          child: AppText(
                            context
                                .read<CompanyPro>()
                                .loc(model?.company_id ?? 2),
                            fontSize: 12.spMin,
                            fontWeight: FontWeight.w400,
                            color: MyColor.grey,
                          ),
                        ),
                      ),
                    ],
                  ),
                  sizedBoxH10,
                ],
              ),
            ),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                children: [
                  Expanded(
                    child: Builder(
                      builder: (context) {
                        var vat = model!.price * model!.vat;
                        var total = model!.price + vat;
                        return AppText(
                          "${total.roundToNearestTen()} SAR\n",
                          text2: "Monthly",
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          maxLines: 3,
                          height: 0.9,
                          fontSize2: 12.spMin,
                          fontWeight2: FontWeight.w500,
                          color: MyColor.primary,
                        );
                      },
                    ),
                  ),
                  // AppImage(
                  //   image: MyImage.download_icon,
                  //   color: Theme.of(context).primaryColor,
                  //   height: 16.spMin,
                  // )
                ],
              ),
            ),
            const Spacer(),
            AppButton(
              text: rented ? lang.booked : lang.add_to_cart,
              disabled: rented,
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(10),
                bottomRight: Radius.circular(10),
              ),
              onDisabled: () => MySnackBar.show(title: lang.booked_sub),
              onPressed: () {
                context.read<AddCartPro>().clear();
                var userPro = context.read<UserPro>();
                if (!userPro.isLogin) return userPro.notLoginDialog();
                showModalBottomSheet(
                  context: navigatorKey.currentContext!,
                  useSafeArea: false,
                  isScrollControlled: true,
                  enableDrag: false,
                  isDismissible: false,
                  backgroundColor: Colors.transparent,
                  builder: (_) => AddCartDialog(
                    _,
                    model: model,
                    onAdd: () {
                      if (model == null) return;
                      printC(model!.vat);
                      context.read<AddCartPro>().add(model!);
                    },
                  ),
                );
              },
              height: 30,
              fontWeight: FontWeight.w600,
              fontSize: 10,
            )
          ],
        ),
      ),
    );
  }
}
