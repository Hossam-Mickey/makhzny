import 'package:client_1/constants/colors.dart';
import 'package:client_1/provider/current_route_pro/current_route_pro.dart';
import 'package:client_1/provider/home_elevation_pro.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

class WebHomeTopButtn extends StatelessWidget {
  final String name;
  final String path;
  final bool pop;
  const WebHomeTopButtn({
    super.key,
    this.pop = false,
    required this.name,
    required this.path,
  });

  @override
  Widget build(BuildContext context) {
    return Consumer<CurrentRoutePro>(
      builder: (_, v, w) {
        var isDark = Theme.of(_).brightness == Brightness.dark;
        var loc = v.loc;
        bool selected = loc == path;
        return AnimatedContainer(
          duration: 400.ms,
          decoration: selected
              ? BoxDecoration(
                  borderRadius: BorderRadius.circular(90),
                  color: isDark
                      ? MyColor.btnColor
                      : MyColor.btnColor.withOpacity(0.2),
                )
              : null,
          child: TextButton(
            onPressed: () {
              _.read<HomeElevationPro>().set(false);
              _.go(path);
              if (pop) _.pop();
            },
            child: AppText(
              name,
              fontWeight: selected ? FontWeight.w900 : FontWeight.w900,
              color: !selected
                  ? isDark
                      ? Colors.grey.withOpacity(0.5)
                      : MyColor.grey
                  : isDark
                      ? Colors.white
                      : MyColor.btnColor,
            ),
          ),
        );
      },
    );
  }
}
