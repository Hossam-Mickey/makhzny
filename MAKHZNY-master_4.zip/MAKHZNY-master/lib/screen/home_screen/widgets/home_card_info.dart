import 'package:client_1/constants/image.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

class HomeCardInfo extends StatelessWidget {
  const HomeCardInfo({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Container(
        width: double.infinity,
        // height: 100,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          gradient: LinearGradient(
            stops: const [0.1, 0.4, 0.8, 1],
            colors: [
              Theme.of(context).primaryColor,
              Theme.of(context).primaryColor,
              Theme.of(context).primaryColor.withOpacity(0.5),
              Theme.of(context).primaryColor.withOpacity(0.5),
            ],
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            sizedBoxW10,
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  sizedBoxH10,
                  AppText(
                    lang.we_have_place,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    maxLines: 4,
                  ),
                  sizedBoxH5,
                  AppText(
                    lang.first_since,
                    color: Colors.white,
                    fontWeight: FontWeight.w200,
                    fontSize: 10.spMin,
                    maxLines: 4,
                  ),
                  sizedBoxH20,
                  AppButton(
                    width: 120,
                    // buttonColor: const Color(0xfff99734).withOpacity(0.3),
                    // border: Border.all(
                    //   color: const Color(0xfff99734),
                    //   width: 1,
                    // ),
                    buttonColor: Colors.red,
                    text: lang.rent_now,
                    height: 30,
                    fontColor: Colors.white,
                    fontSize: 15.spMin,
                    fontWeight: FontWeight.w600,
                    onPressed: () => context.go("/store"),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  sizedBoxH10,
                ],
              ),
            ),
            sizedBoxW5,
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: AppImage(image: MyImage.rent_now),
            ),
            sizedBoxW10,
          ],
        ),
      ),
    );
  }
}
