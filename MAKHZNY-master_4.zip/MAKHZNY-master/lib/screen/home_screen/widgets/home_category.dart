import 'package:client_1/get_it.dart';
import 'package:client_1/model/product_model/product_model.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';

import '../../../functions/connectivity_check.dart';
import 'home_error_screen.dart';
import 'home_loader.dart';
import 'home_no_data.dart';
import 'product_card.dart';

class HomeCategory extends StatelessWidget {
  final String title;
  final bool loading;
  final bool hasError;
  final List<ProductModel> product;
  final Function() onError;

  const HomeCategory({
    super.key,
    required this.title,
    required this.loading,
    required this.hasError,
    required this.product,
    required this.onError,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: AppText(
            title,
            fontWeight: FontWeight.w600,
            fontSize: 16,
          ),
        ),
        Builder(
          builder: (_) {
            if (loading) return const HomeProductLoader();
            if (hasError) {
              return HomeErrorScreen(
                onTap: () async {
                  var connectCheck = getIt<ConnectivityCheck>();
                  var network = await connectCheck.getCurrentState();
                  if (!network) return;
                  onError();
                },
              );
            }
            if (product.isEmpty) {
              return const HomeNoData();
            } else {
              return SizedBox(
                height: 250,
                child: ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  itemCount: product.length,
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (_, i) {
                    var model = product[i];
                    return ProductCard(model: model);
                  },
                ),
              );
            }
          },
        ),
      ],
    );
  }
}
