import 'package:client_1/constants/colors.dart';
import 'package:client_1/constants/image.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/functions/blur_bottom_sheet.dart';
import 'package:client_1/main.dart';
import 'package:client_1/model/product_model/product_model.dart';
import 'package:client_1/provider/add_cart_pro/add_cart_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/mouse_cursor.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import 'widgets/add_cart_radio.dart';

class AddCartDialog extends StatelessWidget {
  final BuildContext dialogContext;
  final Function() onAdd;
  final ProductModel? model;
  final String? productId;
  const AddCartDialog(
    this.dialogContext, {
    super.key,
    required this.onAdd,
    this.model,
    this.productId,
  });

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return Stack(
      children: [
        const BlurDialogBg(),
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: 100.h,
            width: double.infinity,
            color: Theme.of(context).primaryColor,
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: SafeArea(
            minimum: const EdgeInsets.only(bottom: 20),
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Theme.of(context).scaffoldBackgroundColor,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 30),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          sizedBoxH20,
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(
                              padding: EdgeInsets.zero,
                              onPressed: () => Navigator.pop(dialogContext),
                              icon: Icon(
                                Icons.close,
                                color: Theme.of(context).primaryColor,
                              ),
                            ),
                          ),
                          // sizedBoxH50,
                          Center(
                            child: AppText(
                              lang.rental_option,
                              fontWeight: FontWeight.w600,
                              fontSize: 20.spMin,
                            ),
                          ),
                          sizedBoxH10H,
                          ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: AppText(
                              "- ${lang.invoice_period}",
                              fontWeight: FontWeight.w600,
                              fontSize: 16.spMin,
                            ),
                            subtitle: AppText(
                              lang.invoice_period_sub,
                              fontWeight: FontWeight.w400,
                              fontSize: 12.5.spMin,
                              color: MyColor.grey,
                            ),
                          ),
                          const AddCartRadio(),
                          sizedBoxH30H,
                          // ListTile(
                          //   contentPadding: EdgeInsets.zero,
                          //   title: AppText(
                          //     "- ${lang.quantity}",
                          //     fontWeight: FontWeight.w600,
                          //     fontSize: 16.spMin,
                          //   ),
                          //   subtitle: AppText(
                          //     lang.quantity_sub,
                          //     fontWeight: FontWeight.w400,
                          //     fontSize: 11.spMin,
                          //     color: MyColor.grey,
                          //   ),
                          // ),
                          // sizedBoxH10,
                          // Consumer<AddCartPro>(
                          //   builder: (_, v, w) {
                          //     return QuantityButtuon(
                          //       val: v.quantity.toString(),
                          //       onPlus: () {
                          //         var val = v.quantity + 1;
                          //         v.changeQuantity(val);
                          //       },
                          //       onMinuse: () {
                          //         var val = v.quantity - 1;
                          //         v.changeQuantity(val);
                          //       },
                          //     );
                          //   },
                          // ),

                          // sizedBoxH30H,
                          ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: AppText(
                              "- ${lang.rental_date}",
                              fontWeight: FontWeight.w600,
                              fontSize: 16.spMin,
                            ),
                            subtitle: AppText(
                              lang.rental_date_sub,
                              fontWeight: FontWeight.w400,
                              fontSize: 12.5.spMin,
                              color: MyColor.grey,
                              maxLines: 4,
                            ),
                          ),
                          sizedBoxH10,
                          Consumer<AddCartPro>(
                            builder: (_, v, w) {
                              var day = v.startDate.day.toString();
                              var month = v.startDate.month;
                              var year = v.startDate.year.toString();
                              return IgnorePointer(
                                ignoring: true,
                                child: Container(
                                  height: 40,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(22),
                                    color: Colors.transparent,
                                    border: Border.all(
                                      color: MyColor.grey,
                                      width: 1.5,
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      sizedBoxW20,
                                      AppText(
                                        day.padLeft(2, '0'),
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14.spMin,
                                      ),
                                      sizedBoxW10,
                                      const VerticalDivider(thickness: 3),
                                      sizedBoxW10,
                                      AppText(
                                        v.convertToMonth(month),
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14.spMin,
                                      ),
                                      sizedBoxW10,
                                      const VerticalDivider(thickness: 3),
                                      sizedBoxW10,
                                      AppText(
                                        year,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14.spMin,
                                      ),
                                      sizedBoxW20,
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                    // const Spacer(),
                    sizedBoxH30,
                    Container(
                      // height: 70.h,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                        ),
                        color: Theme.of(context).primaryColor,
                      ),
                      child: ListTile(
                        title: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            sizedBoxH5,
                            Consumer<AddCartPro>(
                              builder: (_, v, w) {
                                var res = amount(v);
                                var d =
                                    v.priceCalculator(model!.price) + res.vat;
                                return AppText(
                                  "${lang.total_amount} : ${d.roundToNearestTen()} SAR",
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12.spMin,
                                  color: Colors.white,
                                );
                              },
                            ),
                            // sizedBoxH5,
                            // Consumer<AddCartPro>(
                            //   builder: (_, v, w) {
                            //     var res = amount(v);
                            //     return AppText(
                            //       "${lang.vat} : ${res.vat} SAR  (${(model!.vat * 100).roundPoint()}%)",
                            //       fontWeight: FontWeight.w400,
                            //       fontSize: 12.spMin,
                            //       color: Colors.white,
                            //     );
                            //   },
                            // ),
                            sizedBoxH5,
                            Consumer<AddCartPro>(
                              builder: (_, v, w) {
                                var res = amount(v);
                                return AppText(
                                  "${lang.discount.capFirst()} : - ${res.dis} SAR",
                                  fontWeight: FontWeight.w400,
                                  fontSize: 12.spMin,
                                  color: Colors.white,
                                );
                              },
                            ),
                            sizedBoxH5,
                            AppText(
                              "${lang.payable_amount} :",
                              fontWeight: FontWeight.w400,
                              fontSize: 14.spMin,
                              color: Colors.white,
                            ),
                          ],
                        ),
                        subtitle: Consumer<AddCartPro>(
                          builder: (_, v, w) {
                            var res = amount(v);
                            return AppText(
                              "${res.payable} SAR",
                              fontWeight: FontWeight.w700,
                              fontSize: 14.spMin,
                              color: Colors.white,
                            );
                          },
                        ),
                        trailing: AppButton(
                          width: 120.w > 200 ? 200 : 120.w,
                          height: 40.h < 40 ? 40 : 40.h,
                          text: lang.checkout,
                          borderRadius: BorderRadius.circular(22),
                          fontColor: Theme.of(context).primaryColor,
                          buttonColor: Colors.white,
                          fontWeight: FontWeight.w500,
                          fontSize: 14.spMin,
                          onPressed: () => onAdd(),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  ({double vat, double dis, int payable}) amount(AddCartPro v) {
    double rentAmount = model!.price;
    double rentVAT = model!.vat;

    double d = (rentAmount * v.period.duration);

    double vat = d * rentVAT;

    double price = (rentAmount * v.period.duration) + vat;

    // 25% change to 0.25
    double dicRate = v.period.discount / 100;

    double dicMin = price * dicRate;

    double payableAmount = price - dicMin;
    return (
      dis: double.parse(dicMin.toStringAsFixed(2)),
      vat: vat,
      payable: payableAmount.roundToNearestTen(),
    );
  }

  Widget qtyBtn(String image, Function onTap) {
    var context = messangerKey.currentContext!;
    return MaterialButton(
      splashColor: Colors.transparent,
      minWidth: 20,
      onPressed: () => onTap(),
      child: AppImage(
        image: image,
        color: Theme.of(context).primaryColor,
      ),
    );
  }
}

class QuantityButtuon extends StatelessWidget {
  final String val;
  final Function onPlus;
  final Function onMinuse;
  final double? height;
  final double? width;
  final double? fontSize;

  const QuantityButtuon({
    super.key,
    required this.val,
    required this.onPlus,
    required this.onMinuse,
    this.height,
    this.width,
    this.fontSize,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height ?? 40,
      width: width ?? 150.w,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: MyColor.grey,
          width: 1.5,
        ),
      ),
      child: Row(
        children: [
          sizedBoxW5,
          qtyBtn(
            MyImage.minuse,
            () => onMinuse(),
          ),
          Expanded(
            child: AppText(
              val,
              color: MyColor.primary,
              fontWeight: FontWeight.w700,
              fontSize: fontSize ?? 18.spMin,
              textAlign: TextAlign.center,
            ),
          ),
          qtyBtn(
            MyImage.add,
            () => onPlus(),
          ),
          sizedBoxW5,
        ],
      ),
    );
  }

  Widget qtyBtn(String image, Function onTap) {
    var context = messangerKey.currentContext!;
    return CusMouseCursor(
      child: GestureDetector(
        onTap: () => onTap(),
        child: Container(
          color: Colors.transparent,
          height: (height ?? 40) - 2,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: AppImage(
            image: image,
            color: Theme.of(context).primaryColor,
          ),
        ),
      ),
    );
  }
}

extension StringCasingExtension on String {
  String capFirst() {
    if (isEmpty) {
      return this;
    }
    return this[0].toUpperCase() + substring(1);
  }
}

extension IntCasingExtension on double {
  int roundToNearestTen() {
    return (this / 10).round() * 10;
  }
}
