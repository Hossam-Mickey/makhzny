import 'package:client_1/main.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../constants/colors.dart';
import '../../../constants/sized_box.dart';
import '../../../provider/add_cart_pro/add_cart_pro.dart';
import '../../../provider/lang_pro/lang_pro.dart';
import '../../../widgets/app_text.dart';

class AddCartRadio extends StatelessWidget {
  const AddCartRadio({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return Consumer<AddCartPro>(
      builder: (_, v, w) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                radioBtn(
                  name: lang.montly,
                  value: InvoicePeriod.montly,
                  selected: v.period,
                  onChange: (ino) {
                    if (ino == null) return;
                    v.changePeriod(ino);
                  },
                ),
                radioBtn(
                  name: lang.semi_annual,
                  value: InvoicePeriod.semi_annual,
                  selected: v.period,
                  onChange: (ino) {
                    if (ino == null) return;
                    v.changePeriod(ino);
                  },
                ),
              ],
            ),
            sizedBoxH10,
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                radioBtn(
                  name: lang.quarterly,
                  value: InvoicePeriod.quaterly,
                  selected: v.period,
                  onChange: (ino) {
                    if (ino == null) return;
                    v.changePeriod(ino);
                  },
                ),
                radioBtn(
                  name: lang.annual,
                  value: InvoicePeriod.annual,
                  selected: v.period,
                  onChange: (ino) {
                    if (ino == null) return;
                    v.changePeriod(ino);
                  },
                ),
              ],
            ),
          ],
        );
      },
    );
  }

  Widget radioBtn({
    required String name,
    required InvoicePeriod value,
    required InvoicePeriod selected,
    required Function(InvoicePeriod?) onChange,
  }) {
    var bool = value == selected;
    var color = bool ? MyColor.primary : MyColor.grey;
    var context = messangerKey.currentContext!;
    var lang = context.read<LangPro>().lang;
    return Expanded(
      child: SizedBox(
        // width: (MediaQuery.of(navigatorKey.currentContext!).size.width / 2.5),
        child: GestureDetector(
          onTap: () => onChange(value),
          child: Container(
            color: Colors.transparent,
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    SizedBox(
                      height: 10,
                      width: 10,
                      child: Radio(
                        fillColor: WidgetStatePropertyAll(color),
                        value: value,
                        groupValue: selected,
                        onChanged: (_) => onChange(_),
                      ),
                    ),
                    sizedBoxW10,
                    Flexible(
                      child: AppText(
                        name,
                        color: color,
                        fontWeight: bool ? FontWeight.w700 : FontWeight.w400,
                      ),
                    )
                  ],
                ),
                if (value.discount > 0) sizedBoxH5,
                if (value.discount > 0)
                  AppText(
                    "${value.discount.roundPoint()}% ${lang.discount}",
                    color: color,
                    fontWeight: bool ? FontWeight.w700 : FontWeight.w400,
                    fontSize: 12.spMin,
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

extension DoubleExtension on double {
  String roundPoint() {
    var point = toString().split(".");
    if (int.parse(point.last) > 0) return toString();
    return point.first;
  }
}
