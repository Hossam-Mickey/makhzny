import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/account_create_pro/account_create_pro.dart';
import 'package:client_1/provider/login_pro/login_pro.dart';
import 'package:client_1/provider/user_pro/user_pro.dart';
import 'package:client_1/widgets/cus_tab.dart';
import 'package:client_1/widgets/loader.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../provider/lang_pro/lang_pro.dart';
import '../login_screen/widgets/login_top_text.dart';
import 'widgets/ac_business.dart';
import 'widgets/ac_create_btm_btn.dart';
import 'widgets/ac_personal.dart';

class AccountCreateScreen extends StatelessWidget {
  const AccountCreateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    // var accountPro = context.read<AccountCreatePro>();
    // var media = MediaQuery.of(context).size;
    return Scaffold(
      body: Consumer2<UserPro, LoginPro>(
        child: Scaffold(
          bottomNavigationBar: const AccountCreateBottomBtn(),
          body: SafeArea(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  sizedBoxH20,
                  const LoginTopText(),
                  sizedBoxH30,
                  Consumer<AccountCreatePro>(
                    builder: (_, v, w) {
                      return CusTab(
                        data: [
                          (lang.personal, 0),
                          (lang.business, 1),
                        ],
                        selected: v.selected,
                        onTap: (i) => v.changeSelected(i),
                      );
                    },
                  ),
                  sizedBoxH20,
                  Consumer<AccountCreatePro>(
                    builder: (_, v, w) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: v.selected == 0
                            ? const AccountPersonalScreen()
                            : const AccountBusinessScreen(),
                      );
                    },
                  )
                ],
              ),
            ),
          ),
        ),
        builder: (_, v, v2, w) {
          return PopScope(
            canPop: !v.loading,
            child: Stack(
              children: [
                w!,
                if (v.loading || v2.loading) const Loader(),
              ],
            ),
          );
        },
      ),
    );
  }
}
