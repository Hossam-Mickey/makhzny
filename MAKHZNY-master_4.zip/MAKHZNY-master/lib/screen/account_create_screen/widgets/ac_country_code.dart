import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/country_picker_pro/country_picker_pro.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

class AcCountryCode extends StatelessWidget {
  const AcCountryCode({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Consumer<CountryPickerPro>(
          builder: (_, v, w) {
            return InkWell(
              onTap: () => v.pickCountry(context),
              child: Container(
                color: Colors.transparent,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AppText(
                      context.read<CountryPickerPro>().loginCountry,
                      // padding: const EdgeInsets.symmetric(horizontal: 10),
                      fontWeight: FontWeight.bold,
                      fontSize: 14.spMin,
                    ),
                    sizedBoxW5,
                    const Icon(Icons.keyboard_arrow_down_rounded),
                    sizedBoxW5,
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
