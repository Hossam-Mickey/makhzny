import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/account_create_pro/account_create_pro.dart';
import 'package:client_1/screen/account_create_screen/widgets/ac_country_code.dart';
import 'package:client_1/widgets/text_field.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../provider/lang_pro/lang_pro.dart';
import 'ac_otp_send_btn.dart';

class AccountPersonalScreen extends StatelessWidget {
  const AccountPersonalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    var accountPro = context.read<AccountCreatePro>();
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        CusTextField(
          validator: (_) {},
          node: accountPro.full_nameF,
          nextNode: accountPro.id_numberF,
          control: accountPro.full_name,
          hintText: lang.full_name,
          fillHint: AutofillHints.name,
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.id_number,
          node: accountPro.id_numberF,
          nextNode: accountPro.dobF,
          hintText: "${lang.id_number} (${lang.optional})",
          type: TextInputType.number,
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.dob,
          node: accountPro.dobF,
          nextNode: accountPro.addressF,
          hintText: "${lang.date_of_birth} (${lang.optional})",
          type: TextInputType.number,
          hint2: "DD/MM/YYYY",
          formatter: [BirthdayTextFormatter()],
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.address,
          node: accountPro.addressF,
          nextNode: accountPro.mobile_numberF,
          hintText: lang.address,
          type: TextInputType.streetAddress,
          fillHint: AutofillHints.fullStreetAddress,
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.mobile_number,
          node: accountPro.mobile_numberF,
          nextNode: accountPro.nature_of_goodsF,
          hintText: lang.mobile_number,
          type: TextInputType.number,
          // hint2: "+966011XXXXXXX",
          fillHint: AutofillHints.telephoneNumberNational,

          prefixIcon: const AcCountryCode(),
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.nature_of_goods,
          node: accountPro.nature_of_goodsF,
          hintText: lang.nature_of_goods_stored,
          nextNode: accountPro.emailF,
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.email,
          node: accountPro.emailF,
          hintText: lang.email,
          nextNode: accountPro.otp_numberF,
          type: TextInputType.emailAddress,
          fillHint: AutofillHints.email,
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.otp_number,
          node: accountPro.otp_numberF,
          hintText: lang.otp_number,
          type: TextInputType.number,
        ),
        sizedBoxH5,
        const AccountOTPSendBtn(),
        sizedBoxH20,
      ],
    );
  }
}
