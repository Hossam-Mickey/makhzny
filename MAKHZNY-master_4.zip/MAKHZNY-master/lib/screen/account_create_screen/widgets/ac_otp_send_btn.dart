import 'package:client_1/constants/colors.dart';
import 'package:client_1/functions/show_snakbar.dart';
import 'package:client_1/provider/account_create_pro/account_create_pro.dart';
import 'package:client_1/provider/country_picker_pro/country_picker_pro.dart';
import 'package:client_1/provider/login_pro/login_pro.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../provider/lang_pro/lang_pro.dart';

class AccountOTPSendBtn extends StatelessWidget {
  const AccountOTPSendBtn({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    var accountPro = context.read<AccountCreatePro>();
    return Align(
      alignment: Alignment.centerRight,
      child: Consumer<LoginPro>(
        builder: (_, v, w) {
          return v.remainingSeconds == 0
              ? TextButton(
                  onPressed: () {
                    var isPersonal = accountPro.selected == 0;
                    var number = isPersonal
                        ? accountPro.mobile_number.text
                        : accountPro.company_phone.text;

                    if (number.isEmpty) {
                      var title = isPersonal
                          ? lang.enter_phone_number
                          : lang.enter_company_phone;

                      MySnackBar.show(title: title);
                      return;
                    }
                    var code = context.read<CountryPickerPro>().loginCountry;
                    context.read<LoginPro>().sendOTP(code + number);
                  },
                  child: AppText(
                    lang.send_otp,
                    fontWeight: FontWeight.bold,
                  ),
                )
              : AppText(
                  "${lang.resend_in} ${v.remainingSeconds} sec",
                  color: MyColor.grey,
                  fontWeight: FontWeight.w500,
                );
        },
      ),
    );
  }
}
