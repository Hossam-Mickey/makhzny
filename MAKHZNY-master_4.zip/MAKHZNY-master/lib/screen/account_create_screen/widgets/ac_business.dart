import 'package:client_1/constants/colors.dart';
import 'package:client_1/constants/image.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/account_create_pro/account_create_pro.dart';
import 'package:client_1/provider/document_pro/document_pro.dart';
import 'package:client_1/route.dart';
import 'package:client_1/screen/account_create_screen/widgets/ac_country_code.dart';
import 'package:client_1/screen/document_screen/widgets/document_add_dialog.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/text_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../provider/lang_pro/lang_pro.dart';
import 'ac_otp_send_btn.dart';

class AccountBusinessScreen extends StatelessWidget {
  const AccountBusinessScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    var accountPro = context.read<AccountCreatePro>();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        CusTextField(
          validator: (_) {},
          control: accountPro.company_name,
          node: accountPro.company_nameF,
          nextNode: accountPro.cr_numberF,
          hintText: lang.company_name,
          fillHint: AutofillHints.name,
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.cr_number,
          node: accountPro.cr_numberF,
          nextNode: accountPro.vat_regF,
          hintText: lang.cr_number,
          type: TextInputType.number,
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.vat_reg,
          node: accountPro.vat_regF,
          nextNode: accountPro.company_phoneF,
          hintText: lang.vat_registration,
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.company_phone,
          node: accountPro.company_phoneF,
          nextNode: accountPro.nature_of_goodsF,
          hintText: lang.company_phone,
          type: TextInputType.number,
          // hint2: "+966011XXXXXXX",
          prefixIcon: const AcCountryCode(),
          fillHint: AutofillHints.telephoneNumberNational,
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.nature_of_goods,
          node: accountPro.nature_of_goodsF,
          hintText: lang.nature_of_goods_stored,
          nextNode: accountPro.company_emailF,
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.company_email,
          node: accountPro.company_emailF,
          nextNode: accountPro.auth_person_nameF,
          hintText: lang.company_email,
          type: TextInputType.emailAddress,
          fillHint: AutofillHints.email,
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.auth_person_name,
          node: accountPro.auth_person_nameF,
          nextNode: accountPro.company_id_numberF,
          hintText: lang.auth_person_name,
          fillHint: AutofillHints.name,
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.company_id_number,
          node: accountPro.company_id_numberF,
          nextNode: accountPro.auth_person_numberF,
          hintText: lang.id_number,
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.auth_person_number,
          type: TextInputType.number,
          prefixIcon: const AcCountryCode(),
          // hint2: "+966011XXXXXXX",
          node: accountPro.auth_person_numberF,
          hintText: lang.auth_person_number,
          nextNode: accountPro.business_otp_numberF,
          fillHint: AutofillHints.telephoneNumberNational,
        ),
        sizedBoxH10,
        CusTextField(
          validator: (_) {},
          control: accountPro.business_otp_number,
          node: accountPro.business_otp_numberF,
          hintText: lang.otp_number,
          type: TextInputType.number,
        ),
        sizedBoxH5,
        const AccountOTPSendBtn(),
        sizedBoxH30,
        Consumer<DocumentPro>(
          child: SizedBox(
            width: double.infinity,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                AppImage(
                  image: MyImage.document,
                  height: 50.spMin,
                ),
                sizedBoxH10,
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 50.w),
                  child: AppText(
                    "${lang.please_attach_required} ",
                    text2: lang.lets_add,
                    color: MyColor.grey,
                    maxLines: 3,
                    textAlign: TextAlign.center,
                    onTapText2: () {
                      showModalBottomSheet(
                        context: navigatorKey.currentContext!,
                        useSafeArea: false,
                        isScrollControlled: true,
                        isDismissible: false,
                        enableDrag: false,
                        backgroundColor: Colors.transparent,
                        builder: (_) {
                          return DocumentAddDialog(dialogContext: _);
                        },
                      );
                    },
                    color2: Theme.of(context).primaryColor,
                  ),
                )
              ],
            ),
          ),
          builder: (_, v, w) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    AppText(
                      "${lang.attached_documents} : ",
                      fontWeight: FontWeight.w500,
                      fontSize: 14.spMin,
                    ),
                    const Spacer(),
                    if (v.pickedFiles.isNotEmpty)
                      InkWell(
                        onTap: () {
                          showModalBottomSheet(
                            context: navigatorKey.currentContext!,
                            useSafeArea: false,
                            isScrollControlled: true,
                            isDismissible: false,
                            enableDrag: false,
                            backgroundColor: Colors.transparent,
                            builder: (_) {
                              return DocumentAddDialog(
                                clear: false,
                                dialogContext: _,
                              );
                            },
                          );
                        },
                        child: Container(
                          height: 20,
                          width: 20,
                          color: Colors.transparent,
                          child: AppImage(
                            image: MyImage.add,
                            height: 15,
                            color: Theme.of(context).primaryColor,
                          ),
                        ),
                      ),
                  ],
                ),
                if (v.pickedFiles.isEmpty) sizedBoxH40,
                if (v.pickedFiles.isNotEmpty) sizedBoxH20,
                if (v.pickedFiles.isNotEmpty)
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: v.pickedFiles.length,
                    itemBuilder: (_, i) {
                      var file = v.pickedFiles[i];
                      return Container(
                        // height: 45.h,
                        padding: const EdgeInsets.all(10),
                        margin: const EdgeInsets.symmetric(vertical: 15),
                        decoration: BoxDecoration(
                          color:
                              Theme.of(context).brightness == Brightness.light
                                  ? Colors.grey.shade300
                                  : Colors.grey.shade800,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.shade900.withOpacity(0.5),
                              spreadRadius: -10,
                              offset: const Offset(0, 4),
                              blurRadius: 20,
                            )
                          ],
                          borderRadius: BorderRadius.circular(6.r),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: AppText(
                                file.name,
                                fontWeight: FontWeight.w400,
                                fontSize: 14.spMin,
                                maxLines: 2,
                              ),
                            ),
                            sizedBoxW10,
                            AppText(
                              file.ext.toUpperCase(),
                              fontWeight: FontWeight.bold,
                              fontSize: 15.spMin,
                              maxLines: 1,
                            ),
                            sizedBoxW10,
                            sizedBoxW5,
                            SizedBox(
                              height: 30,
                              width: 30,
                              child: IconButton(
                                padding: EdgeInsets.zero,
                                onPressed: () {
                                  v.removePickedFile(file);
                                },
                                icon: const Icon(Icons.close),
                                iconSize: 22,
                                color: Colors.red,
                              ),
                            )
                          ],
                        ),
                      );
                    },
                  ),
                if (v.pickedFiles.isEmpty) w!,
              ],
            );
          },
        ),
        sizedBoxH40,
      ],
    );
  }
}
