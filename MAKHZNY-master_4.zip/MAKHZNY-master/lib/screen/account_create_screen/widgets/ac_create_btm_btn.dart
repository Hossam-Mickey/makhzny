import 'package:client_1/constants/colors.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/provider/user_pro/user_pro.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../provider/lang_pro/lang_pro.dart';

class AccountCreateBottomBtn extends StatelessWidget {
  const AccountCreateBottomBtn({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    var borderRadius2 = BorderRadius.only(
      topLeft: Radius.circular(20.r),
      topRight: Radius.circular(20.r),
    );
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        systemNavigationBarColor: Theme.of(context).primaryColor,
      ),
      child: Stack(
        alignment: AlignmentDirectional.bottomCenter,
        // mainAxisSize: MainAxisSize.min,
        children: [
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  color: context.read<ThemePro>().grey.withOpacity(0.4),
                  borderRadius: borderRadius2,
                ),
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        Icons.info_rounded,
                        size: 18.spMin,
                        color: MyColor.primary,
                      ),
                      sizedBoxW5,
                      Flexible(
                        child: AppText(
                          lang.please_ensure_info,
                          maxLines: 3,
                          fontWeight: FontWeight.w400,
                          fontSize: (11.5).spMin,
                          color: MyColor.primary,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              sizedBoxH30,
            ],
          ),
          AppButton(
            text: lang.continue_text,
            fontWeight: FontWeight.w500,
            fontSize: 18.spMin,
            borderRadius: borderRadius2,
            onPressed: () {
              context.read<UserPro>().registerUser();
            },
          )
        ],
      ),
    );
  }
}
