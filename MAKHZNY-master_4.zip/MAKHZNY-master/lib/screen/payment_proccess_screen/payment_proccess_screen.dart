// ignore_for_file: use_build_context_synchronously

import 'package:client_1/constants/api.dart';
import 'package:client_1/functions/connectivity_check.dart';
import 'package:client_1/functions/print_c.dart';
import 'package:client_1/functions/show_snakbar.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/main.dart';
import 'package:client_1/provider/invoice_pro/invoice_pro.dart';
import 'package:client_1/provider/rent_checkout_pro/rent_checkout_pro.dart';
import 'package:client_1/route.dart';
import 'package:client_1/screen/store_screen/store_screen.dart';
import 'package:client_1/widgets/loader.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:universal_platform/universal_platform.dart';
import 'package:url_launcher/url_launcher.dart';

class PaymentProcessScreen extends StatefulWidget {
  final int id;
  final String? link;
  const PaymentProcessScreen({
    super.key,
    required this.id,
    this.link,
  });

  @override
  State<PaymentProcessScreen> createState() => _PaymentProcessScreenState();
}

class _PaymentProcessScreenState extends State<PaymentProcessScreen> {
  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewController? webViewController;
  InAppWebViewSettings settings = InAppWebViewSettings(
    javaScriptCanOpenWindowsAutomatically: true,
    useShouldOverrideUrlLoading: true,
    userAgent:
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
    algorithmicDarkeningAllowed:
        Theme.of(navigatorKey.currentContext!).brightness == Brightness.dark,
  );

  bool loading = false;
  bool hasError = false;

  late Uri uri;

  @override
  void initState() {
    uri = Uri.parse(widget.link ?? "${API.baseUrl}mobile/cart/${widget.id}");
    if (UniversalPlatform.isWeb || UniversalPlatform.isWindows) {
      launchUrl(uri).then((_) {
        if (mounted) context.pushReplacement("/home");
      });
    } else {
      loading = true;
      setState(() {});
      printC(uri.toString());
    }

    super.initState();
  }

  @override
  void setState(VoidCallback fn) {
    if (!mounted) return;
    super.setState(fn);
  }

  @override
  void dispose() {
    webViewController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        systemNavigationBarColor: Theme.of(context).scaffoldBackgroundColor,
      ),
      child: Scaffold(
        body: Stack(
          children: [
            if (!UniversalPlatform.isWeb && !UniversalPlatform.isWindows)
              SizedBox(
                height: MediaQuery.sizeOf(context).height,
                width: double.infinity,
                child: SafeArea(
                  child: InAppWebView(
                    key: webViewKey,
                    initialUrlRequest: URLRequest(
                      allowsCellularAccess: true,
                      url: WebUri.uri(uri),
                    ),
                    initialSettings: settings,
                    onWebViewCreated: (controller) {
                      webViewController = controller;
                      setState(() {});
                    },
                    onLoadStart: (controller, url) {
                      hasError = false;
                      loading = true;
                      setState(() {});
                    },
                    onLoadStop: (controller, url) async {
                      loading = false;
                      setState(() {});
                    },
                    onReceivedError: (controller, request, error) {
                      loading = false;
                      hasError = true;
                      setState(() {});
                    },
                    onReceivedHttpError: (controller, request, errorResponse) {
                      loading = false;
                      hasError = true;
                      setState(() {});
                    },
                    shouldOverrideUrlLoading:
                        (controller, navigationAction) async {
                      var go = _navigateDetect(
                          navigationAction.request.url!.uriValue);
                      if (go) return NavigationActionPolicy.ALLOW;
                      return NavigationActionPolicy.CANCEL;
                    },
                  ),
                ),
              ),
            if (loading) const Loader(),
            if (hasError)
              Container(
                height: double.infinity,
                width: double.infinity,
                color: Theme.of(context).scaffoldBackgroundColor,
                child: StoreErrorScreen(
                  onTap: () async {
                    var connectCheck = getIt<ConnectivityCheck>();
                    var network = await connectCheck.getCurrentState();
                    if (!network) return;
                    setState(() {
                      loading = true;
                      hasError = false;
                    });
                    webViewController?.reload();
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  bool _navigateDetect(Uri url) {
    printC("navigate called ${url.path}");
    var context = navigatorKey.currentContext!;
    var apiBase = Uri.parse(API.baseUrl);
    var bool = url.host == "www.geidea.net" ||
        url.host == apiBase.host ||
        url.host == "www.ksamerchant.geidea.net";
    if (bool) {
      printC(url, color: PColor.magenta);
      var responseMes = url.queryParameters["responseMessage"];
      var code =
          int.tryParse(url.queryParameters["responseCode"].toString()) ?? 000;
      var para = url.path.split("/").last;
      if (para == "payment_fail_mobile") {
        MySnackBar.show(title: "Payment failed", duration: 4.seconds);
        Navigator.pop(context);
        return false;
      }

      if (responseMes == "Cancelled by User") {
        Navigator.pop(context);
        return false;
      } else if (code >= 110) {
        MySnackBar.show(
          title: "Transaction failed\n$responseMes",
          duration: 4.seconds,
        );
        Navigator.pop(context);
        return false;
      } else if (responseMes == "Success") {
        // Navigator.pop(context);
        printC("PAYMENT SUCCESS");
        if (widget.link == null) {
          messangerKey.currentContext?.read<RentCheckOutPro>().successRemove();
          var loc = GoRouter.of(context).location();
          loc = loc.replaceAll("/signature", "");
          context.pushReplacement(loc);
          MySnackBar.show(
            title: "Transaction success",
            duration: 4.seconds,
          );
        } else {
          messangerKey.currentContext
              ?.read<InvoicePro>()
              .changeToPaid(widget.id);
          context.pushReplacement("/settings/invoice");
          MySnackBar.show(
            title: "Transaction success",
            duration: 4.seconds,
          );
        }

        return false;
      }
    }

    if (bool) return true;

    return false;
  }
}
