import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/widgets/loader.dart';
import 'package:client_1/widgets/mouse_cursor.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../constants/sized_box.dart';
import '../../../widgets/app_text.dart';

class SettingsCard extends StatelessWidget {
  final String name;
  final Function onTap;
  final bool loading;
  const SettingsCard({
    super.key,
    this.loading = false,
    required this.name,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return CusMouseCursor(
      child: GestureDetector(
        onTap: () {
          if (loading) return;
          onTap();
        },
        child: Container(
          height: 40,
          margin: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: context.watch<ThemePro>().cardColor,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.shade900.withOpacity(0.5),
                spreadRadius: -10,
                offset: const Offset(0, 4),
                blurRadius: 20,
              )
            ],
            borderRadius: BorderRadius.circular(6.r),
          ),
          child: Row(
            children: [
              sizedBoxW20,
              AppText(
                name,
                fontWeight: FontWeight.w500,
                fontSize: 14.spMin,
              ),
              const Spacer(),
              if (loading)
                SizedBox(
                  height: 30.h,
                  width: 30.h,
                  child: const Loader(loaderOnly: true, stock: 2),
                )
              else
                Icon(
                  Icons.arrow_forward_ios,
                  size: 14.spMin,
                ),
              sizedBoxW20,
            ],
          ),
        ),
      ),
    );
  }
}
