import 'package:client_1/functions/show_dialog.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/user_pro/user_pro.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../constants/sized_box.dart';
import '../home_screen/widgets/home_top.dart';
import 'widgets/settings_card.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.watch<LangPro>().lang;
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
          
              const HomeTop(),
              sizedBoxH40,
              SettingsCard(
                name: lang.profile,
                onTap: () {
                  var userPro = context.read<UserPro>();
                  if (userPro.isLogin) {
                    context.go("/settings/user_info");
                  } else {
                    userPro.notLoginDialog();
                  }
                },
              ),
              SettingsCard(
                name: lang.languages,
                onTap: () => context.go("/settings/language"),
              ),
              SettingsCard(
                name: lang.appearance,
                onTap: () => context.go("/settings/appearance"),
              ),
              // SettingsCard(
              //   name: lang.saved_payment_methods,
              //   onTap: () => context.go("/settings/saved_payment"),
              // ),
              SettingsCard(
                name: lang.documents,
                onTap: () {
                  var userPro = context.read<UserPro>();
                  if (!userPro.isLogin) return userPro.notLoginDialog();
                  context.go("/settings/documents");
                },
              ),
              SettingsCard(
                name: lang.invoices,
                onTap: () {
                  var userPro = context.read<UserPro>();
                  if (!userPro.isLogin) return userPro.notLoginDialog();
                  context.go("/settings/invoice");
                },
              ),
              Consumer<UserPro>(
                builder: (_, v, w) {
                  return SettingsCard(
                    name: v.isLogin ? lang.logout : lang.login,
                    onTap: () {
                      if (v.isLogin) {
                        v.logout();
                      } else {
                        context.push("/settings/login");
                      }
                    },
                  );
                },
              ),
              Consumer<UserPro>(
                builder: (_, v, w) {
                  return !v.isLogin
                      ? const SizedBox()
                      : SettingsCard(
                          loading: v.loading,
                          name: lang.delete_ac,
                          onTap: () {
                            if (v.loading) return;
                            showAlertdialogMessage(
                              lang.delete_ac,
                              lang.delete_ac_sub,
                              (_) {
                                return [
                                  TextButton(
                                    onPressed: () => Navigator.pop(_),
                                    child: AppText(
                                      lang.cancel,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      v.deleteAccount();
                                      Navigator.pop(_);
                                    },
                                    child: AppText(
                                      lang.continue_text,
                                      fontWeight: FontWeight.w400,
                                      color: Colors.redAccent,
                                    ),
                                  ),
                                  sizedBoxW20,
                                ];
                              },
                            );
                          },
                        );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
