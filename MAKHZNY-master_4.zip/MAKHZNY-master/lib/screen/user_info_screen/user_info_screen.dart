import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/functions/connectivity_check.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/user_pro/user_pro.dart';
import 'package:client_1/screen/store_screen/store_screen.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/container_shimner.dart';
import 'package:client_1/widgets/cus_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../constants/colors.dart';

class UserInfoScreen extends StatelessWidget {
  const UserInfoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          backgroundColor: MyColor.refreshColor,
          onRefresh: () {
            return context.read<UserPro>().loadUser(true);
          },
          child: Consumer<UserPro>(
            builder: (_, v, w) {
              var expanded = Expanded(
                child: StoreErrorScreen(
                  sub: v.errorMes,
                  onTap: () async {
                    var connectCheck = getIt<ConnectivityCheck>();
                    var network = await connectCheck.getCurrentState();
                    if (!network) return;
                    v.loadUser();
                  },
                ),
              );
              return Column(
                children: [
                  sizedBoxH20,
                  CusAppbar(title: lang.profile),
                  Builder(
                    builder: (_) {
                      if (v.hasError) return expanded;

                      if (v.loading) return const UserShowloader();

                      if (v.userShow == null) return expanded;
                      var user = v.userShow!;
                      return Expanded(
                        child: SingleChildScrollView(
                          physics: const AlwaysScrollableScrollPhysics(),
                          child: Column(
                            children: [
                              sizedBoxH20,
                              card(
                                lang.full_name,
                                user.name,
                                Icons.person_2_outlined,
                              ),
                              card(
                                lang.email,
                                user.email,
                                Icons.email_outlined,
                              ),
                              card(
                                lang.mobile_number,
                                user.phone,
                                Icons.phone_iphone_outlined,
                              ),
                              sizedBoxH20,
                            ],
                          ),
                        ),
                      );
                    },
                  )
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  ListTile card(String title, String sub, IconData icon) {
    return ListTile(
      leading: Icon(icon),
      title: AppText(
        title,
        fontSize: 15.spMin,
        fontWeight: FontWeight.bold,
      ),
      subtitle: AppText(
        sub,
        fontSize: 13.spMin,
        fontWeight: FontWeight.w400,
      ),
    );
  }
}

class UserShowloader extends StatelessWidget {
  const UserShowloader({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      child: Column(
        children: [
          sizedBoxH20,
          loader(),
          loader(),
          loader(),
          sizedBoxH20,
        ],
      ),
    );
  }

  ListTile loader() {
    return ListTile(
      leading: ContainerShimner(
        width: 25,
        height: 35,
        borderRadius: BorderRadius.circular(6),
      ),
      title: Row(
        children: [
          ContainerShimner(width: 100.w),
        ],
      ),
      subtitle: Row(
        children: [
          ContainerShimner(width: 200.w),
        ],
      ),
    );
  }
}
