import 'package:client_1/provider/add_card_pro/add_card_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/widgets/rtl_layout.dart';
import 'package:client_1/widgets/text_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../constants/sized_box.dart';
import '../../widgets/app_button.dart';
import '../../widgets/cus_app_bar.dart';

class AddCardScreen extends StatelessWidget {
  const AddCardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        systemNavigationBarColor: Theme.of(context).primaryColor,
      ),
      child: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              sizedBoxH20,
              RTLLayout(child: CusAppbar(title: lang.add_card)),
              sizedBoxH30,
              Consumer<AddCardPro>(
                builder: (_, v, w) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CusTextField(
                          validator: (v) {},
                          node: v.cardNameF,
                          nextNode: v.cardNumberF,
                          control: v.cardName,
                          hintText: lang.card_nickname,
                        ),
                        sizedBoxH10,
                        CusTextField(
                          validator: (v) {},
                          node: v.cardNumberF,
                          nextNode: v.cardHolderF,
                          control: v.cardNumber,
                          hintText: lang.card_number,
                          type: TextInputType.number,
                          formatter: [
                            CardFormatter(),
                          ],
                        ),
                        sizedBoxH10,
                        CusTextField(
                          validator: (v) {},
                          node: v.cardHolderF,
                          nextNode: v.cardCvvF,
                          control: v.cardHolderName,
                          hintText: lang.card_holder_name,
                        ),
                        sizedBoxH10,
                        Row(
                          children: [
                            Expanded(
                              child: CusTextField(
                                validator: (v) {},
                                node: v.cardCvvF,
                                nextNode: v.cardExpireF,
                                control: v.cardCvv,
                                hintText: lang.cvv,
                                type: TextInputType.number,
                              ),
                            ),
                            sizedBoxW30,
                            Expanded(
                              child: CusTextField(
                                validator: (v) {},
                                node: v.cardExpireF,
                                control: v.cardExpire,
                                hintText: lang.expiry_date,
                                type: TextInputType.number,
                                formatter: [
                                  ExpiryDateInputFormatter(),
                                ],
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  );
                },
              ),
              const Spacer(),
              RTLLayout(
                child: AppButton(
                  text: lang.add,
                  onPressed: () {},
                  fontSize: 14.spMin,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
