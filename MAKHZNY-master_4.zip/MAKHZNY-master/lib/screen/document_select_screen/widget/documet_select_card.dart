import 'package:client_1/functions/show_snakbar.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:open_file/open_file.dart';
import 'package:provider/provider.dart';

import '../../../constants/sized_box.dart';

class DocumentSelectCard extends StatelessWidget {
  final String name;
  final String path;
  final String ext;
  final Function onTap;
  final bool selected;
  const DocumentSelectCard({
    super.key,
    required this.name,
    required this.path,
    required this.ext,
    required this.onTap,
    this.selected = false,
  });

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return GestureDetector(
      onTap: () => onTap(),
      child: AnimatedContainer(
        duration: 500.ms,
        constraints: const BoxConstraints(minWidth: 115),
        width: double.infinity,
        margin: const EdgeInsets.all(15),
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: Theme.of(context).scaffoldBackgroundColor,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selected
                ? Theme.of(context).primaryColor
                : context.read<ThemePro>().grey.withOpacity(0.2),
            width: 1.5,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            sizedBoxW20,
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: AppText(
                    name,
                    fontWeight: FontWeight.w500,
                    fontSize: 14.spMin,
                    maxLines: 2,
                  ),
                ),
                sizedBoxW10,
                AppText(
                  ext.toUpperCase(),
                  fontWeight: FontWeight.w900,
                  fontSize: 14.spMin,
                  maxLines: 2,
                ),
              ],
            ),
            sizedBoxH10,
            const Divider(),
            Center(
              child: InkWell(
                onTap: () async {
                  try {
                    await OpenFile.open(path);
                  } catch (e) {
                    MySnackBar.show(title: "Failed to open");
                  }
                },
                child: Container(
                  color: Colors.transparent,
                  padding: const EdgeInsets.all(5),
                  child: AppText(
                    lang.view_document,
                    fontWeight: FontWeight.w500,
                    fontSize: 13.spMin,
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
