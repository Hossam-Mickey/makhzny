import 'package:client_1/constants/colors.dart';
import 'package:client_1/constants/image.dart';
import 'package:client_1/provider/document_pro/document_pro.dart';
import 'package:client_1/route.dart';
import 'package:client_1/screen/document_screen/widgets/document_add_dialog.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/loader.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../constants/sized_box.dart';
import '../../provider/lang_pro/lang_pro.dart';
import '../../widgets/cus_app_bar.dart';
import 'widget/documet_select_card.dart';

class DocumentSelectScreen extends StatelessWidget {
  const DocumentSelectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        systemNavigationBarColor: Theme.of(context).primaryColor,
      ),
      child: Consumer<DocumentPro>(
        child: Scaffold(
          bottomNavigationBar: AppButton(
            text: lang.upload,
            fontWeight: FontWeight.w500,
            fontSize: 18.spMin,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20.r),
              topRight: Radius.circular(20.r),
            ),
            onPressed: () {
              context.read<DocumentPro>().upload();
            },
          ).animate().moveY(duration: 700.ms, begin: 50).fade(duration: 700.ms),
          body: SafeArea(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  sizedBoxH20,
                  CusAppbar(
                    title: lang.documents,
                    sideChild: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: IconButton(
                        onPressed: () {
                          showModalBottomSheet(
                            context: navigatorKey.currentContext!,
                            useSafeArea: false,
                            isScrollControlled: true,
                            isDismissible: false,
                            enableDrag: false,
                            backgroundColor: Colors.transparent,
                            builder: (_) {
                              return DocumentAddDialog(dialogContext: _);
                            },
                          );
                        },
                        icon: AppImage(
                          image: MyImage.add,
                          height: 15,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                    ),
                  ),
                  sizedBoxH20,
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: AppText(
                      lang.select_doc_you_want,
                      color: MyColor.grey,
                      fontSize: 14.spMin,
                      maxLines: 3,
                    ),
                  ),
                  sizedBoxH10,
                  Consumer<DocumentPro>(
                    builder: (_, v, w) {
                      return ListView.builder(
                        shrinkWrap: true,
                        itemCount: v.pickedFiles.length,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: (_, i) {
                          var doc = v.pickedFiles[i];
                          return DocumentSelectCard(
                            name: doc.name,
                            path: doc.path,
                            ext: doc.ext,
                            selected: v.isSelected(doc),
                            onTap: () => v.toggleSelect(doc),
                          );
                        },
                      );
                    },
                  )
                ],
              ),
            ),
          ),
        ),
        builder: (_, v, w) {
          return PopScope(
            canPop: !v.loading,
            child: Stack(
              children: [
                w!,
                if (v.loading) const Loader(),
              ],
            ),
          );
        },
      ),
    );
  }
}
