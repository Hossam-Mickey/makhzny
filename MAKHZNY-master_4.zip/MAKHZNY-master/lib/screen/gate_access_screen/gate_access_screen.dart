import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../constants/sized_box.dart';
import '../home_screen/widgets/home_top.dart';

class GateAccessScreen extends StatelessWidget {
  const GateAccessScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            sizedBoxH20,
            const HomeTop(),
            Expanded(
              child: Center(
                child: AppText(
                  "COMING SOON",
                  fontWeight: FontWeight.bold,
                  fontSize: 14.spMin,
                ),
              ),
            )
            // sizedBoxH40,
            // const SearchText(),
            // ListView.builder(
            //   shrinkWrap: true,
            //   itemCount: 10,
            //   physics: const NeverScrollableScrollPhysics(),
            //   padding: const EdgeInsets.symmetric(
            //     horizontal: 15,
            //     vertical: 20,
            //   ),
            //   itemBuilder: (_, i) => const Padding(
            //     padding: EdgeInsets.symmetric(vertical: 10),
            //     child: GateAccessCard(),
            //   ),
            // )
          ],
        ),
      ),
    );
  }
}
