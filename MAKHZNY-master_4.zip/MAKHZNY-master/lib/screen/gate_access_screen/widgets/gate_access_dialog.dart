import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../constants/colors.dart';
import '../../../constants/sized_box.dart';
import '../../../functions/blur_bottom_sheet.dart';
import '../../../provider/lang_pro/lang_pro.dart';
import '../../../widgets/app_text.dart';

class AccessCodeDialog extends StatelessWidget {
  final BuildContext dialogContext;

  const AccessCodeDialog({super.key, required this.dialogContext});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    double height = 400.h;
    return Stack(
      children: [
        const BlurDialogBg(),
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: height,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Theme.of(context).scaffoldBackgroundColor,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Column(
                  children: [
                    sizedBoxH50,
                    sizedBoxH20,
                    sizedBoxH20,
                    AppText(
                      lang.access_code,
                      fontWeight: FontWeight.w700,
                      fontSize: 20.spMin,
                    ),
                    sizedBoxH20,
                    AppText(
                      lang.pls_enter_code,
                      color: MyColor.grey,
                      maxLines: 5,
                      fontWeight: FontWeight.w400,
                      fontSize: 14.spMin,
                    ),
                    sizedBoxH50H,
                    AppText(
                      "505939",
                      fontWeight: FontWeight.w700,
                      color: MyColor.primary,
                      fontSize: 35.spMin,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: height,
            width: double.infinity,
            alignment: Alignment.topRight,
            padding: const EdgeInsets.only(top: 10, right: 20),
            child: IconButton(
              padding: EdgeInsets.zero,
              onPressed: () => dialogContext.pop(),
              icon: Icon(
                Icons.close,
                color: Theme.of(context).primaryColor,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
