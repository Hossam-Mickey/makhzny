import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../constants/colors.dart';
import '../../../constants/image.dart';
import '../../../constants/sized_box.dart';
import '../../../provider/lang_pro/lang_pro.dart';
import '../../../route.dart';
import '../../../widgets/app_text.dart';
import 'gate_access_dialog.dart';

class GateAccessCard extends StatelessWidget {
  const GateAccessCard({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    var grey = context.read<ThemePro>().grey;
    return Container(
      height: 105,
      decoration: BoxDecoration(
        color: context.read<ThemePro>().cardColor,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade900.withOpacity(0.1),
            spreadRadius: -1,
            offset: const Offset(0, 4),
            blurRadius: 20,
          )
        ],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Expanded(
            child: Row(
              children: [
                Container(
                  width: 90,
                  margin: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: grey.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Flexible(
                              child: AppText(
                                "Medium - A12",
                                maxLines: 2,
                                fontSize: 14.spMin,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ],
                        ),
                        AppText(
                          "12 M²",
                          fontSize: 14.spMin,
                          fontWeight: FontWeight.w400,
                        ),
                        const Spacer(),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Transform.translate(
                              offset: const Offset(0, 2),
                              child: AppImage(
                                image: MyImage.location,
                                color: MyColor.grey,
                                height: 12.spMin,
                              ),
                            ),
                            sizedBoxW5,
                            Expanded(
                              child: AppText(
                                "Dammam",
                                fontSize: 12.spMin,
                                fontWeight: FontWeight.w400,
                                color: MyColor.grey,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
            color: grey,
            height: double.infinity,
            width: 1.5,
          ),
          SizedBox(
            width: 90,
            child: Column(
              children: [
                accessBtn(
                  MyImage.gate_access,
                  lang.open,
                  Theme.of(context).primaryColor,
                  () {
                    showModalBottomSheet(
                      context: navigatorKey.currentContext!,
                      useSafeArea: false,
                      isScrollControlled: true,
                      enableDrag: false,
                      isDismissible: false,
                      backgroundColor: Colors.transparent,
                      builder: (_) => AccessCodeDialog(dialogContext: _),
                    );
                  },
                ),
                Container(
                  color: grey,
                  height: 1.5,
                ),
                accessBtn(
                  MyImage.gate_close,
                  lang.close,
                  MyColor.primary,
                  () {},
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget accessBtn(
    String image,
    String name,
    Color color,
    Function onTap,
  ) {
    return Expanded(
      child: InkWell(
        onTap: () => onTap(),
        child: Container(
          color: Colors.transparent,
          child: Row(
            children: [
              const Spacer(),
              AppImage(
                image: image,
                color: color,
                height: 18.spMin,
                width: 18.spMin,
              ),
              sizedBoxW5,
              AppText(
                name,
                fontWeight: FontWeight.w600,
                color: color,
                fontSize: 12.spMin,
              ),
              const Spacer(),
            ],
          ),
        ),
      ),
    );
  }
}
