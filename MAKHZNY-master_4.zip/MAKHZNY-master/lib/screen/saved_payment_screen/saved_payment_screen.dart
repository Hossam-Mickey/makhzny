import 'package:client_1/constants/image.dart';
import 'package:client_1/route.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../constants/sized_box.dart';
import '../../functions/blur_bottom_sheet.dart';
import '../../provider/lang_pro/lang_pro.dart';
import '../../widgets/cus_app_bar.dart';

class SavedPaymentScreen extends StatelessWidget {
  const SavedPaymentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        systemNavigationBarColor: Theme.of(context).scaffoldBackgroundColor,
      ),
      child: Scaffold(
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              children: [
                sizedBoxH20,
                CusAppbar(
                  title: lang.saved_payment_methods,
                  sideChild: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: IconButton(
                      onPressed: () {
                        var loc = GoRouter.of(context).location();
                        context.go("$loc/add");
                      },
                      icon: AppImage(
                        image: MyImage.add,
                        height: 15,
                        color: Theme.of(context).primaryColor,
                      ),
                    ),
                  ),
                ),
                sizedBoxH30,

                const SavedPaymentCard(cardColor: Color(0xffEDEDED)),
                const SavedPaymentCard(cardColor: Color(0xffF2E5D8)),
                const SavedPaymentCard(cardColor: Color(0xffE9DFEF)),

                // ListView.builder(
                //   shrinkWrap: true,
                //   padding:
                //       const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                //   physics: const NeverScrollableScrollPhysics(),
                //   itemCount: 10,
                //   itemBuilder: (_, i) {
                //     return const InvoiceCard();
                //   },
                // )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SavedPaymentCard extends StatelessWidget {
  const SavedPaymentCard({super.key, required this.cardColor});

  final Color cardColor;

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    Color darken(Color color, [double amount = 0.1]) {
      assert(amount >= 0 && amount <= 1);
      return Color.fromRGBO(
        (color.red * (1 - amount)).round(),
        (color.green * (1 - amount)).round(),
        (color.blue * (1 - amount)).round(),
        1,
      );
    }

    Color lighten(Color color, [double amount = 0.1]) {
      assert(amount >= 0 && amount <= 1);
      return Color.fromRGBO(
        color.red + ((255 - color.red) * amount).round(),
        color.green + ((255 - color.green) * amount).round(),
        color.blue + ((255 - color.blue) * amount).round(),
        1,
      );
    }

    var color1 = darken(cardColor, 0);
    var color2 = lighten(color1, 0.4);

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
      height: 80,
      width: double.infinity,
      decoration: BoxDecoration(
        color: color1,
        borderRadius: BorderRadius.circular(8.r),
      ),
      child: Stack(
        children: [
          Positioned(
            top: 12.h,
            left: -25.w,
            child: Container(
              height: 50.w,
              width: 50.w,
              decoration: BoxDecoration(
                color: color2,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            top: -30.h,
            left: 50.w,
            child: Container(
              height: 70.w,
              width: 70.w,
              decoration: BoxDecoration(
                color: color2,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            bottom: -20.h,
            left: 160.w,
            child: Container(
              height: 60.w,
              width: 60.w,
              decoration: BoxDecoration(
                color: color2,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            top: -30.h,
            left: 250.w,
            child: Container(
              height: 70.w,
              width: 70.w,
              decoration: BoxDecoration(
                color: color2,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(
              vertical: 10,
              horizontal: 15,
            ),
            child: Row(
              children: [
                AppImage(
                  image: MyImage.visa,
                  height: 20.h,
                ),
                sizedBoxW10,
                sizedBoxW5,
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      AppText(
                        "Card Nickname",
                        fontWeight: FontWeight.w400,
                        fontSize: 12.spMin,
                        color: Colors.black,
                      ),
                      const Spacer(),
                      AppText(
                        "4242 4242 4242 4242",
                        fontWeight: FontWeight.w700,
                        fontSize: 14.spMin,
                        color: Colors.black,
                      ),
                      Row(
                        children: [
                          Flexible(
                            child: AppText(
                              "Bank name",
                              fontWeight: FontWeight.w400,
                              fontSize: 10.spMin,
                              color: Colors.black,
                            ),
                          ),
                          sizedBoxW30W,
                          AppText(
                            "11/28",
                            fontWeight: FontWeight.w400,
                            fontSize: 10.spMin,
                            color: Colors.black,
                          ),
                        ],
                      )
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    blurBottomSheet(
                      title: lang.are_you_sure_card,
                      continueText: lang.yes,
                      onTap: (_) {},
                    );
                  },
                  child: Container(
                    color: Colors.transparent,
                    padding: const EdgeInsets.all(5),
                    child: AppImage(
                      image: MyImage.delete,
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
