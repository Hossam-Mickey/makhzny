// import 'dart:convert';

// import 'package:client_1/constants/image.dart';
// import 'package:client_1/constants/sized_box.dart';
// import 'package:client_1/functions/print_c.dart';
// import 'package:client_1/provider/cart_pro/cart_pro.dart';
// import 'package:client_1/provider/lang_pro/lang_pro.dart';
// import 'package:client_1/provider/payment_gateway_pro/payment_gateway_pro.dart';
// import 'package:client_1/provider/rent_checkout_pro/rent_checkout_pro.dart';
// import 'package:client_1/provider/theme_pro/theme_pro.dart';
// import 'package:client_1/screen/language_screen/language_screen.dart';
// import 'package:client_1/widgets/app_button.dart';
// import 'package:client_1/widgets/app_text.dart';
// import 'package:client_1/widgets/cus_app_bar.dart';
// import 'package:client_1/widgets/loader.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_animate/flutter_animate.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:provider/provider.dart';
// import 'package:webview_flutter/webview_flutter.dart';

// class PaymentMethodScreen extends StatefulWidget {
//   const PaymentMethodScreen({super.key});

//   @override
//   State<PaymentMethodScreen> createState() => _PaymentMethodScreenState();
// }

// class _PaymentMethodScreenState extends State<PaymentMethodScreen> {
//   int selected = 0;
//   @override
//   Widget build(BuildContext context) {
//     var lang = context.read<LangPro>().lang;

//     return AnnotatedRegion<SystemUiOverlayStyle>(
//       value: SystemUiOverlayStyle(
//         systemNavigationBarColor: Theme.of(context).primaryColor,
//       ),
//       child: Consumer<RentCheckOutPro>(
//         child: Scaffold(
//           bottomNavigationBar: AppButton(
//             text: lang.continue_text,
//             fontWeight: FontWeight.w500,
//             fontSize: 18.spMin,
//             borderRadius: BorderRadius.only(
//               topLeft: Radius.circular(20.r),
//               topRight: Radius.circular(20.r),
//             ),
//             onPressed: () {
//               var read = context.read<RentCheckOutPro>();
//               // read.checkOut();
//               context.read<PaymentGatewayPro>().checkOut();
//             },
//           ).animate().moveY(duration: 700.ms, begin: 50).fade(duration: 700.ms),
//           body: SafeArea(
//             child: SingleChildScrollView(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   sizedBoxH20,
//                   CusAppbar(title: lang.payment_method),
//                   sizedBoxH20,
//                   AppText(
//                     lang.select_payment_method,
//                     color: ThemePro().grey,
//                     fontWeight: FontWeight.w500,
//                     padding: const EdgeInsets.symmetric(horizontal: 15),
//                     maxLines: 4,
//                   ),
//                   sizedBoxH10,
//                   LanguageCard(
//                     selected: selected == 0,
//                     image: MyImage.visa,
//                     weight: FontWeight.bold,
//                     name: lang.card_payment,
//                     onTap: () => change(0),
//                   ),
//                   LanguageCard(
//                     selected: selected == 1,
//                     image: MyImage.sadad,
//                     name: lang.sadad_payment,
//                     weight: FontWeight.bold,
//                     onTap: () => change(1),
//                   ),
//                   LanguageCard(
//                     selected: selected == 2,
//                     image: MyImage.bank_transfer,
//                     name: lang.bank_tansfer,
//                     weight: FontWeight.bold,
//                     onTap: () => change(2),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//         builder: (_, v, w) {
//           return PopScope(
//             canPop: !v.loading,
//             child: Stack(
//               children: [
//                 w!,
//                 if (v.loading) const Loader(),
//               ],
//             ),
//           );
//         },
//       ),
//     );
//   }

//   void change(int s) {
//     if (s == selected) return;
//     selected = s;
//     setState(() {});
//   }
// }
