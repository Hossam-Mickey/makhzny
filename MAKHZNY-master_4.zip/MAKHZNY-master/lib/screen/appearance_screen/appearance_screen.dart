import 'package:client_1/constants/image.dart';
import 'package:client_1/model/lang_model/lang_model.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../constants/colors.dart';
import '../../constants/sized_box.dart';
import '../../provider/lang_pro/lang_pro.dart';
import '../../widgets/app_image.dart';
import '../../widgets/app_text.dart';
import '../../widgets/cus_app_bar.dart';

class AppearanceScreen extends StatelessWidget {
  const AppearanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              sizedBoxH20,
              CusAppbar(title: lang.appearance),
              sizedBoxH30,
              const AppearanceCard(type: ThemeType.light),
              const AppearanceCard(type: ThemeType.dark),
              const AppearanceCard(type: ThemeType.auto),
            ],
          ),
        ),
      ),
    );
  }
}

class AppearanceCard extends StatelessWidget {
  final ThemeType type;
  const AppearanceCard({super.key, required this.type});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return Consumer<ThemePro>(
      child: Row(
        children: [
          Container(
            margin: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: MyColor.grey,
              borderRadius: BorderRadius.circular(8),
            ),
            child: AppImage(
              image: image(),
              fit: BoxFit.cover,
              height: 60,
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Spacer(),
                  AppText(
                    title(lang),
                    maxLines: 2,
                    fontSize: 15.spMin,
                    fontWeight: FontWeight.w100,
                  ),
                  sizedBoxH5,
                  AppText(
                    sub(lang),
                    maxLines: 2,
                    fontSize: 12.spMin,
                    color: MyColor.grey,
                    fontWeight: FontWeight.w400,
                  ),
                  const Spacer(),
                ],
              ),
            ),
          ),
        ],
      ),
      builder: (_, v, w) {
        return GestureDetector(
          onTap: () => v.change(type),
          child: AnimatedContainer(
            duration: 400.ms,
            height: 90,
            margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
            decoration: BoxDecoration(
              color: Theme.of(context).scaffoldBackgroundColor,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: v.type == type
                    ? Theme.of(context).primaryColor
                    : v.grey.withOpacity(0.2),
                width: 1.5,
              ),
              // boxShadow: [
              //   BoxShadow(
              //     color: Colors.black.withOpacity(0.2),
              //     spreadRadius: -1,
              //     offset: const Offset(0, 4),
              //     blurRadius: 20,
              //   )
              // ],
            ),
            child: w!,
          ),
        );
      },
    );
  }

  String image() {
    switch (type) {
      case ThemeType.light:
        return MyImage.light_mode;
      case ThemeType.dark:
        return MyImage.dark_mode;
      case ThemeType.auto:
        return MyImage.auto_mode;
      default:
        return MyImage.light_mode;
    }
  }

  String title(LangModel lang) {
    switch (type) {
      case ThemeType.light:
        return lang.light_mode;
      case ThemeType.dark:
        return lang.dark_mode;
      case ThemeType.auto:
        return lang.auto_mode;
      default:
        return lang.light_mode;
    }
  }

  String sub(LangModel lang) {
    switch (type) {
      case ThemeType.light:
        return lang.light_mode_sub;
      case ThemeType.dark:
        return lang.dark_mode_sub;
      case ThemeType.auto:
        return lang.auto_mode_sub;
      default:
        return lang.light_mode_sub;
    }
  }
}
