import 'package:client_1/constants/colors.dart';
import 'package:client_1/constants/image.dart';
import 'package:client_1/constants/widget.dart';
import 'package:client_1/functions/connectivity_check.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/provider/dammam_units_pro/dammam_units_pro.dart';
import 'package:client_1/provider/jeddah_units_pro/jeddah_units_pro.dart';
import 'package:client_1/provider/riyadh_units_pro/riyadh_units_pro.dart';
import 'package:client_1/provider/store_pro/store_pro.dart';
import 'package:client_1/screen/home_screen/widgets/product_card_shimner.dart';
import 'package:client_1/screen/my_storage_screen/my_storage_screen.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/cus_tab.dart';
import 'package:client_1/widgets/range_filed.dart';
import 'package:client_1/widgets/search_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../constants/sized_box.dart';
import '../../provider/lang_pro/lang_pro.dart';
import '../home_screen/widgets/home_top.dart';
import '../home_screen/widgets/product_card.dart';

class StoreScreen extends StatelessWidget {
  const StoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          backgroundColor: MyColor.refreshColor,
          onRefresh: () {
            return Future.wait([
              context.read<JeddahUnitsPro>().getProduct(),
              context.read<RiyadhUnitsPro>().getProduct(),
              context.read<DammamUnitsPro>().getProduct(),
            ]);
          },
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: Column(
              children: [
                const HomeTop(),
                sizedBoxH40,
                Consumer<StorePro>(
                  builder: (_, v, w) {
                    return CusTab(
                      data: [
                        (lang.jeddah, 0),
                        (lang.riyadh, 1),
                        (lang.dammam, 2),
                      ],
                      selected: v.selected,
                      onTap: (i) {
                        context.read<JeddahUnitsPro>().node.unfocus();
                        context.read<DammamUnitsPro>().node.unfocus();
                        context.read<RiyadhUnitsPro>().node.unfocus();
                        v.changeSelected(i);
                      },
                    );
                  },
                ),
                sizedBoxH20,
                Consumer<StorePro>(
                  builder: (_, v, w) {
                    if (v.selected == 0) return const JeddahStore();
                    if (v.selected == 1) return const RiyadhStore();
                    return const DammmamStore();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class JeddahStore extends StatelessWidget {
  const JeddahStore({super.key});

  @override
  Widget build(BuildContext context) {
    var pro = context.read<JeddahUnitsPro>();
    var controller = pro.controller;
    var node = pro.node;
    //830
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            Expanded(
              child: SearchText(
                controller: controller,
                node: node,
                onChanged: (_) => pro.searchUpdate(),
              ),
            ),
            Selector<JeddahUnitsPro, bool>(
              selector: (_, v) => v.haveFilter,
              builder: (_, v, w) {
                return SearchRangeButton(
                  haveFilter: v,
                  child: Consumer<JeddahUnitsPro>(
                    builder: (_, v, w) {
                      return RangeFiled(
                        maxPrice: 5900,
                        maxSize: 29,
                        sheet: true,
                        haveFilter: v.haveFilter,
                        price: v.priceRange ?? const RangeValues(0, 5900),
                        size: v.sizeRange ?? const RangeValues(0, 29),
                        priceChange: (r) => v.setPriceRange(r),
                        sizeChange: (r) => v.setSizeeRange(r),
                        clear: () => v.clearRange(),
                      );
                    },
                  ),
                );
              },
            )
          ],
        ),
        sizedBoxH10,
        Consumer<JeddahUnitsPro>(
          builder: (_, v, w) {
            return RangeFiled(
              maxPrice: 5900,
              maxSize: 29,
              haveFilter: v.haveFilter,
              price: v.priceRange ?? const RangeValues(0, 5900),
              size: v.sizeRange ?? const RangeValues(0, 29),
              priceChange: (r) => v.setPriceRange(r),
              sizeChange: (r) => v.setSizeeRange(r),
              clear: () => v.clearRange(),
            );
          },
        ),
        Consumer<JeddahUnitsPro>(
          builder: (_, v, w) {
            var product = v.products;
            var loading = v.loading;
            var hasError = v.hasError;

            if (loading) {
              return const StoreScreenLoader();
            } else if (hasError) {
              return SizedBox(
                height: MediaQuery.sizeOf(context).height / 1.6,
                child: StoreErrorScreen(
                  onTap: () async {
                    var connectCheck = getIt<ConnectivityCheck>();
                    var network = await connectCheck.getCurrentState();
                    if (!network) return;
                    v.getProduct();
                  },
                ),
              );
            } else if (product.isEmpty) {
              return SizedBox(
                height: MediaQuery.sizeOf(context).height / 1.6,
                child: const Center(child: MyStorageNoData()),
              );
            } else {
              return GridView.builder(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                padding: const EdgeInsets.symmetric(vertical: 10),
                gridDelegate: extent,
                itemCount: product.length,
                itemBuilder: (_, int i) {
                  return ProductCard(model: product[i]);
                },
              );
            }
          },
        ),
      ],
    );
  }
}

class DammmamStore extends StatelessWidget {
  const DammmamStore({super.key});

  @override
  Widget build(BuildContext context) {
    var pro = context.read<DammamUnitsPro>();
    var controller = pro.controller;
    var node = pro.node;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            Expanded(
              child: SearchText(
                controller: controller,
                node: node,
                onChanged: (_) => pro.searchUpdate(),
              ),
            ),
            Selector<DammamUnitsPro, bool>(
              selector: (_, v) => v.haveFilter,
              builder: (_, v, w) {
                return SearchRangeButton(
                  haveFilter: v,
                  child: Consumer<DammamUnitsPro>(
                    builder: (_, v, w) {
                      return RangeFiled(
                        maxPrice: 5900,
                        maxSize: 29,
                        sheet: true,
                        haveFilter: v.haveFilter,
                        price: v.priceRange ?? const RangeValues(0, 5900),
                        size: v.sizeRange ?? const RangeValues(0, 29),
                        priceChange: (r) => v.setPriceRange(r),
                        sizeChange: (r) => v.setSizeeRange(r),
                        clear: () => v.clearRange(),
                      );
                    },
                  ),
                );
              },
            )
          ],
        ),
        sizedBoxH10,
        Consumer<DammamUnitsPro>(
          builder: (_, v, w) {
            return RangeFiled(
              maxPrice: 5900,
              maxSize: 29,
              haveFilter: v.haveFilter,
              price: v.priceRange ?? const RangeValues(0, 5900),
              size: v.sizeRange ?? const RangeValues(0, 29),
              priceChange: (r) => v.setPriceRange(r),
              sizeChange: (r) => v.setSizeeRange(r),
              clear: () => v.clearRange(),
            );
          },
        ),
        Consumer<DammamUnitsPro>(
          builder: (_, v, w) {
            var product = v.products;
            var loading = v.loading;
            var hasError = v.hasError;
            if (loading) {
              return const StoreScreenLoader();
            } else if (hasError) {
              return SizedBox(
                height: MediaQuery.sizeOf(context).height / 1.6,
                child: StoreErrorScreen(
                  onTap: () async {
                    var connectCheck = getIt<ConnectivityCheck>();
                    var network = await connectCheck.getCurrentState();
                    if (!network) return;
                    v.getProduct();
                  },
                ),
              );
            } else if (product.isEmpty) {
              return SizedBox(
                height: MediaQuery.sizeOf(context).height / 1.6,
                child: const Center(child: MyStorageNoData()),
              );
            } else {
              return GridView.builder(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                padding: const EdgeInsets.symmetric(vertical: 10),
                gridDelegate: extent,
                itemCount: product.length,
                itemBuilder: (_, int i) {
                  return ProductCard(model: product[i]);
                },
              );
            }
          },
        ),
      ],
    );
  }
}

class RiyadhStore extends StatelessWidget {
  const RiyadhStore({super.key});

  @override
  Widget build(BuildContext context) {
    var pro = context.read<RiyadhUnitsPro>();
    var controller = pro.controller;
    var node = pro.node;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            Expanded(
              child: SearchText(
                controller: controller,
                node: node,
                onChanged: (_) => pro.searchUpdate(),
              ),
            ),
            Selector<RiyadhUnitsPro, bool>(
              selector: (_, v) => v.haveFilter,
              builder: (_, v, w) {
                return SearchRangeButton(
                  haveFilter: v,
                  child: Consumer<RiyadhUnitsPro>(
                    builder: (_, v, w) {
                      return RangeFiled(
                        maxPrice: 5900,
                        maxSize: 29,
                        sheet: true,
                        haveFilter: v.haveFilter,
                        price: v.priceRange ?? const RangeValues(0, 5900),
                        size: v.sizeRange ?? const RangeValues(0, 29),
                        priceChange: (r) => v.setPriceRange(r),
                        sizeChange: (r) => v.setSizeeRange(r),
                        clear: () => v.clearRange(),
                      );
                    },
                  ),
                );
              },
            )
          ],
        ),
        sizedBoxH10,
        Consumer<RiyadhUnitsPro>(
          builder: (_, v, w) {
            return RangeFiled(
              maxPrice: 5900,
              maxSize: 29,
              haveFilter: v.haveFilter,
              price: v.priceRange ?? const RangeValues(0, 5900),
              size: v.sizeRange ?? const RangeValues(0, 29),
              priceChange: (r) => v.setPriceRange(r),
              sizeChange: (r) => v.setSizeeRange(r),
              clear: () => v.clearRange(),
            );
          },
        ),
        Consumer<RiyadhUnitsPro>(
          builder: (_, v, w) {
            var product = v.products;
            var loading = v.loading;
            var hasError = v.hasError;

            if (loading) {
              return const StoreScreenLoader();
            } else if (hasError) {
              return SizedBox(
                height: MediaQuery.sizeOf(context).height / 1.6,
                child: StoreErrorScreen(
                  onTap: () async {
                    var connectCheck = getIt<ConnectivityCheck>();
                    var network = await connectCheck.getCurrentState();
                    if (!network) return;
                    v.getProduct();
                  },
                ),
              );
            } else if (product.isEmpty) {
              return SizedBox(
                height: MediaQuery.sizeOf(context).height / 1.6,
                child: const Center(child: MyStorageNoData()),
              );
            } else {
              return GridView.builder(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                padding: const EdgeInsets.symmetric(vertical: 10),
                gridDelegate: extent,
                itemCount: product.length,
                itemBuilder: (_, int i) {
                  return ProductCard(model: product[i]);
                },
              );
            }
          },
        ),
      ],
    );
  }
}

class StoreErrorScreen extends StatelessWidget {
  final Function onTap;
  final String? sub;
  const StoreErrorScreen({
    super.key,
    required this.onTap,
    this.sub,
  });

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Center(
          child: AppImage(
            image: MyImage.error,
            height: MediaQuery.of(context).size.height / 3.5,
            width: MediaQuery.of(context).size.height / 3.5,
          ),
        ),
        sizedBoxH20,
        if (sub != null && sub!.isNotEmpty)
          AppText(
            sub!,
            fontWeight: FontWeight.bold,
            fontSize: 16.spMin,
            maxLines: 3,
          ),
        AppText(lang.something_went_wrong),
        sizedBoxH10,
        AppButton(
          width: 90.w,
          height: 40.h,
          fontSize: 12,
          borderRadius: BorderRadius.circular(8.r),
          fontWeight: FontWeight.bold,
          text: lang.retry,
          onPressed: () => onTap(),
        ),
      ],
    );
  }
}

class StoreScreenLoader extends StatelessWidget {
  const StoreScreenLoader({super.key});

  @override
  Widget build(BuildContext context) {
    const extent = SliverGridDelegateWithMaxCrossAxisExtent(
      crossAxisSpacing: 10.0,
      mainAxisSpacing: 10.0,
      mainAxisExtent: 260,
      maxCrossAxisExtent: 260,
    );
    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      padding: const EdgeInsets.symmetric(vertical: 10),
      gridDelegate: extent,
      itemCount: 10,
      itemBuilder: (BuildContext context, int index) {
        return const ProductCardShimner();
      },
    );
  }
}
