import 'dart:typed_data';

import 'package:client_1/constants/api.dart';
import 'package:client_1/constants/image.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/model/invoice_model/invoice_model.dart';
import 'package:client_1/provider/checkout_pro.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/screen/add_cart_dialog/add_cart_dialog.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/cus_app_bar.dart';
import 'package:client_1/widgets/loader.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:provider/provider.dart';
import 'package:universal_platform/universal_platform.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../constants/colors.dart';
import '../../../widgets/app_image.dart';

class InvoiceCard extends StatelessWidget {
  final InvoiceModel invoice;
  const InvoiceCard({super.key, required this.invoice});

  @override
  Widget build(BuildContext context) {
    var container = Container(
      height: 105,
      margin: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: context.read<ThemePro>().cardColor,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade900.withOpacity(0.1),
            spreadRadius: -1,
            offset: const Offset(0, 4),
            blurRadius: 20,
          )
        ],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Container(
            width: 90,
            margin: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: context.read<ThemePro>().grey.withOpacity(0.5),
              borderRadius: BorderRadius.circular(8),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: AppImage(
                image: API.baseUrl + invoice.image,
                fit: BoxFit.cover,
                height: double.infinity,
                width: double.infinity,
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Flexible(
                        child: AppText(
                          invoice.name,
                          maxLines: 2,
                          fontSize: 14.spMin,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      // sizedBoxW20,
                      // AppText(
                      //   "12 M²",
                      //   fontSize: 14.spMin,
                      //   fontWeight: FontWeight.w400,
                      // ),
                    ],
                  ),
                  const Spacer(),
                  // Row(
                  //   crossAxisAlignment: CrossAxisAlignment.start,
                  //   children: [
                  //     Transform.translate(
                  //       offset: const Offset(0, 2),
                  //       child: AppImage(
                  //         image: MyImage.location,
                  //         color: MyColor.grey,
                  //         height: 12.spMin,
                  //       ),
                  //     ),
                  //     sizedBoxW5,
                  //     Expanded(
                  //       child: AppText(
                  //         "Dammam",
                  //         fontSize: 12.spMin,
                  //         fontWeight: FontWeight.w400,
                  //         color: MyColor.grey,
                  //       ),
                  //     ),
                  //   ],
                  // ),

                  const Spacer(flex: 5),
                  AppText(
                    "${invoice.price} SAR ",
                    // text2: "Monthly",
                    fontSize: 14.spMin,
                    color: MyColor.primary,
                    fontWeight: FontWeight.w700,
                    fontWeight2: FontWeight.w500,
                    fontSize2: 10.spMin,
                  )
                ],
              ),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              AppText(
                // "20/10/2023 11:30 AM",
                DateFormat("dd/MM/yyyy").format(invoice.date),
                fontSize: 10.spMin,
                color: MyColor.grey,
              ),
              sizedBoxH5,
              Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  if (invoice.status == "paid")
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: AppImage(
                        image: MyImage.eye,
                      ),
                    ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 15,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(22.r),
                    ),
                    child: AppText(
                      invoice.status.capFirst(),
                      fontWeight: FontWeight.w500,
                      fontSize: 12.spMin,
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                ],
              ),
              sizedBoxH10,
            ],
          ),
          sizedBoxW10,
        ],
      ),
    );
    return invoice.status == "paid"
        ? GestureDetector(
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) {
                    return InvoicePDF(invoice: invoice);
                  },
                ),
              );
            },
            child: container,
          )
        : GestureDetector(
            onTap: () async {
              var link =
                  '${API.baseUrl}mobile/cart/${invoice.reservation_id}/${invoice.contract_id}';
              if (UniversalPlatform.isIOS) {
                var uri = Uri.parse(link);
                await launchUrl(uri);
              } else {
                var checkout = context.read<CheckoutPro>();
                checkout.init(
                  reservation_id: invoice.reservation_id.toString(),
                  contract_id: invoice.contract_id.toString(),
                  price: invoice.price,
                );
              }
            },
            child: container,
          );
  }
}

class InvoicePDF extends StatefulWidget {
  const InvoicePDF({
    super.key,
    required this.invoice,
  });

  final InvoiceModel invoice;

  @override
  State<InvoicePDF> createState() => _InvoicePDFState();
}

class _InvoicePDFState extends State<InvoicePDF> {
  Uint8List? data;

  @override
  void initState() {
    init();
    super.initState();
  }

  Future<void> init() async {
    var dio = Dio();
    var res = await dio.get(
      widget.invoice.invoice_url,
      options: Options(responseType: ResponseType.bytes),
    );
    setState(() {
      data = Uint8List.fromList(res.data);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const CusAppbar(title: ""),
          data == null
              ? const Expanded(child: Loader(loaderOnly: true))
              : Expanded(
                  child: PdfViewer.data(
                    data!,
                    sourceName: "",
                  ),
                ),
        ],
      ),
    );
  }
}
