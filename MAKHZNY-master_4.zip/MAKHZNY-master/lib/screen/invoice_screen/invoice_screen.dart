import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/functions/connectivity_check.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/model/invoice_model/invoice_model.dart';
import 'package:client_1/provider/checkout_pro.dart';
import 'package:client_1/provider/invoice_pro/invoice_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/screen/my_storage_screen/my_storage_screen.dart';
import 'package:client_1/screen/store_screen/store_screen.dart';
import 'package:client_1/widgets/container_shimner.dart';
import 'package:client_1/widgets/cus_tab.dart';
import 'package:client_1/widgets/loader.dart';
import 'package:client_1/widgets/product_cart_vert_shimner.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../constants/colors.dart';
import '../../widgets/cus_app_bar.dart';
import '../../widgets/search_text.dart';
import 'widgets/invoice_card.dart';

class InvoiceScreen extends StatelessWidget {
  const InvoiceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          backgroundColor: MyColor.refreshColor,
          onRefresh: () {
            return context.read<InvoicePro>().getInvoices();
          },
          child: Consumer<CheckoutPro>(
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              child: Column(
                children: [
                  sizedBoxH20,
                  CusAppbar(title: lang.invoices),
                  sizedBoxH30,
                  Consumer<InvoicePro>(
                    builder: (_, v, w) {
                      return CusTab(
                        data: [
                          (lang.paid, 0),
                          (lang.unpaid, 1),
                          (lang.rejected, 2),
                        ],
                        selected: v.selected,
                        onTap: (i) {
                          context.read<InvoicePro>().paidNode.unfocus();
                          context.read<InvoicePro>().unpaidNode.unfocus();
                          context.read<InvoicePro>().rejectedNode.unfocus();
                          v.changeSelected(i);
                        },
                      );
                    },
                  ),
                  sizedBoxH20,
                  Consumer<InvoicePro>(
                    builder: (_, v, w) {
                      var con = getController(v);
                      var controller = con.$1;
                      var node = con.$2;
                      var data = getData(v);
                      return InvoiceChild(
                        controller: controller,
                        model: data,
                        hasError: v.hasError,
                        loading: v.loading,
                        node: node,
                      );
                    },
                  )
                  // InvoiceLoader()
                  // const SearchText(),
                  // sizedBoxH10,
                  // ListView.builder(
                  //   shrinkWrap: true,
                  //   padding:
                  //       const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                  //   physics: const NeverScrollableScrollPhysics(),
                  //   itemCount: 10,
                  //   itemBuilder: (_, i) {
                  //     return const InvoiceCard();
                  //   },
                  // )
                ],
              ),
            ),
            builder: (_, v, w) {
              return PopScope(
                canPop: !v.loading,
                child: Stack(
                  children: [
                    w!,
                    if (v.loading) const Loader(),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  (TextEditingController, FocusNode) getController(InvoicePro i) {
    switch (i.selected) {
      case 0:
        return (i.paidController, i.paidNode);
      case 1:
        return (i.unpaidController, i.unpaidNode);
      case 2:
        return (i.rejectedController, i.rejectedNode);
      default:
        return (i.paidController, i.paidNode);
    }
  }

  List<InvoiceModel> getData(InvoicePro i) {
    switch (i.selected) {
      case 0:
        return (i.paid);
      case 1:
        return (i.unpaid);
      case 2:
        return (i.rejected);
      default:
        return (i.paid);
    }
  }
}

class InvoiceChild extends StatelessWidget {
  final TextEditingController controller;
  final List<InvoiceModel> model;
  final bool hasError;
  final bool loading;
  final FocusNode node;
  const InvoiceChild({
    super.key,
    required this.controller,
    required this.model,
    required this.hasError,
    required this.loading,
    required this.node,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const InvoiceLoader();
    } else if (hasError) {
      return SizedBox(
        height: MediaQuery.sizeOf(context).height / 1.6,
        child: StoreErrorScreen(
          onTap: () async {
            var connectCheck = getIt<ConnectivityCheck>();
            var network = await connectCheck.getCurrentState();
            if (!network) return;
            // ignore: use_build_context_synchronously
            context.read<InvoicePro>().getInvoices();
          },
        ),
      );
    } else {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SearchText(
            controller: controller,
            node: node,
            onChanged: (_) => context.read<InvoicePro>().searchUpdate(),
          ),
          sizedBoxH10,
          if (model.isEmpty)
            SizedBox(
              height: MediaQuery.sizeOf(context).height / 1.6,
              child: const Center(child: MyStorageNoData()),
            ),
          if (model.isNotEmpty)
            ListView.builder(
              shrinkWrap: true,
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
              physics: const NeverScrollableScrollPhysics(),
              itemCount: model.length,
              itemBuilder: (_, i) {
                return InvoiceCard(invoice: model[i]);
              },
            )
        ],
      );
    }
  }
}

class InvoiceLoader extends StatelessWidget {
  const InvoiceLoader({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        ContainerShimner(
          width: double.infinity,
          margin: const EdgeInsets.symmetric(horizontal: 15),
          height: 45,
          borderRadius: BorderRadius.circular(8),
        ),
        sizedBoxH10,
        ListView.builder(
          shrinkWrap: true,
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          physics: const NeverScrollableScrollPhysics(),
          itemCount: 10,
          itemBuilder: (_, i) {
            return const ProductCardVertShimner();
          },
        )
      ],
    );
  }
}
