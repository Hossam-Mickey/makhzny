import 'package:client_1/constants/colors.dart';
import 'package:client_1/provider/document_pro/document_pro.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../constants/image.dart';
import '../../constants/sized_box.dart';
import '../../provider/lang_pro/lang_pro.dart';
import '../../route.dart';
import '../../widgets/app_image.dart';
import '../../widgets/cus_app_bar.dart';
import 'widgets/document_add_dialog.dart';
import 'widgets/document_child.dart';

class DocumentScreen extends StatelessWidget {
  const DocumentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        systemNavigationBarColor: Theme.of(context).scaffoldBackgroundColor,
      ),
      child: Scaffold(
        body: SafeArea(
          child: RefreshIndicator(
            backgroundColor: MyColor.refreshColor,
            onRefresh: () {
              return context.read<DocumentPro>().getUploaded();
            },
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              child: Column(
                children: [
                  sizedBoxH20,
                  CusAppbar(
                    title: lang.documents,
                    sideChild: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: IconButton(
                        onPressed: () {
                          if (context.read<DocumentPro>().loading) return;
                          showModalBottomSheet(
                            context: navigatorKey.currentContext!,
                            useSafeArea: false,
                            isScrollControlled: true,
                            isDismissible: false,
                            enableDrag: false,
                            backgroundColor: Colors.transparent,
                            builder: (_) {
                              return DocumentAddDialog(dialogContext: _);
                            },
                          );
                        },
                        icon: AppImage(
                          image: MyImage.add,
                          height: 15,
                          color: Theme.of(context).primaryColor,
                        ),
                      ),
                    ),
                  ),
                  sizedBoxH30,
                  const DocumentChild(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
