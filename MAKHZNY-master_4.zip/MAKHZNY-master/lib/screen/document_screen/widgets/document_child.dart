import 'package:client_1/functions/blur_bottom_sheet.dart';
import 'package:client_1/functions/connectivity_check.dart';
import 'package:client_1/functions/platform/download_file.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/model/document_model/document_model.dart';
import 'package:client_1/model/download_model/download_model.dart';
import 'package:client_1/provider/doc_delete_pro/doc_delete_pro.dart';
import 'package:client_1/provider/document_pro/document_pro.dart';
import 'package:client_1/provider/download_pro.dart';
import 'package:client_1/route.dart';
import 'package:client_1/screen/my_storage_screen/my_storage_screen.dart';
import 'package:client_1/screen/store_screen/store_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:universal_platform/universal_platform.dart';

import '../../../provider/lang_pro/lang_pro.dart';
import '../../../widgets/search_text.dart';
import 'document_card.dart';
import 'document_loader.dart';

class DocumentChild extends StatelessWidget {
  const DocumentChild({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return Consumer<DocumentPro>(
      builder: (_, v, w) {
        if (v.loading) {
          return const DocumentLoader();
        } else if (v.hasError) {
          return SizedBox(
            height: MediaQuery.sizeOf(context).height / 1.45,
            child: StoreErrorScreen(
              onTap: () async {
                var connectCheck = getIt<ConnectivityCheck>();
                var network = await connectCheck.getCurrentState();
                if (!network) return;
                v.getUploaded();
              },
            ),
          );
        } else {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SearchText(
                controller: v.controller,
                node: v.node,
                onChanged: (_) => v.searchUpdate(),
              ),
              if (v.uploaded.isEmpty)
                SizedBox(
                  height: MediaQuery.sizeOf(context).height / 1.5,
                  child: const Center(child: MyStorageNoData()),
                ),
              if (v.uploaded.isNotEmpty)
                Consumer<DownloadPro>(
                  builder: (_, dpro, w) {
                    return ListView.builder(
                      shrinkWrap: true,
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: v.uploaded.length,
                      itemBuilder: (_, i) {
                        var docModel = v.uploaded[i];

                        String link = docModel.urlWithBase;

                        var downloadModel = dpro.getByUrl(link);
                        return DocumentCard(
                          downloadModel: downloadModel,
                          docModel: docModel,
                          onTap: () => onView(downloadModel, docModel),
                          onView: () => onView(downloadModel, docModel),
                          onDelete: () {
                            blurBottomSheet(
                              title: lang.are_you_sure_delete_doc,
                              onTap: (cxt) {
                                Navigator.pop(cxt);
                                context.read<DocDeletePro>().delete(docModel);
                              },
                              continueText: lang.yes,
                            );
                          },
                        );
                      },
                    );
                  },
                ),
            ],
          );
        }
      },
    );
  }

  Future<void> onView(
    DownloadModel? downloadModel,
    DocumentModel docModel,
  ) async {
    var context = navigatorKey.currentContext!;
    var dpro = context.read<DownloadPro>();
    if (UniversalPlatform.isWeb) {
      await DownloadFile.download(docModel.urlWithBase, docModel.name);
      return;
    }
    var link = docModel.urlWithBase;
    var status = downloadModel?.status.value;
    if (downloadModel == null) {
      var fileName = "${docModel.name}-${docModel.id}";
      dpro.dowload(fileName: fileName, link: link);
    } else if (status == DownloadStatus.failed ||
        status == DownloadStatus.pause) {
      dpro.resume(downloadModel.id);
    } else if (status == DownloadStatus.completed) {
      dpro.open(downloadModel);
    }
  }
}
