import 'package:client_1/constants/colors.dart';
import 'package:client_1/model/document_model/document_model.dart';
import 'package:client_1/model/download_model/download_model.dart';
import 'package:client_1/provider/doc_delete_pro/doc_delete_pro.dart';
import 'package:client_1/provider/download_pro.dart';
import 'package:client_1/widgets/loader.dart';
import 'package:client_1/widgets/mouse_cursor.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../constants/image.dart';
import '../../../constants/sized_box.dart';
import '../../../provider/theme_pro/theme_pro.dart';
import '../../../widgets/app_image.dart';
import '../../../widgets/app_text.dart';

class DocumentCard extends StatelessWidget {
  final Function onView;
  final Function onDelete;
  final Function onTap;
  final DownloadModel? downloadModel;
  final DocumentModel docModel;
  const DocumentCard({
    super.key,
    required this.onView,
    required this.onDelete,
    required this.onTap,
    this.downloadModel,
    required this.docModel,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onTap(),
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          children: [
            Container(
              height: 45.h,
              decoration: BoxDecoration(
                color: context.read<ThemePro>().cardColor,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.shade900.withOpacity(0.5),
                    spreadRadius: -10,
                    offset: const Offset(0, 4),
                    blurRadius: 20,
                  )
                ],
                borderRadius: BorderRadius.circular(6.r),
              ),
              child: Row(
                children: [
                  sizedBoxW20,
                  Expanded(
                    child: AppText(
                      docModel.name,
                      fontWeight: FontWeight.w500,
                      fontSize: 14.spMin,
                      maxLines: 2,
                    ),
                  ),
                  GestureDetector(
                    onTap: () => onView(),
                    child: CusMouseCursor(
                      child: Container(
                        color: Colors.transparent,
                        padding: const EdgeInsets.all(8),
                        child: AppImage(
                          image: MyImage.eye,
                          color: Theme.of(context).primaryColor,
                          height: 15.spMin,
                        ),
                      ),
                    ),
                  ),
                  sizedBoxW10,
                  sizedBoxW5,
                  Opacity(
                    opacity: docModel.can_delete ? 1 : 0.5,
                    child: IgnorePointer(
                      ignoring: !docModel.can_delete,
                      child: Consumer<DocDeletePro>(
                        builder: (_, v, w) {
                          var isDark =
                              Theme.of(context).brightness == Brightness.dark;
                          return v.ids.contains(docModel.id)
                              ? Padding(
                                  padding: const EdgeInsets.only(left: 8),
                                  child: SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: Loader(
                                      loaderOnly: true,
                                      stock: 2.5,
                                      color: isDark
                                          ? Colors.grey.shade300
                                          : Colors.grey.shade700,
                                    ),
                                  ),
                                )
                              : GestureDetector(
                                  onTap: () => onDelete(),
                                  child: Container(
                                    color: Colors.transparent,
                                    padding: const EdgeInsets.all(8),
                                    child: AppImage(
                                      image: MyImage.delete,
                                      color: MyColor.primary,
                                      height: 15.spMin,
                                    ),
                                  ),
                                )
                                  .animate(target: docModel.can_delete ? 0 : 1)
                                  .desaturate();
                        },
                      ),
                    ),
                  ),
                  sizedBoxW20,
                ],
              ),
            ),
            Consumer<DownloadPro>(
              builder: (_, v, w) {
                if (v.loadingIds.contains(docModel.urlWithBase)) {
                  return LinearProgressIndicator(
                    borderRadius: BorderRadius.circular(90),
                  );
                }
                if (downloadModel == null) return const SizedBox();

                return ValueListenableBuilder(
                  valueListenable: downloadModel!.status,
                  child: ValueListenableBuilder(
                    valueListenable: downloadModel!.progress,
                    builder: (_, p, c) {
                      return LinearProgressIndicator(
                        value: p / 100,
                        borderRadius: BorderRadius.circular(90),
                      );
                    },
                  ),
                  builder: (_, s, w) {
                    if (s == DownloadStatus.running ||
                        s == DownloadStatus.processing) return w!;
                    return const SizedBox();
                  },
                );
              },
            )
          ],
        ),
      ),
    );
  }
}
