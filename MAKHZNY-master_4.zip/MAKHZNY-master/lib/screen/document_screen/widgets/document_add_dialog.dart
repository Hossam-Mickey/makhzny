import 'package:client_1/constants/colors.dart';
import 'package:client_1/functions/blur_bottom_sheet.dart';
import 'package:client_1/provider/document_pro/document_pro.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/route.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:universal_platform/universal_platform.dart';

import '../../../constants/sized_box.dart';
import '../../../provider/lang_pro/lang_pro.dart';

class DocumentAddDialog extends StatelessWidget {
  final BuildContext dialogContext;
  final bool? clear;
  const DocumentAddDialog({super.key, required this.dialogContext, this.clear});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    var grey = context.read<ThemePro>().grey;
    var fontColor = Theme.of(context).primaryColor;

    return Stack(
      children: [
        const BlurDialogBg(),
        Align(
          alignment: Alignment.bottomCenter,
          child: SafeArea(
            child: Container(
              // height: 400.h,
              margin: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AppButton(
                    text: lang.add_document,
                    height: 50.h < 40 ? 40 : 50.h,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(14.r),
                      topRight: Radius.circular(14.r),
                    ),
                    padding: EdgeInsets.zero,
                    margin: EdgeInsets.zero,
                    onPressed: () {},
                    fontColor: grey,
                    fontWeight: FontWeight.w500,
                    fontSize: 14.spMin,
                    buttonColor: Theme.of(context).scaffoldBackgroundColor,
                  ),
                  Container(
                    height: 1.5,
                    width: double.infinity,
                    color: grey,
                  ),
                  AppButton(
                    text: lang.upload_from_phone,
                    height: 50.h < 40 ? 40 : 50.h,
                    onPressed: () {
                      Navigator.pop(context);
                      var loc = GoRouter.of(context).location();
                      var c = clear ?? loc == "/settings/documents";
                      context.read<DocumentPro>().pickDocs(c);
                    },
                    fontColor: fontColor,
                    fontWeight: FontWeight.w500,
                    fontSize: 16.spMin,
                    buttonColor: Theme.of(context).scaffoldBackgroundColor,
                  ),
                  if (UniversalPlatform.isAndroid) ...[
                    Container(
                      height: 1.5,
                      width: double.infinity,
                      color: grey,
                    ),
                    AppButton(
                      text: lang.open_pdf_scanner,
                      height: 50.h < 40 ? 40 : 50.h,
                      onPressed: () {
                        Navigator.pop(context);
                        var loc = GoRouter.of(context).location();
                        var c = clear ?? loc == "/settings/documents";
                        context.read<DocumentPro>().pickDocScanner(c);
                      },
                      fontColor: fontColor,
                      fontWeight: FontWeight.w500,
                      fontSize: 16.spMin,
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(14.r),
                        bottomRight: Radius.circular(14.r),
                      ),
                      buttonColor: Theme.of(context).scaffoldBackgroundColor,
                    ),
                  ],
                  sizedBoxH20H,
                  AppButton(
                    text: lang.cancel,
                    height: 50.h < 40 ? 40 : 50.h,
                    onPressed: () => Navigator.pop(dialogContext),
                    fontColor: MyColor.primary,
                    fontWeight: FontWeight.w500,
                    fontSize: 16.spMin,
                    borderRadius: BorderRadius.circular(14.r),
                    buttonColor: Theme.of(context).scaffoldBackgroundColor,
                  ),
                ],
              ),
            ),
          ),
        )
      ],
    );
  }
}
