import 'package:client_1/widgets/container_shimner.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class DocumentLoader extends StatelessWidget {
  const DocumentLoader({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        ContainerShimner(
          width: double.infinity,
          margin: const EdgeInsets.symmetric(horizontal: 15),
          height: 45,
          borderRadius: BorderRadius.circular(8),
        ),
        ListView.builder(
          shrinkWrap: true,
          padding: const EdgeInsets.symmetric(vertical: 10),
          physics: const NeverScrollableScrollPhysics(),
          itemCount: 10,
          itemBuilder: (_, i) {
            return ContainerShimner(
              width: double.infinity,
              height: 45.h,
              margin: const EdgeInsets.all(15),
              borderRadius: BorderRadius.circular(6.r),
            );
          },
        )
      ],
    );
  }
}
