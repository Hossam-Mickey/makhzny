
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/cus_app_bar.dart';
import 'package:client_1/widgets/rtl_layout.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:pdfrx/pdfrx.dart';
import 'package:provider/provider.dart';

import 'package:printing/printing.dart';

class TermsConditionScreen extends StatelessWidget {
  const TermsConditionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var bgColor = context.read<ThemePro>().light.scaffoldBackgroundColor;
    var path = context.read<LangPro>().type == LangType.ar
        ? "assets/doc/arabic.pdf"
        : "assets/doc/english.pdf";
    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: Column(
          children: [
            sizedBoxH10,
            RTLLayout(
              child: CusAppbar(
                title: "Terms & Conditions",
                color: Colors.black,
                sideChild: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: InkWell(
                    onTap: () async {
                      var load = await rootBundle.load(path);
                      await Printing.layoutPdf(
                        name: "Terms & Conditions",
                        onLayout: (_) => Uint8List.view(load.buffer),
                      );
                    },
                    child: Container(
                      color: Colors.transparent,
                      padding: const EdgeInsets.all(5),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.print_outlined,
                            color: const Color.fromARGB(255, 28, 96, 151),
                            size: 19.spMin,
                          ),
                          sizedBoxW5,
                          AppText(
                            "Print",
                            fontSize: 16.spMin,
                            fontWeight: FontWeight.w600,
                            color: const Color.fromARGB(255, 28, 96, 151),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            sizedBoxH10,
            Expanded(
              child: PdfViewer.asset(
                path,
                params: PdfViewerParams(
                  backgroundColor: bgColor,
                  pageDropShadow: const BoxShadow(),
                  minScale: 2,
                  margin: 0,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
