// ignore_for_file: use_build_context_synchronously

import 'package:client_1/constants/colors.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/functions/blur_bottom_sheet.dart';
import 'package:client_1/main.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/quote_pro.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/mouse_cursor.dart';
import 'package:client_1/widgets/search_text.dart';
import 'package:easy_stepper/easy_stepper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

class QuoteScreen extends StatelessWidget {
  const QuoteScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    bool isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                color: MyColor.btnColor,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AppText(
                      lang.request_quote.firstLetterCap(),
                      fontWeight: FontWeight.bold,
                      fontSize: 20.spMin,
                      color: Colors.white,
                    ),
                    sizedBoxH5,
                    AppText(
                      lang.request_quote_sub,
                      fontWeight: FontWeight.bold,
                      fontSize: 14.spMin,
                      maxLines: 5,
                      color: Colors.grey.shade400,
                    ),
                  ],
                ),
              ),
              sizedBoxH20,
              Selector<QuotePro, int>(
                selector: (_, v) => v.page,
                builder: (_, v, w) {
                  return EasyStepper(
                    activeStep: v,
                    internalPadding: 20,
                    showLoadingAnimation: false,
                    finishedStepBackgroundColor:
                        MyColor.primary.withOpacity(0.8),
                    activeStepBackgroundColor:
                        isDark ? Colors.grey.shade800 : Colors.grey.shade400,
                    activeStepBorderColor: Colors.grey,
                    unreachedStepBorderType: BorderType.normal,
                    activeStepBorderType: BorderType.normal,
                    stepRadius: 35.wMin,
                    unreachedStepBackgroundColor:
                        isDark ? Colors.grey.shade800 : Colors.grey.shade400,
                    enableStepTapping: false,
                    steps: [
                      EasyStep(
                        customStep: AppText(
                          "1",
                          fontWeight: FontWeight.bold,
                          fontSize: 16.spMin,
                          color: Colors.white,
                        ),
                        customTitle: AppText(
                          lang.choose_branch,
                          textAlign: TextAlign.center,
                          fontWeight: FontWeight.bold,
                          fontSize: 10.spMin,
                        ),
                      ),
                      EasyStep(
                        customStep: AppText(
                          "2",
                          fontWeight: FontWeight.bold,
                          fontSize: 16.spMin,
                          color: Colors.white,
                        ),
                        customTitle: AppText(
                          lang.choose_area,
                          textAlign: TextAlign.center,
                          fontWeight: FontWeight.bold,
                          fontSize: 10.spMin,
                        ),
                      ),
                      EasyStep(
                        customStep: AppText(
                          "3",
                          fontWeight: FontWeight.bold,
                          fontSize: 16.spMin,
                          color: Colors.white,
                        ),
                        customTitle: AppText(
                          lang.receiving_method,
                          textAlign: TextAlign.center,
                          fontWeight: FontWeight.bold,
                          fontSize: 10.spMin,
                        ),
                      ),
                    ],
                  );
                },
              ),
              sizedBoxH20,
              Selector<QuotePro, int>(
                selector: (_, v) => v.page,
                builder: (_, v, w) {
                  if (v == 1) return const QuoteBranch();
                  if (v == 2) return const QuoteArea();
                  if (v == 3) return const QuoteReceving();
                  return const SizedBox();
                },
              ),
              sizedBoxH20,
            ],
          ),
        ),
      ),
    );
  }
}

class QuoteReceving extends StatelessWidget {
  const QuoteReceving({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return Column(
      children: [
        card(
          lang.via_email,
          () {
            showDialog(
              context: context,
              builder: (_) => const QuoteDetailDialog(),
            );
          },
        ),
        card(
          lang.download_pdf,
          () {},
        ),
      ],
    ).animate().fade(duration: 500.ms);
  }

  Widget card(String title, Function onTap) {
    return GestureDetector(
      onTap: () => onTap(),
      child: CusMouseCursor(
        child: Container(
          alignment: Alignment.centerLeft,
          height: 50,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          margin: const EdgeInsets.symmetric(vertical: 6),
          width: 200.w,
          decoration: BoxDecoration(
            color: MyColor.primary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10.r),
            border: Border.all(color: MyColor.primary.withOpacity(0.5)),
          ),
          child: AppText(
            title,
            fontWeight: FontWeight.bold,
            fontSize: 12.spMin,
            color: Colors.grey.shade700,
          ),
        ),
      ),
    );
  }
}

class QuoteDetailDialog extends StatelessWidget {
  const QuoteDetailDialog({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    var of = Theme.of(context);
    return Dialog.fullscreen(
      backgroundColor: Colors.transparent,
      child: Stack(
        children: [
          const BlurDialogBg(),
          Center(
            child: Container(
              margin: const EdgeInsets.all(15),
              constraints: const BoxConstraints(maxWidth: 500),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15.r),
                color: of.brightness == Brightness.dark
                    ? Colors.grey.shade800
                    : of.scaffoldBackgroundColor,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    sizedBoxH20,
                    Row(
                      children: [
                        sizedBoxW20,
                        Expanded(
                          child: AppText(
                            lang.your_personal_info,
                            fontWeight: FontWeight.bold,
                            fontSize: 16.spMin,
                          ),
                        ),
                        IconButton(
                          onPressed: () => Navigator.pop(context),
                          icon: const Icon(Icons.close),
                        ),
                        sizedBoxW20,
                      ],
                    ),
                    sizedBoxH20,
                    SearchText(
                      controller: TextEditingController(),
                      hint: lang.full_name.firstLetterCap(),
                    ),
                    sizedBoxH20,
                    SearchText(
                      controller: TextEditingController(),
                      hint: lang.email.firstLetterCap(),
                    ),
                    sizedBoxH20,
                    SearchText(
                      controller: TextEditingController(),
                      hint: lang.mobile_number.firstLetterCap(),
                      type: TextInputType.number,
                    ),
                    sizedBoxH20,
                    AppButton(
                      margin: const EdgeInsets.symmetric(horizontal: 20),
                      fontWeight: FontWeight.bold,
                      fontSize: 14.spMin,
                      borderRadius: BorderRadius.circular(10.r),
                      text: lang.continue_text,
                      onPressed: () {},
                    ),
                    sizedBoxH20,
                  ],
                ),
              ),
            ).animate().fade(duration: 500.ms),
          )
        ],
      ),
    );
  }
}

class QuoteArea extends StatelessWidget {
  const QuoteArea({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    return Column(
      children: [
        Wrap(
          alignment: WrapAlignment.center,
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: 10,
          runSpacing: 10,
          children: context.read<QuotePro>().areas.map((e) => card(e)).toList(),
        ),
        sizedBoxH20,
        Consumer<QuotePro>(
          builder: (_, v, w) {
            return IgnorePointer(
              ignoring: v.area.isEmpty,
              child: AnimatedOpacity(
                duration: 500.ms,
                opacity: v.area.isEmpty ? 0.3 : 1,
                child: AppButton(
                  width: 200.wMin,
                  fontWeight: FontWeight.bold,
                  fontSize: 14.spMin,
                  borderRadius: BorderRadius.circular(10.r),
                  text: lang.next,
                  onPressed: () => v.setPage(3),
                ),
              ),
            );
          },
        )
      ],
    ).animate().fade(duration: 500.ms);
  }

  Widget card(int area) {
    return Consumer<QuotePro>(
      builder: (_, v, w) {
        var selected = v.area.contains(area);
        var color = selected
            ? MyColor.primary.withOpacity(0.7)
            : MyColor.primary.withOpacity(0.1);
        return GestureDetector(
          onTap: () async {
            v.setArea(area);
            // await Future.delayed(700.ms);
            // _.read<QuotePro>().setPage(2);
          },
          child: CusMouseCursor(
            child: AnimatedContainer(
              duration: 500.ms,
              alignment: Alignment.center,
              height: selected ? 55 : 50,
              width: selected ? 55 : 50,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(10.r),
                border: Border.all(color: MyColor.primary.withOpacity(0.5)),
              ),
              child: AppText(
                "$area M²",
                fontWeight: FontWeight.bold,
                fontSize: 12.spMin,
                color: selected ? Colors.white : Colors.grey.shade500,
              ),
            ),
          ),
        );
      },
    );
  }
}

class QuoteBranch extends StatelessWidget {
  const QuoteBranch({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        card(lang.riyadh.firstLetterCap(), QuoteBranchType.riyadh),
        card(lang.dammam.firstLetterCap(), QuoteBranchType.dammam),
        card(lang.jeddah.firstLetterCap(), QuoteBranchType.jeddah),
      ],
    ).animate().fade(duration: 500.ms);
  }

  Widget card(String title, QuoteBranchType branch) {
    return Selector<QuotePro, QuoteBranchType?>(
      selector: (_, v) => v.branch,
      builder: (_, v, w) {
        var selected = branch == v;
        var color = selected
            ? MyColor.primary.withOpacity(0.7)
            : MyColor.primary.withOpacity(0.1);
        return GestureDetector(
          onTap: () async {
            _.read<QuotePro>().setBranch(branch);
            _.read<QuotePro>().clearArea();

            await Future.delayed(700.ms);
            _.read<QuotePro>().setPage(2);
          },
          child: CusMouseCursor(
            child: AnimatedScale(
              duration: 500.ms,
              scale: selected ? 1.04 : 1,
              child: AnimatedContainer(
                duration: 500.ms,
                alignment: Alignment.centerLeft,
                height: 50,
                padding: const EdgeInsets.symmetric(horizontal: 20),
                margin: const EdgeInsets.symmetric(vertical: 6),
                width: 200.w,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(10.r),
                  border: Border.all(color: MyColor.primary.withOpacity(0.5)),
                ),
                child: AppText(
                  title,
                  fontWeight: FontWeight.bold,
                  fontSize: 13.spMin,
                  color: selected ? Colors.white : Colors.grey.shade500,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
