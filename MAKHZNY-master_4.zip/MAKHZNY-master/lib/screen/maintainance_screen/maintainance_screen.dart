import 'package:client_1/constants/image.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class MaintainanceScreen extends StatelessWidget {
  const MaintainanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: AppImage(
                image: MyImage.maintainance,
                height: 300.dg > 300 ? 300 : 300.dg,
              ),
            ),
            sizedBoxH20,
            AppText(
              "We're down for maintenance.",
              fontWeight: FontWeight.w900,
              fontSize: 20.spMin,
            ),
            sizedBoxH5,
            AppText(
              "We're working on it and should be backup shortly. Thanks for your patience.",
              maxLines: 5,
              fontWeight: FontWeight.w500,
              fontSize: 15.spMin,
              textAlign: TextAlign.center,
              color: Theme.of(context).textTheme.bodyLarge!.color!.withOpacity(0.8),
              padding: const EdgeInsets.symmetric(horizontal: 20),
            ),
          ],
        ),
      ),
    );
  }
}
