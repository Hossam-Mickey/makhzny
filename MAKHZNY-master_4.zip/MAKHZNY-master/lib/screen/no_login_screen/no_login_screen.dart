import 'package:client_1/constants/colors.dart';
import 'package:client_1/constants/image.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/route.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

class NoLoginScreen extends StatelessWidget {
  final bool needPop;
  const NoLoginScreen({super.key, this.needPop = false});

  @override
  Widget build(BuildContext context) {
    var loc = GoRouter.of(context).location();
    var lang = context.read<LangPro>().lang;
    var isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: AppImage(
                image: MyImage.no_login,
                height: MediaQuery.of(context).size.height / 4,
                width: MediaQuery.of(context).size.height / 4,
              ),
            ),
            sizedBoxH10,
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: AppText(
                "${lang.to_able_to_view} ",
                text2: lang.sign_in,
                maxLines: 5,
                textAlign: TextAlign.center,
                color: isDark ? Colors.white : Colors.black,
                // color: Colors.black,
                color2: MyColor.primary,
                fontWeight: FontWeight.w500,
                onTapText2: () {
                  if (needPop) Navigator.pop(context);
                  context.go("$loc/login");
                },
                decoration2: TextDecoration.underline,
                decorationColor: MyColor.primary,
                fontSize: 14.sp,
              ),
            )
          ],
        ),
      ),
    );
  }
}
