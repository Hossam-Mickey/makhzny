import 'package:client_1/provider/country_picker_pro/country_picker_pro.dart';
import 'package:client_1/widgets/loader.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../constants/colors.dart';
import '../../constants/sized_box.dart';
import '../../provider/lang_pro/lang_pro.dart';
import '../../provider/login_pro/login_pro.dart';
import '../../provider/theme_pro/theme_pro.dart';
import '../../widgets/app_button.dart';
import '../../widgets/app_text.dart';
import '../login_screen/widgets/login_numbericpad.dart';
import '../login_screen/widgets/login_top_text.dart';

class OTPScreen extends StatelessWidget {
  const OTPScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    var isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      body: Consumer<LoginPro>(
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 50.dg > 50 ? 50 : 50.dg),
              const LoginTopText(),
              SizedBox(height: 100.dg > 100 ? 100 : 100.dg),
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: isDark ? Colors.grey.shade800 : Colors.white,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(25),
                      topRight: Radius.circular(25),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: MyColor.grey.withOpacity(0.5),
                        spreadRadius: 1,
                        blurRadius: 20,
                        blurStyle: BlurStyle.outer,
                      )
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        sizedBoxH50,
                        Consumer2<LoginPro, CountryPickerPro>(
                          builder: (_, v, v2, w) {
                            return AppText(
                              lang.enter_otp_send,
                              text2: "${v2.loginCountry} ${v.controller.text}",
                              color2: MyColor.primary,
                              maxLines: 3,
                              color: MyColor.grey,
                            );
                          },
                        ),
                        Center(
                          child: SizedBox(
                            width: 200,
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Directionality(
                                  textDirection: TextDirection.ltr,
                                  child: TextField(
                                    keyboardType: TextInputType.none,
                                    controller:
                                        context.read<LoginPro>().otpcontroller,
                                    readOnly: true,
                                    style: TextStyle(
                                      fontFamily: context.read<ThemePro>().font,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20,
                                    ),
                                    textAlign: TextAlign.center,
                                    decoration: InputDecoration(
                                      hintText: "OTP",
                                      hintStyle: TextStyle(
                                        color: MyColor.grey,
                                        fontFamily:
                                            context.read<ThemePro>().font,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                                Consumer<LoginPro>(
                                  builder: (_, v, w) {
                                    return v.remainingSeconds == 0
                                        ? InkWell(
                                            onTap: () => v.resendOTP(),
                                            child: Container(
                                              color: Colors.transparent,
                                              padding: const EdgeInsets.all(3),
                                              child: AppText(
                                                lang.resend,
                                                fontWeight: FontWeight.w500,
                                                color: Theme.of(context)
                                                    .primaryColor,
                                              ),
                                            ),
                                          )
                                        : AppText(
                                            "${lang.resend_in} ${v.remainingSeconds} sec",
                                            color: MyColor.grey,
                                            fontWeight: FontWeight.w500,
                                          );
                                  },
                                )
                              ],
                            ),
                          ),
                        ),
                        sizedBoxH20,
                        Expanded(
                          child: NumericKeypad(
                            controller: context.read<LoginPro>().otpcontroller,
                          ),
                        ),
                        sizedBoxH30,
                      ],
                    ),
                  ),
                ),
              ),
              AppButton(
                text: lang.login,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(12),
                  topRight: Radius.circular(12),
                ),
                fontWeight: FontWeight.w500,
                onPressed: () {
                  context.read<LoginPro>().confirmOTP();
                },
              ),
            ],
          ),
        ),
        builder: (_, v, w) {
          return PopScope(
            canPop: !v.loading,
            child: Stack(
              children: [
                w!,
                if (v.loading) const Loader(),
              ],
            ),
          );
        },
      ),
    );
  }
}
