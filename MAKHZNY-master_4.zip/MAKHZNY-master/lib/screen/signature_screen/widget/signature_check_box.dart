import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/signature_pro/signature_pro.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/route.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

class SignatureCheckBox extends StatelessWidget {
  const SignatureCheckBox({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    return ListTile(
      // onTap: () {
      //   // var pro = context.read<SignaturePro>();
      //   // pro.changeCheckBox(!pro.checkBox);
      // },
      contentPadding: EdgeInsets.zero,
      title: AppText(
        lang.agreeToTerms,
        fontWeight: FontWeight.bold,
        fontSize: 15.spMin,
        maxLines: 4,
      ),
      subtitle: AppText(
        "${lang.continue_checkbox} ",
        text2: "Terms & Conditions",
        onTapText2: () async {
          var loc = GoRouter.of(context).location();
          context.go("$loc/terms_conditions");
        },
        fontWeight2: FontWeight.w900,
        color2: Colors.blueAccent,
        decorationColor: Colors.blueAccent,
        decoration2: TextDecoration.underline,
        padding: const EdgeInsets.only(top: 2),
        fontWeight: FontWeight.bold,
        fontSize: 13.spMin,
        maxLines: 5,
        color: context.read<ThemePro>().grey,
      ),
      trailing: Consumer<SignaturePro>(
        builder: (_, v, w) {
          return Checkbox(
            value: v.checkBox,
            activeColor: Colors.transparent,
            side: WidgetStateBorderSide.resolveWith(
              (states) => BorderSide(
                color: context.read<ThemePro>().grey,
                width: 2,
              ),
            ),
            checkColor: Theme.of(context).primaryColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
            ),
            onChanged: (c) {
              v.changeCheckBox(!v.checkBox);
            },
          );
        },
      ),
    );
  }
}
