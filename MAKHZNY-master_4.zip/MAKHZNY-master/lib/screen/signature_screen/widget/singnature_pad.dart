import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/signature_pro/signature_pro.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/mouse_cursor.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:signature/signature.dart';

class SignaturePad extends StatelessWidget {
  const SignaturePad({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    var backgroundColor = Theme.of(context).brightness == Brightness.light
        ? Colors.grey.shade300
        : Colors.grey.shade800;
    var lang = context.read<LangPro>().lang;

    var borderSide = BorderSide(
      color: backgroundColor,
      width: 1.5,
    );
    return Column(
      children: [
        ClipRRect(
          borderRadius: const BorderRadius.only(
            topRight: Radius.circular(8),
            topLeft: Radius.circular(8),
          ),
          child: Consumer<SignaturePro>(
            builder: (_, v, w) {
              return RepaintBoundary(
                child: Signature(
                  height: 250,
                  backgroundColor: backgroundColor,
                  width: double.infinity,
                  controller: v.controller,
                ),
              );
            },
          ),
        ),
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.only(
              bottomRight: Radius.circular(8),
              bottomLeft: Radius.circular(8),
            ),
            border: Border(
              bottom: borderSide,
              left: borderSide,
              right: borderSide,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              sizedBoxH10,
              AppText(
                lang.yourSignature,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                fontWeight: FontWeight.bold,
                fontSize: 18.spMin,
                maxLines: 4,
              ),
              AppText(
                lang.pleaseSignAbove,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                fontWeight: FontWeight.bold,
                fontSize: 13.spMin,
                maxLines: 4,
                color: context.read<ThemePro>().grey,
              ),
              sizedBoxH10,
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Wrap(
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        stockSelecter(
                          width: 75.dm,
                          height: 10.5,
                          stock: PenStock.large,
                        ),
                        stockSelecter(
                          width: 55.dm,
                          height: 6.5,
                          stock: PenStock.medium,
                        ),
                        stockSelecter(
                          width: 35.dm,
                          height: 3,
                          stock: PenStock.small,
                        ),
                      ],
                    ),
                  ),
                  // const Spacer(),
                  AppButton(
                    text: lang.clear,
                    width: 100,
                    height: 30,
                    fontWeight: FontWeight.w500,
                    fontSize: 14.spMin,
                    borderRadius: BorderRadius.circular(20),
                    onPressed: () {
                      context.read<SignaturePro>().clearSign();
                    },
                  ),
                  sizedBoxW10,
                ],
              ),
              sizedBoxH10,
            ],
          ),
        ),
      ],
    );
  }

  Widget stockSelecter({
    required double height,
    required double width,
    required PenStock stock,
  }) {
    return CusMouseCursor(
      child: Consumer<SignaturePro>(
        builder: (_, v, w) {
          var isDark = Theme.of(_).brightness == Brightness.dark;
          return GestureDetector(
            onTap: () => v.changeStock(stock),
            child: Container(
              color: Colors.transparent,
              padding: const EdgeInsets.all(8),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  AnimatedContainer(
                    duration: 500.ms,
                    width: width + 15,
                    height: height + 15,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: v.stock != stock
                            ? Colors.transparent
                            : isDark
                                ? Colors.grey
                                : Colors.black,
                      ),
                      borderRadius: BorderRadius.circular(90),
                    ),
                  ),
                  Container(
                    width: width,
                    height: height,
                    decoration: BoxDecoration(
                      color: isDark ? Colors.grey : Colors.black,
                      borderRadius: BorderRadius.circular(90),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
