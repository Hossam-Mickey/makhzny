import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/checkout_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/signature_pro/signature_pro.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/screen/signature_screen/widget/signature_check_box.dart';
import 'package:client_1/screen/signature_screen/widget/singnature_pad.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/cus_app_bar.dart';
import 'package:client_1/widgets/loader.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

class SignatureScreen extends StatelessWidget {
  const SignatureScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return Consumer2<SignaturePro, CheckoutPro>(
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle(
          systemNavigationBarColor: Theme.of(context).scaffoldBackgroundColor,
        ),
        child: Scaffold(
          body: SafeArea(
            child: Scrollbar(
              thumbVisibility: true,
              controller: context.read<SignaturePro>().scrollController,
              child: SingleChildScrollView(
                controller: context.read<SignaturePro>().scrollController,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    sizedBoxH20,
                    CusAppbar(title: lang.termsOfServiceTitle),
                    sizedBoxH20,
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          AppText(
                            lang.agreeToTerms,
                            fontWeight: FontWeight.bold,
                            fontSize: 18.spMin,
                            maxLines: 4,
                          ),
                          sizedBoxH10,
                          AppText(
                            lang.termsAndConditionsSub,
                            fontWeight: FontWeight.bold,
                            fontSize: 13.spMin,
                            maxLines: 5,
                            color: context.read<ThemePro>().grey,
                          ),
                          sizedBoxH30,
                          const SignatureCheckBox(),
                          sizedBoxH20,
                          const SignaturePad(),
                          sizedBoxH20,
                          sizedBoxH20,
                          AppButton(
                            text: lang.continue_text,
                            borderRadius: BorderRadius.circular(90),
                            fontWeight: FontWeight.bold,
                            fontSize: 16.spMin,
                            onPressed: () {
                              context.read<SignaturePro>().next();
                            },
                          ),
                          sizedBoxH20,
                          sizedBoxH20,
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
      builder: (_, v, v2, w) {
        var loading = v.loading || v2.loading;
        return PopScope(
          canPop: !loading,
          child: Stack(
            children: [
              w!,
              if (loading) const Loader(),
            ],
          ),
        );
      },
    );
  }
}
