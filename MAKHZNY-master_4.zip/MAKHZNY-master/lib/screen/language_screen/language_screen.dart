import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../constants/sized_box.dart';
import '../../provider/theme_pro/theme_pro.dart';
import '../../widgets/app_text.dart';
import '../../widgets/cus_app_bar.dart';

class LanguageScreen extends StatelessWidget {
  const LanguageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Consumer<LangPro>(
            builder: (_, v, w) {
              var lang = v.lang;
              return Column(
                children: [
                  sizedBoxH20,
                  CusAppbar(title: lang.languages),
                  sizedBoxH10,
                  LanguageCard(
                    name: "Arabic",
                    onTap: () => v.change(LangType.ar),
                    selected: v.type == LangType.ar,
                  ),
                  LanguageCard(
                    name: "English",
                    onTap: () => v.change(LangType.eng),
                    selected: v.type == LangType.eng,
                  ),
                  // LanguageCard(
                  //   name: "Russian (test)",
                  //   onTap: () => v.change(LangType.rs),
                  //   selected: v.type == LangType.rs,
                  // ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }
}

class LanguageCard extends StatelessWidget {
  final String? image;
  final String name;
  final Function onTap;
  final bool selected;
  final FontWeight weight;
  const LanguageCard({
    super.key,
    this.weight = FontWeight.w500,
    this.selected = false,
    required this.name,
    required this.onTap,
    this.image,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => onTap(),
      child: AnimatedContainer(
        duration: 700.ms,
        height: 50,
        width: double.infinity,
        margin: const EdgeInsets.all(15),
        alignment: Alignment.centerLeft,
        padding: const EdgeInsets.symmetric(horizontal: 15),
        decoration: BoxDecoration(
          color: context.read<ThemePro>().cardColor,
          border: Border.all(
            color: selected
                ? Theme.of(context).primaryColor
                : context.read<ThemePro>().grey.withOpacity(0.2),
            width: 1.5,
          ),
          // boxShadow: [
          //   BoxShadow(
          //     color: Colors.grey.shade900.withOpacity(0.5),
          //     spreadRadius: -10,
          //     offset: const Offset(0, 4),
          //     blurRadius: 20,
          //   )
          // ],
          borderRadius: BorderRadius.circular(6.r),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (image != null) AppImage(image: image, width: 30),
            if (image != null) sizedBoxW10,
            AppText(
              name,
              fontWeight: weight,
              fontSize: 14.spMin,
            ),
          ],
        ),
      ),
    );
  }
}
