// import 'package:client_1/constants/api.dart';
// import 'package:client_1/constants/image.dart';
// import 'package:client_1/functions/connectivity_check.dart';
// import 'package:client_1/get_it.dart';
// import 'package:client_1/model/cart_model/cart_model.dart';
// import 'package:client_1/model/product_model/product_model.dart';
// import 'package:client_1/provider/add_cart_pro/add_cart_pro.dart';
// import 'package:client_1/provider/cart_pro/cart_pro.dart';
// import 'package:client_1/provider/company_pro/company_pro.dart';
// import 'package:client_1/provider/dammam_units_pro/dammam_units_pro.dart';
// import 'package:client_1/provider/jeddah_units_pro/jeddah_units_pro.dart';
// import 'package:client_1/provider/riyadh_units_pro/riyadh_units_pro.dart';
// import 'package:client_1/screen/add_cart_dialog/add_cart_dialog.dart';
// import 'package:client_1/screen/my_storage_screen/my_storage_screen.dart';
// import 'package:client_1/screen/store_screen/store_screen.dart';
// import 'package:client_1/widgets/app_image.dart';
// import 'package:client_1/widgets/app_text.dart';
// import 'package:client_1/widgets/loader.dart';
// import 'package:client_1/widgets/product_cart_vert_shimner.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter_animate/flutter_animate.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:go_router/go_router.dart';
// import 'package:provider/provider.dart';
// import 'package:intl/intl.dart' as intl;

// import '../../constants/colors.dart';
// import '../../constants/sized_box.dart';
// import '../../functions/blur_bottom_sheet.dart';
// import '../../provider/lang_pro/lang_pro.dart';
// import '../../provider/theme_pro/theme_pro.dart';
// import '../../route.dart';
// import '../../widgets/app_button.dart';
// import '../../widgets/cus_app_bar.dart';
// import '../../widgets/cus_elevation.dart';

// class CartScreen extends StatelessWidget {
//   const CartScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     var lang = context.read<LangPro>().lang;

//     return AnnotatedRegion<SystemUiOverlayStyle>(
//       value: SystemUiOverlayStyle(
//         systemNavigationBarColor: Theme.of(context).primaryColor,
//       ),
//       child: Consumer<CartPro>(
//         child: Scaffold(
//           bottomNavigationBar: AppButton(
//             text: lang.checkout,
//             fontWeight: FontWeight.w500,
//             fontSize: 18.spMin,
//             borderRadius: BorderRadius.only(
//               topLeft: Radius.circular(20.r),
//               topRight: Radius.circular(20.r),
//             ),
//             onPressed: () {
//               var read = context.read<CartPro>();
//               if (read.cart.isEmpty) return;

//               var read1 = context.read<RiyadhUnitsPro>();
//               var read2 = context.read<DammamUnitsPro>();
//               var read3 = context.read<JeddahUnitsPro>();
//               var loading = read1.loading || read2.loading || read3.loading;
//               var hasError = read1.hasError || read2.hasError || read3.hasError;

//               if (loading || hasError) return;

//               var loc = GoRouter.of(context).location();
//               context.go("$loc/signature");
//             },
//           ).animate().moveY(duration: 700.ms, begin: 50).fade(duration: 700.ms),
//           body: SafeArea(
//             child: SingleChildScrollView(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   sizedBoxH20,
//                   CusAppbar(title: lang.my_cart),
//                   sizedBoxH20,
//                   Padding(
//                     padding: const EdgeInsets.symmetric(horizontal: 15),
//                     child: Align(
//                       alignment:
//                           context.read<LangPro>().direction == TextDirection.ltr
//                               ? Alignment.centerRight
//                               : Alignment.centerLeft,
//                       child: GestureDetector(
//                         onTap: () {
//                           context.read<CartPro>().clearAll();
//                         },
//                         child: Container(
//                           color: Colors.transparent,
//                           padding: const EdgeInsets.all(5),
//                           child: Row(
//                             mainAxisSize: MainAxisSize.min,
//                             children: [
//                               AppImage(
//                                 image: MyImage.delete,
//                                 color: Theme.of(context).primaryColor,
//                                 height: 15.spMin,
//                               ),
//                               sizedBoxW10,
//                               AppText(
//                                 lang.clear_all_items,
//                                 color: Theme.of(context).primaryColor,
//                                 fontWeight: FontWeight.w500,
//                                 fontSize: 14.spMin,
//                                 decoration: TextDecoration.underline,
//                                 decorationColor: Theme.of(context).primaryColor,
//                               ),
//                             ],
//                           ),
//                         ),
//                       ),
//                     ),
//                   ),
//                   sizedBoxH10,
//                   Consumer3<JeddahUnitsPro, DammamUnitsPro, RiyadhUnitsPro>(
//                     builder: (_, v1, v2, v3, w) {
//                       var loading = v1.loading || v2.loading || v3.loading;
//                       var hasError = v1.hasError || v2.hasError || v3.hasError;

//                       var product = [
//                         ...v1.non_filter_product,
//                         ...v2.non_filter_product,
//                         ...v3.non_filter_product,
//                       ];
//                       if (loading) {
//                         return ListView.builder(
//                           itemCount: 5,
//                           physics: const NeverScrollableScrollPhysics(),
//                           shrinkWrap: true,
//                           padding: const EdgeInsets.symmetric(horizontal: 15),
//                           itemBuilder: (_, i) {
//                             return const ProductCardVertShimner();
//                           },
//                         );
//                       }
//                       if (hasError) {
//                         return SizedBox(
//                           height: MediaQuery.sizeOf(context).height / 1.8,
//                           child: StoreErrorScreen(
//                             onTap: () async {
//                               var connectCheck = getIt<ConnectivityCheck>();
//                               var network =
//                                   await connectCheck.getCurrentState();
//                               if (!network) return;
//                               if (v1.hasError) v1.getProduct();
//                               if (v2.hasError) v2.getProduct();
//                               if (v3.hasError) v3.getProduct();
//                             },
//                           ),
//                         );
//                       }
//                       return Consumer<CartPro>(
//                         builder: (_, v, w) {
//                           if (v.cart.isEmpty) {
//                             return Column(
//                               children: [
//                                 sizedBoxH20,
//                                 MyStorageNoData(
//                                   image: MyImage.cart_empty,
//                                   title: lang.your_cart_is_empty,
//                                   subtitle: "",
//                                 ),
//                                 sizedBoxH20,
//                               ],
//                             );
//                           }
//                           return ListView.builder(
//                             itemCount: v.cart.length,
//                             physics: const NeverScrollableScrollPhysics(),
//                             shrinkWrap: true,
//                             padding: const EdgeInsets.symmetric(horizontal: 15),
//                             itemBuilder: (_, i) {
//                               var cart = v.cart[i];
//                               var prod = product
//                                   .where((e) => e.id == cart.unit_id)
//                                   .first;
//                               return CartCard(product: prod, cart: cart);
//                             },
//                           );
//                         },
//                       );
//                     },
//                   ),
//                   sizedBoxH20,
//                   AppText(
//                     lang.add_ons,
//                     fontWeight: FontWeight.w600,
//                     fontSize: 15.spMin,
//                     padding: const EdgeInsets.symmetric(horizontal: 25),
//                   ),
//                   SizedBox(
//                     height: 235,
//                     child: ListView.builder(
//                       padding: const EdgeInsets.symmetric(horizontal: 5),
//                       itemCount: 10,
//                       shrinkWrap: true,
//                       scrollDirection: Axis.horizontal,
//                       itemBuilder: (_, i) {
//                         return const AdOnsCard();
//                       },
//                     ),
//                   ),
//                   sizedBoxH20,
//                   const CartAmountCalculate(),
//                   sizedBoxH30,
//                 ],
//               ),
//             ),
//           ),
//         ),
//         builder: (_, v, w) {
//           return PopScope(
//             canPop: !v.loading,
//             child: Stack(
//               children: [
//                 w!,
//                 if (v.loading) const Loader(),
//               ],
//             ),
//           );
//         },
//       ),
//     );
//   }
// }

// class CartAmountCalculate extends StatelessWidget {
//   const CartAmountCalculate({
//     super.key,
//   });

//   @override
//   Widget build(BuildContext context) {
//     var lang = context.read<LangPro>().lang;
//     return Consumer4<JeddahUnitsPro, DammamUnitsPro, RiyadhUnitsPro, CartPro>(
//       builder: (_, v1, v2, v3, v4, w) {
//         var product = <ProductModel>[
//           ...v1.non_filter_product,
//           ...v2.non_filter_product,
//           ...v3.non_filter_product,
//         ];

//         var fulltotal = v4.total(product);
//         var totalAmount = fulltotal.total;
//         var totalVat = fulltotal.vat;
//         var payable = totalVat + totalAmount;

//         return Container(
//           decoration: BoxDecoration(
//             color: context.read<ThemePro>().grey.withOpacity(0.15),
//             borderRadius: BorderRadius.circular(10.r),
//           ),
//           margin: const EdgeInsets.symmetric(horizontal: 15),
//           padding: const EdgeInsets.all(20),
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               amt(lang.total_amount, totalAmount.toStringAsFixed(2)),
//               sizedBoxH10,
//               amt(lang.vat, totalVat.toStringAsFixed(2)),
//               sizedBoxH20,
//               amt(lang.payable_amount, payable.toStringAsFixed(2), true),
//             ],
//           ),
//         );
//       },
//     );
//   }

//   Widget amt(
//     String title,
//     String amount, [
//     bool special = false,
//   ]) {
//     var fontWeight = special ? FontWeight.w500 : FontWeight.w400;
//     var fontWeight2 = special ? FontWeight.w700 : FontWeight.w400;

//     var fontSize = special ? 16.spMin : 14.spMin;
//     return Row(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       children: [
//         Expanded(
//           child: AppText(
//             title,
//             fontWeight: fontWeight,
//             fontSize: fontSize,
//           ),
//         ),
//         Flexible(
//           child: AppText(
//             "$amount SAR",
//             textAlign: TextAlign.right,
//             fontWeight: fontWeight2,
//             fontSize: fontSize,
//             color: special ? MyColor.primary : MyColor.grey,
//             maxLines: 4,
//           ),
//         ),
//       ],
//     );
//   }
// }

// class CartCard extends StatelessWidget {
//   final ProductModel product;
//   final CartModel cart;
//   const CartCard({
//     super.key,
//     required this.product,
//     required this.cart,
//   });

//   @override
//   Widget build(BuildContext context) {
//     var grey = context.read<ThemePro>().grey;
//     var lang = context.read<LangPro>().lang;
//     String area() {
//       var af = product.area;
//       double fp = af - af.floor();
//       if (fp == 0) return af.floor().toString();
//       return af.toString();
//     }

//     return Container(
//       height: 105,
//       margin: const EdgeInsets.symmetric(vertical: 10),
//       decoration: BoxDecoration(
//         color: context.read<ThemePro>().cardColor,
//         boxShadow: [
//           BoxShadow(
//             color: Colors.grey.shade900.withOpacity(0.1),
//             spreadRadius: -1,
//             offset: const Offset(0, 4),
//             blurRadius: 20,
//           )
//         ],
//         borderRadius: BorderRadius.circular(8),
//       ),
//       child: Row(
//         children: [
//           Container(
//             width: 90,
//             margin: const EdgeInsets.all(10),
//             decoration: BoxDecoration(
//               color: grey,
//               borderRadius: BorderRadius.circular(8),
//             ),
//             child: ClipRRect(
//               borderRadius: BorderRadius.circular(8),
//               child: AppImage(
//                 image: API.baseUrl + product.image,
//                 fit: BoxFit.cover,
//                 height: double.infinity,
//                 width: double.infinity,
//               ),
//             ),
//           ),
//           Expanded(
//             child: Padding(
//               padding: const EdgeInsets.symmetric(vertical: 10),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Row(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Flexible(
//                         child: AppText(
//                           product.title,
//                           maxLines: 2,
//                           fontSize: 14.spMin,
//                           fontWeight: FontWeight.w400,
//                         ),
//                       ),
//                       sizedBoxW20,
//                       AppText(
//                         "${area()} M²",
//                         fontSize: 14.spMin,
//                         fontWeight: FontWeight.w400,
//                       ),
//                     ],
//                   ),
//                   const Spacer(),
//                   Row(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Transform.translate(
//                         offset: const Offset(0, 2),
//                         child: AppImage(
//                           image: MyImage.location,
//                           color: MyColor.grey,
//                           height: 12.spMin,
//                         ),
//                       ),
//                       sizedBoxW5,
//                       Expanded(
//                         child: AppText(
//                           context.read<CompanyPro>().loc(cart.branch_id),
//                           fontSize: 12.spMin,
//                           fontWeight: FontWeight.w400,
//                           color: MyColor.grey,
//                         ),
//                       ),
//                     ],
//                   ),
//                   const Spacer(flex: 5),
//                   AppText(
//                     "${product.price} SAR ",
//                     text2: "Monthly",
//                     fontSize: 14.spMin,
//                     color: MyColor.primary,
//                     fontWeight: FontWeight.w700,
//                     fontWeight2: FontWeight.w500,
//                     fontSize2: 10.spMin,
//                   ),
//                   AppText(
//                     "${context.read<AddCartPro>().periodToString(cart.installment_duration)} paln",
//                     fontSize: 10.spMin,
//                     color: MyColor.grey,
//                     fontWeight: FontWeight.w400,
//                   ),
//                 ],
//               ),
//             ),
//           ),
//           Column(
//             crossAxisAlignment: CrossAxisAlignment.end,
//             children: [
//               IconButton(
//                 onPressed: () {
//                   blurBottomSheet(
//                     title: lang.are_you_sure_cart,
//                     continueText: lang.yes,
//                     onTap: (_) {
//                       context.read<CartPro>().remove(cart);
//                       Navigator.pop(context);
//                     },
//                   );
//                 },
//                 icon: CircleAvatar(
//                   radius: 10,
//                   backgroundColor: Theme.of(context).primaryColor,
//                   child: Center(
//                     child: Icon(
//                       Icons.close,
//                       color: Theme.of(context).scaffoldBackgroundColor,
//                       size: 14,
//                     ),
//                   ),
//                 ),
//               ),
//               const Spacer(),
//               AppText(
//                 lang.rental_date,
//                 fontSize: 10.spMin,
//                 fontWeight: FontWeight.bold,
//               ),
//               AppText(
//                 intl.DateFormat("dd-MMM-yyyy").format(cart.move_in_date),
//                 fontSize: 12.spMin,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.grey,
//               ),
//               // QuantityButtuon(
//               //   val: "10",
//               //   width: 100.w,
//               //   height: 30,
//               //   fontSize: 12.spMin,
//               //   onPlus: () {},
//               //   onMinuse: () {},
//               // ),
//               sizedBoxH10,
//             ],
//           ),
//           sizedBoxW10,
//         ],
//       ),
//     );
//   }
// }

// class AdOnsCard extends StatelessWidget {
//   const AdOnsCard({
//     super.key,
//   });

//   @override
//   Widget build(BuildContext context) {
//     var lang = context.read<LangPro>().lang;
//     var grey = context.read<ThemePro>().grey;

//     return CustomElevation(
//       shape: BoxShape.rectangle,
//       color: Colors.grey.shade600,
//       spread: -35,
//       blur: 30,
//       offset: const Offset(0, 15),
//       child: Container(
//         width: 200,
//         // height: 230,
//         margin: const EdgeInsets.all(10),
//         decoration: BoxDecoration(
//           color: context.read<ThemePro>().cardColor,
//           borderRadius: BorderRadius.circular(8),
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Container(
//               height: 90,
//               margin: const EdgeInsets.all(10),
//               decoration: BoxDecoration(
//                 color: grey.withOpacity(0.5),
//                 borderRadius: BorderRadius.circular(8),
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 10),
//               child: Row(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Expanded(
//                     child: AppText(
//                       "Box - large",
//                       fontSize: 13.spMin,
//                       fontWeight: FontWeight.w500,
//                       maxLines: 2,
//                     ),
//                   ),
//                   AppText(
//                     "19 SAR",
//                     fontSize: 12.spMin,
//                     fontWeight: FontWeight.w600,
//                     color: MyColor.primary,
//                     padding: const EdgeInsets.only(top: 1),
//                   )
//                 ],
//               ),
//             ),
//             const Spacer(),
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 10),
//               child: Row(
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 children: [
//                   Expanded(
//                     child: AppText(
//                       "${lang.quantity}: ",
//                       fontSize: 12.spMin,
//                       color: MyColor.grey,
//                       fontWeight: FontWeight.w400,
//                       maxLines: 2,
//                     ),
//                   ),
//                   QuantityButtuon(
//                     val: "10",
//                     width: 100.w,
//                     height: 25,
//                     fontSize: 12.spMin,
//                     onPlus: () {},
//                     onMinuse: () {},
//                   ),
//                 ],
//               ),
//             ),
//             const Spacer(),
//             AppButton(
//               text: lang.add_to_cart,
//               borderRadius: const BorderRadius.only(
//                 bottomLeft: Radius.circular(10),
//                 bottomRight: Radius.circular(10),
//               ),
//               onPressed: () {
//                 showModalBottomSheet(
//                   context: navigatorKey.currentContext!,
//                   useSafeArea: false,
//                   isScrollControlled: true,
//                   enableDrag: false,
//                   isDismissible: false,
//                   backgroundColor: Colors.transparent,
//                   builder: (_) => AddCartDialog(
//                     _,
//                     onAdd: () {},
//                   ),
//                 );
//               },
//               height: 30,
//               fontWeight: FontWeight.w600,
//               fontSize: 10,
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }
