import 'package:client_1/constants/image.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/message_pro.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:client_1/constants/colors.dart';
import 'package:client_1/constants/sized_box.dart';

import 'package:client_1/route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:client_1/widgets/mouse_cursor.dart';
import 'package:provider/provider.dart';

class MessageTextfield extends StatelessWidget {
  const MessageTextfield({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    var border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: const BorderSide(color: Colors.transparent),
    );

    var style = TextStyle(
      fontSize: 16.spMin,
      fontWeight: FontWeight.w500,
      fontFamily: context.read<ThemePro>().font,
    );
    var lang = context.read<LangPro>().lang;

    bool isDark = Theme.of(context).brightness == Brightness.dark;
    return AnimatedContainer(
      duration: 500.ms,
      margin: const EdgeInsets.symmetric(horizontal: 10),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: isDark ? Colors.grey.shade900 : Colors.grey.shade200,
        borderRadius: BorderRadius.circular(22.r),
      ),
      child: SizedBox(
        // height: 45.h,
        child: Row(
          children: [
            Expanded(
              child: TextField(
                style: style,
                controller: context.read<MessagePro>().controller,
                cursorColor: MyColor.primary,
                decoration: InputDecoration(
                  prefixIcon: imagePickerBtn(),
                  // suffixIcon: audioBtn(),
                  fillColor: Theme.of(context).scaffoldBackgroundColor,
                  filled: true,
                  hintText: lang.message,
                  hintStyle: style,
                  enabledBorder: border,
                  border: border,
                ),
              ),
            ),
            sizedBoxW10,
            sendBtn(),
          ],
        ).animate().flipV(duration: 500.ms),
      ),
    );
  }

  String dur(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');

    int minutes = duration.inMinutes;
    int seconds = duration.inSeconds.remainder(60);

    return '${twoDigits(minutes)}:${twoDigits(seconds)}';
  }

  Widget sendBtn() {
    var context = navigatorKey.currentContext!;
    bool isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: () async {
        // context.read<MessagePro>().text();
      },
      child: CusMouseCursor(
        child: Container(
          width: 45,
          height: 45,
          padding: const EdgeInsets.all(8),
          // decoration: BoxDecoration(
          //   color: Colors.grey,
          //   borderRadius: BorderRadius.circular(14),
          // ),
          child: AppImage(
            image: MyImage.send_plane,
            color: isDark ? Colors.grey : null,
          ),
        ),
      ),
    );
  }

  // Widget audioBtn() {
  //   return GestureDetector(
  //     onTap: () async {
  //       var context = navigatorKey.currentContext!;
  //       FocusScope.of(context).unfocus();
  //       context.read<RecordPro>().start();
  //     },
  //     child: CusMouseCursor(
  //       child: Container(
  //         color: Colors.transparent,
  //         child: const Column(
  //           crossAxisAlignment: CrossAxisAlignment.center,
  //           mainAxisAlignment: MainAxisAlignment.center,
  //           children: [
  //             SizedBox(
  //               height: 26,
  //               width: 26,
  //               child: Icon(Remix.mic_2_line),
  //             ),
  //           ],
  //         ),
  //       ),
  //     ),
  //   );
  // }

  Widget imagePickerBtn() {
    var context = navigatorKey.currentContext!;
    bool isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: () async {
        FocusScope.of(context).unfocus();
        // context.read<MessagePro>().image();
      },
      child: CusMouseCursor(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 10),
          color: Colors.transparent,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 26,
                width: 26,
                child: AppImage(
                  image: MyImage.image_circle,
                  color: isDark ? Colors.grey : null,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
