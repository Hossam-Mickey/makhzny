import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/screen/message_screen/widgets/message_text_filed.dart';
import 'package:client_1/widgets/cus_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class MessageScreen extends StatelessWidget {
  const MessageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            sizedBoxH20,
            CusAppbar(title: lang.message),
            Expanded(
              child: ListView.builder(
                itemCount: 1,
                itemBuilder: (BuildContext context, int index) {
                  return;
                },
              ),
            ),
            sizedBoxH20,
            const MessageTextfield(),
            sizedBoxH20,
          ],
        ),
      ),
    );
  }
}
