import 'package:client_1/constants/api.dart';
import 'package:client_1/constants/colors.dart';
import 'package:client_1/functions/connectivity_check.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/main.dart';
import 'package:client_1/model/product_model/product_model.dart';
import 'package:client_1/provider/company_pro/company_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/my_units_pro/my_units_pro.dart';
import 'package:client_1/provider/storage_pro/storage_pro.dart';
import 'package:client_1/screen/add_cart_dialog/add_cart_dialog.dart';
import 'package:client_1/screen/store_screen/store_screen.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/container_shimner.dart';
import 'package:client_1/widgets/cus_tab.dart';
import 'package:client_1/widgets/product_cart_vert_shimner.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../constants/image.dart';
import '../../constants/sized_box.dart';
import '../../provider/theme_pro/theme_pro.dart';
import '../home_screen/widgets/home_top.dart';

class MyStorageScreen extends StatelessWidget {
  const MyStorageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          backgroundColor: MyColor.refreshColor,
          onRefresh: () {
            return context.read<MyUnitsPro>().getUnits();
          },
          child: Column(
            children: [
     
              const HomeTop(),
              sizedBoxH40,
              Consumer<StoragePro>(
                builder: (_, v, w) {
                  return CusTab(
                    data: [
                      (lang.all, 0),
                      (lang.jeddah, 1),
                      (lang.riyadh, 2),
                      (lang.dammam, 3),
                    ],
                    selected: v.selected,
                    onTap: (i) => v.changeSelected(i),
                  );
                },
              ),
              sizedBoxH20,
              Expanded(
                child: Consumer2<StoragePro, MyUnitsPro>(
                  builder: (_, v, v2, w) {
                    if (v2.loading) return const MyStorageLoader();
                    if (v2.hasError) {
                      return StoreErrorScreen(
                        sub: v2.errorMes,
                        onTap: () async {
                          var connectCheck = getIt<ConnectivityCheck>();
                          var network = await connectCheck.getCurrentState();
                          if (!network) return;
                          v2.getUnits();
                        },
                      );
                    }
                    if (v.selected == 0) {
                      return MyStorage(models: v2.non_filter_units);
                    } else if (v.selected == 1) {
                      return MyStorage(models: v2.jeddahUnits);
                    } else if (v.selected == 2) {
                      return MyStorage(models: v2.riyadhUnits);
                    } else {
                      return MyStorage(models: v2.dammamUnits);
                    }
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MyStorageLoader extends StatelessWidget {
  const MyStorageLoader({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        ContainerShimner(
          margin: const EdgeInsets.symmetric(horizontal: 15),
          height: 40,
          width: double.infinity,
          borderRadius: BorderRadius.circular(8),
        ),
        sizedBoxH10,
        Expanded(
          child: ListView.builder(
            padding:
                const EdgeInsets.symmetric(horizontal: 15).copyWith(bottom: 10),
            itemCount: 10,
            shrinkWrap: true,
            itemBuilder: (_, i) => const ProductCardVertShimner(),
          ),
        )
      ],
    );
  }
}

class MyStorage extends StatelessWidget {
  final List<ProductModel> models;
  const MyStorage({
    super.key,
    required this.models,
  });

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    return Column(
      children: [
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 15),
          height: 40,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: MyColor.grey.withOpacity(0.8),
              width: 1.2,
            ),
          ),
          child: Row(
            children: [
              sizedBoxW10,
              AppText(
                lang.total_number,
                color: MyColor.grey,
                fontSize: 12,
              ),
              AppText(
                "${models.length} ${lang.rented_items}",
                fontSize: 14,
                fontWeight: FontWeight.w700,
              ),
            ],
          ),
        ),
        sizedBoxH10,
        if (models.isEmpty) const Expanded(child: MyStorageNoData()),
        if (models.isNotEmpty)
          Expanded(
            child: ListView.builder(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(
                horizontal: 15,
              ).copyWith(bottom: 10),
              itemCount: models.length,
              shrinkWrap: true,
              // physics: const NeverScrollableScrollPhysics(),
              itemBuilder: (_, i) => ProductCardVert(model: models[i]),
            ),
          )
      ],
    );
  }
}

class ProductCardVert extends StatelessWidget {
  final ProductModel model;
  const ProductCardVert({super.key, required this.model});

  @override
  Widget build(BuildContext context) {
    var grey = context.read<ThemePro>().grey;
    String area() {
      var af = model.area;
      double fp = af - af.floor();
      if (fp == 0) return af.floor().toString();
      return af.toString();
    }

    return Container(
      height: 105,
      margin: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: context.read<ThemePro>().cardColor,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade900.withOpacity(0.1),
            spreadRadius: -1,
            offset: const Offset(0, 4),
            blurRadius: 20,
          )
        ],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Container(
            width: 90,
            margin: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: grey,
              borderRadius: BorderRadius.circular(8),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: AppImage(
                image: API.baseUrl + model.image,
                fit: BoxFit.cover,
                height: double.infinity,
                width: double.infinity,
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Flexible(
                        child: AppText(
                          model.title,
                          maxLines: 2,
                          fontSize: 14.spMin,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      sizedBoxW20,
                      AppText(
                        "${area()} M²",
                        fontSize: 14.spMin,
                        fontWeight: FontWeight.w400,
                      ),
                    ],
                  ),
                  const Spacer(),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Transform.translate(
                        offset: const Offset(0, 2),
                        child: AppImage(
                          image: MyImage.location,
                          color: MyColor.grey,
                          height: 12.spMin,
                        ),
                      ),
                      sizedBoxW5,
                      Expanded(
                        child: AppText(
                          context.read<CompanyPro>().loc(model.company_id),
                          fontSize: 12.spMin,
                          fontWeight: FontWeight.w400,
                          color: MyColor.grey,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(flex: 5),
                  Builder(
                    builder: (context) {
                      var vat = model.price * model.vat;
                      var total = model.price + vat;
                      return AppText(
                        "${total.roundToNearestTen()} SAR ",
                        text2: "Monthly",
                        fontSize: 14.spMin,
                        color: MyColor.primary,
                        fontWeight: FontWeight.w700,
                        fontWeight2: FontWeight.w500,
                        fontSize2: 10.spMin,
                      );
                    },
                  )
                ],
              ),
            ),
          ),
          // autoRenew(
          //   false,
          //   () {
          //     blurBottomSheet(
          //       title: lang.are_you_sure_renewal,
          //       continueText: lang.yes,
          //       onTap: (_) {},
          //     );
          //   },
          // ),
          sizedBoxW10,
        ],
      ),
    );
  }

  Widget autoRenew(bool onn, Function onTap) {
    var lang = messangerKey.currentContext!.read<LangPro>().lang;
    var color = onn ? MyColor.primary : MyColor.grey;
    return GestureDetector(
      onTap: () => onTap(),
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: 10,
          vertical: 4,
        ),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(90),
        ),
        child: Row(
          children: [
            AppImage(
              image: onn ? MyImage.auto_renew : MyImage.auto_renew_off,
              height: 10.spMin,
              color: color,
            ),
            sizedBoxW5,
            AppText(
              lang.auto_renew,
              fontSize: 10.spMin,
              color: color,
            )
          ],
        ),
      ),
    );
  }
}

class MyStorageNoData extends StatelessWidget {
  final String? image;

  final String? title;

  final String? subtitle;
  const MyStorageNoData({super.key, this.title, this.subtitle, this.image});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    var grey = context.read<ThemePro>().grey;

    return SafeArea(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: AppImage(
              image: image ?? MyImage.no_storage_data,
              height: MediaQuery.of(context).size.height / 4,
              width: MediaQuery.of(context).size.height / 4,
            ),
          ),
          sizedBoxH10,
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: AppText(
              title ?? "${lang.no_results_found}\n",
              text2: subtitle ?? lang.try_to_use_other_filter,
              maxLines: 5,
              textAlign: TextAlign.center,
              color: Theme.of(context).textTheme.bodyLarge?.color,
              color2: grey,
              fontWeight: FontWeight.w500,
              fontSize: 16.spMin,
              fontSize2: 11.spMin,
            ),
          )
        ],
      ),
    );
  }
}
