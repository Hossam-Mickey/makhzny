import 'package:client_1/provider/account_create_pro/account_create_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/login_pro/login_pro.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../route.dart';

class LoginRegisterText extends StatelessWidget {
  const LoginRegisterText({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    var theme = Theme.of(context);
    var lang = context.read<LangPro>().lang;

    return Center(
      child: AppText(
        "${lang.do_not_have_ac} ",
        text2: lang.register,
        decoration2: TextDecoration.underline,
        fontSize: 15.spMin,
        fontWeight: FontWeight.w400,
        fontWeight2: FontWeight.bold,
        color: theme.textTheme.bodyLarge?.color,
        color2: theme.primaryColor,
        decorationColor: theme.primaryColor,
        onTapText2: () {
          var loc = GoRouter.of(context).location();
          context.read<LoginPro>().stopTimer();
          context.read<AccountCreatePro>().setNumber();
          context.go("$loc/account");
        },
      ),
    );
  }
}
