import 'package:client_1/constants/image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../widgets/app_image.dart';

class NumericKeypad extends StatefulWidget {
  final TextEditingController controller;

  const NumericKeypad({super.key, required this.controller});

  @override
  State<NumericKeypad> createState() => _NumericKeypadState();
}

class _NumericKeypadState extends State<NumericKeypad> {
  late TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = widget.controller;
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      alignment: Alignment.center,
      color: Colors.transparent,
      constraints: const BoxConstraints(maxHeight: 340),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              _buildButton('1'),
              _buildButton('2'),
              _buildButton('3'),
            ],
          ),
          SizedBox(height: 20.h),
          Row(
            children: [
              _buildButton('4'),
              _buildButton('5'),
              _buildButton('6'),
            ],
          ),
          SizedBox(height: 20.h),
          Row(
            children: [
              _buildButton('7'),
              _buildButton('8'),
              _buildButton('9'),
            ],
          ),
          SizedBox(height: 20.h),
          Row(
            children: [
              const Expanded(child: SizedBox()),
              _buildButton('0'),
              Expanded(
                child: MaterialButton(
                  onPressed: _backspace,
                  child: SizedBox(
                    height: 25,
                    width: 25,
                    child: AppImage(
                      image: MyImage.keypad_back,
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                ),
              )
                  .animate()
                  .fade(duration: 1000.milliseconds)
                  .shimmer(duration: 1000.milliseconds),
            ],
          ),
        ],
      ),
    );
  }

  // Individual keys
  Widget _buildButton(String text, {VoidCallback? onPressed}) {
    return Expanded(
      child: MaterialButton(
        onPressed: onPressed ?? () => _input(text),
        child: AppText(
          text,
          fontSize: 20.spMin,
          fontWeight: FontWeight.bold,
        ),
      ),
    )
        .animate()
        .fade(duration: 1000.milliseconds)
        .shimmer(duration: 1000.milliseconds);
  }

  void _input(String text) {
    final value = _controller.text + text;
    _controller.text = value;
  }

  void _backspace() {
    final value = _controller.text;
    if (value.isNotEmpty) {
      _controller.text = value.substring(0, value.length - 1);
    }
  }
}
