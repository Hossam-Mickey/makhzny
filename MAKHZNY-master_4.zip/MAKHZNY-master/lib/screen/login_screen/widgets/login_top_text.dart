import 'package:client_1/constants/colors.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../route.dart';

class LoginTopText extends StatelessWidget {
  const LoginTopText({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    var location = GoRouter.of(context).location();
    var isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (location != "/login" || location != "/account")
            GestureDetector(
              onTap: () => context.pop(),
              child: Container(
                alignment: Alignment.centerLeft,
                color: Colors.transparent,
                height: 40,
                width: 40,
                child: const Icon(
                  Icons.arrow_back_ios_new,
                  size: 16,
                ),
              ),
            ),
          if (location != "/login" &&
              context.read<LangPro>().direction == TextDirection.rtl)
            sizedBoxW20,
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AppText(
                  lang.welcome_to,
                  text2: lang.app_name,
                  text3: "  ! 👋🏼",
                  fontSize: 22.spMin,
                  maxLines: 3,
                  color: isDark ? Colors.white : Colors.black,
                  color2: MyColor.primary,
                ),
                AppText(
                  lang.dont_miss_the_opportunity,
                  fontSize: 14.spMin,
                  maxLines: 3,
                  color: MyColor.grey,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
