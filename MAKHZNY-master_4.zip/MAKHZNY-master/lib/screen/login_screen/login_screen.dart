import 'package:client_1/constants/colors.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/country_picker_pro/country_picker_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/login_pro/login_pro.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/loader.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import 'widgets/login_numbericpad.dart';
import 'widgets/login_register_text.dart';
import 'widgets/login_top_text.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    var media = MediaQuery.of(context).size;
    var isDark = Theme.of(context).brightness == Brightness.dark;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        systemNavigationBarColor: Theme.of(context).primaryColor,
      ),
      child: Scaffold(
        body: Consumer<LoginPro>(
          child: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: 50.dg > 50 ? 50 :50.dg),
                const LoginTopText(),
                SizedBox(height: 100.dg > 100 ? 100 :100.dg),
                Expanded(
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: isDark ? Colors.grey.shade800 : Colors.white,
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(25),
                        topRight: Radius.circular(25),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: MyColor.grey.withOpacity(0.5),
                          spreadRadius: 1,
                          blurRadius: 20,
                          blurStyle: BlurStyle.outer,
                        )
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: media.height / 15),
                          AppText(
                            lang.enter_your_phone_number,
                            color: MyColor.grey,
                          ),
                          Directionality(
                            textDirection: TextDirection.ltr,
                            child: TextField(
                              keyboardType: TextInputType.none,
                              controller: context.read<LoginPro>().controller,
                              readOnly: true,
                              style: TextStyle(
                                fontFamily: context.read<ThemePro>().font,
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                              ),
                              decoration: InputDecoration(
                                hintText: lang.enter_number,
                                hintStyle: TextStyle(
                                  color: MyColor.grey,
                                  fontFamily: context.read<ThemePro>().font,
                                  fontWeight: FontWeight.bold,
                                ),
                                prefixIcon: Consumer<CountryPickerPro>(
                                  builder: (_, v, w) {
                                    return InkWell(
                                      onTap: () => v.pickCountry(context),
                                      child: Padding(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 10,
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            SizedBox(
                                              child: v.getflagWidget(
                                                v.loginCountry,
                                                context,
                                              ),
                                            ),
                                            const Icon(Icons.keyboard_arrow_down_rounded)
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ),
                          ),
                          sizedBoxH30,
                          Expanded(
                            child: NumericKeypad(
                              controller: context.read<LoginPro>().controller,
                            ),
                          ),
                          sizedBoxH20,
                          const LoginRegisterText(),
                          sizedBoxH30,
                        ],
                      ),
                    ),
                  ),
                ),
                AppButton(
                  text: lang.next,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(12),
                    topRight: Radius.circular(12),
                  ),
                  fontWeight: FontWeight.w500,
                  onPressed: () {
                    context.read<LoginPro>().login();
                  },
                ),
              ],
            ),
          ),
          builder: (_, v, w) {
            return PopScope(
              canPop: !v.loading,
              child: Stack(
                children: [
                  w!,
                  if (v.loading) const Loader(),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
