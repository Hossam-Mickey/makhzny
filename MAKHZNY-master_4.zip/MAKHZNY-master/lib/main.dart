import 'package:client_1/functions/life_cycle.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/hive/main_hive.dart';
import 'package:client_1/provider/account_create_pro/account_create_pro.dart';
import 'package:client_1/provider/add_card_pro/add_card_pro.dart';
import 'package:client_1/provider/carousel_pro/carousel_pro.dart';
import 'package:client_1/provider/checkout_pro.dart';
import 'package:client_1/provider/company_pro/company_pro.dart';
import 'package:client_1/provider/country_picker_pro/country_picker_pro.dart';
import 'package:client_1/provider/current_route_pro/current_route_pro.dart';
import 'package:client_1/provider/dammam_units_pro/dammam_units_pro.dart';
import 'package:client_1/provider/doc_delete_pro/doc_delete_pro.dart';
import 'package:client_1/provider/document_pro/document_pro.dart';
import 'package:client_1/provider/download_pro.dart';
import 'package:client_1/provider/home_elevation_pro.dart';
import 'package:client_1/provider/message_pro.dart';
import 'package:client_1/provider/my_units_pro/my_units_pro.dart';
import 'package:client_1/provider/quote_pro.dart';
import 'package:client_1/provider/rent_checkout_pro/rent_checkout_pro.dart';
import 'package:client_1/provider/riyadh_units_pro/riyadh_units_pro.dart';
import 'package:client_1/provider/invoice_pro/invoice_pro.dart';
import 'package:client_1/provider/jeddah_units_pro/jeddah_units_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/login_pro/login_pro.dart';
import 'package:client_1/provider/signature_pro/signature_pro.dart';
import 'package:client_1/provider/splash_init_pro.dart';
import 'package:client_1/provider/storage_pro/storage_pro.dart';
import 'package:client_1/provider/store_pro/store_pro.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/provider/user_pro/user_pro.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import 'package:universal_platform/universal_platform.dart';
import 'constants/string.dart';
import 'provider/add_cart_pro/add_cart_pro.dart';
import 'route.dart';
import 'package:window_manager/window_manager.dart';

final GlobalKey<ScaffoldMessengerState> messangerKey =
    GlobalKey<ScaffoldMessengerState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (UniversalPlatform.isWindows) {
    await windowManager.ensureInitialized();
    var size = const Size(750, 550);
    WindowOptions windowOptions = WindowOptions(size: size, center: true);
    windowManager.waitUntilReadyToShow(windowOptions, () async {
      await windowManager.show();
      await windowManager.focus();
      await windowManager.setAlignment(Alignment.center);
    });
  }

  AppLifecycleObserver();
  ThemeObserver();
  setUp();
  await mainHive();

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      systemNavigationBarColor: Colors.white,
      statusBarColor: Colors.transparent,
      systemNavigationBarDividerColor: Colors.transparent,
      systemNavigationBarIconBrightness: Brightness.dark,
      statusBarIconBrightness: Brightness.dark,
    ),
  );
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitDown,
    DeviceOrientation.portraitUp,
  ]);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemePro()),
        ChangeNotifierProvider(create: (_) => LoginPro()),
        ChangeNotifierProvider(create: (_) => CountryPickerPro()),
        ChangeNotifierProvider(create: (_) => LangPro()..init()),
        ChangeNotifierProvider(create: (_) => CurrentRoutePro()),
        ChangeNotifierProvider(create: (_) => StoragePro()),
        ChangeNotifierProvider(create: (_) => StorePro()),
        ChangeNotifierProvider(create: (_) => AddCartPro()),
        ChangeNotifierProvider(create: (_) => InvoicePro()),
        ChangeNotifierProvider(create: (_) => AddCardPro()),
        ChangeNotifierProvider(create: (_) => AccountCreatePro()),
        ChangeNotifierProvider(create: (_) => CompanyPro()),
        ChangeNotifierProvider(create: (_) => JeddahUnitsPro()),
        ChangeNotifierProvider(create: (_) => RiyadhUnitsPro()),
        ChangeNotifierProvider(create: (_) => DammamUnitsPro()),
        ChangeNotifierProvider(create: (_) => CarouselPro()),
        ChangeNotifierProvider(create: (_) => UserPro()),
        // ChangeNotifierProvider(create: (_) => CartPro()),
        ChangeNotifierProvider(create: (_) => DocumentPro()),
        // ChangeNotifierProvider(create: (_) => PaymentGatewayPro()),
        ChangeNotifierProvider(create: (_) => MyUnitsPro()),
        ChangeNotifierProvider(create: (_) => DownloadPro()),
        // ChangeNotifierProvider(create: (_) => NewUnitsPro()),
        ChangeNotifierProvider(create: (_) => SignaturePro()),
        ChangeNotifierProvider(create: (_) => RentCheckOutPro()),
        ChangeNotifierProvider(create: (_) => DocDeletePro()),
        ChangeNotifierProvider(create: (_) => HomeElevationPro()),
        ChangeNotifierProvider(create: (_) => SplashInitPro()),
        ChangeNotifierProvider(create: (_) => QuotePro()),
        ChangeNotifierProvider(create: (_) => MessagePro()),
        ChangeNotifierProvider(create: (_) => CheckoutPro()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      // minTextAdapt: true,
      ensureScreenSize: true,
      designSize: const Size(400, 900),
      builder: (context, w) {
        return Consumer<ThemePro>(
          builder: (_, v, w) {
            return MaterialApp.router(
              title: MyString.appTitle,
              scaffoldMessengerKey: messangerKey,
              routerConfig: MyRouter.router,
              theme: v.theme,
              darkTheme: v.dark,
              themeMode: v.model,
              debugShowCheckedModeBanner: false,
            );
          },
        );
      },
    );
  }
}

extension StringExtension on String {
  String firstLetterCap() {
    if (isEmpty) return this;

    return this[0].toUpperCase() + substring(1);
  }
}

extension DoubleExtensions on num {
  double get hMin {
    return (h > this ? this : h).toDouble();
  }

  double get wMin {
    return (w > this ? this : w).toDouble();
  }

  double get dgMin {
    return (dg > this ? this : dg).toDouble();
  }

  double get dmMin {
    return (dm > this ? this : dm).toDouble();
  }
}
