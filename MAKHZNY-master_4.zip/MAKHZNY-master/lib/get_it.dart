import 'package:client_1/functions/connectivity_check.dart';
import 'package:client_1/hive/functions/cart_fucntion.dart';
import 'package:client_1/hive/functions/download_hive.dart';
import 'package:get_it/get_it.dart';

final getIt = GetIt.instance;

void setUp() {
  getIt.registerLazySingleton<ConnectivityCheck>(() => ConnectivityCheck());

  getIt.registerLazySingleton<CartHive>(() => CartHive());
  getIt.registerLazySingleton<DownloadHive>(() => DownloadHive());
}
