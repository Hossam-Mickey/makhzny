import 'package:flutter/material.dart';

class AddCardPro extends ChangeNotifier {
  final TextEditingController cardName = TextEditingController();
  final TextEditingController cardNumber = TextEditingController();
  final TextEditingController cardHolderName = TextEditingController();
  final TextEditingController cardCvv = TextEditingController();
  final TextEditingController cardExpire = TextEditingController();

  final FocusNode cardNameF = FocusNode();
  final FocusNode cardNumberF = FocusNode();
  final FocusNode cardHolderF = FocusNode();
  final FocusNode cardCvvF = FocusNode();
  final FocusNode cardExpireF = FocusNode();
}
