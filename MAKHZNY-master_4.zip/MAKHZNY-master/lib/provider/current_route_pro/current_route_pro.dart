import 'package:client_1/functions/print_c.dart';
import 'package:client_1/route.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class CurrentRoutePro extends ChangeNotifier {
  var loc = "";
  void listern() {
    var context = navigatorKey.currentContext!;
    MyRouter.router.routerDelegate.addListener(() {
      var loc = GoRouter.of(context).location();
      printC(loc, color: PColor.white);
      this.loc = loc;
      notifyListeners();
    });
   
  }
}
