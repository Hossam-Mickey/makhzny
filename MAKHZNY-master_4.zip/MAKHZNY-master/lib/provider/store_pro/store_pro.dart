import 'package:flutter/material.dart';

class StorePro extends ChangeNotifier {
  int selected = 0;

  void changeSelected(int s) {
    if (s == selected) return;
    selected = s;
    notifyListeners();
  }
}
