// import 'package:client_1/constants/api.dart';
// import 'package:client_1/functions/my_dio.dart';
// import 'package:client_1/functions/print_c.dart';
// import 'package:client_1/model/product_model/product_model.dart';
// import 'package:client_1/provider/jeddah_units_pro/jeddah_units_pro.dart';
// import 'package:flutter/material.dart';

// class NewUnitsPro extends ChangeNotifier {
//   final TextEditingController controller = TextEditingController();
//   final FocusNode node = FocusNode();

//   List<ProductModel> _products = [];

//   List<ProductModel> get products {
//     if (controller.text.isEmpty) return _products;
//     var list = _products.where((e) {
//       var text = controller.text.toLowerCase();
//       var contains = e.title.toLowerCase().contains(text);
//       return contains;
//     }).toList();
//     return list;
//   }

//   List<ProductModel> get non_filter_product => _products;

//   // ignore: non_constant_identifier_names
//   // List<ProductModel> get trending_now => _products;

//   void searchUpdate() {
//     notifyListeners();
//   }

//   bool hasError = false;
//   bool loading = false;

//   ProductModel findById(int unitId) {
//     return non_filter_product.where((e) => e.id == unitId).first;
//   }

//   Future<void> getProduct() async {
//     try {
//       return;
//       if (loading) return;
//       loading = true;
//       hasError = false;
//       notifyListeners();
//       var dio = MyDio().dio;
//       var id = 4;
//       var res = await dio.post(API.getProduct, data: {"company_id": id});

//       if (res.statusCode != 200) {
//         hasError = true;
//         loading = false;
//         notifyListeners();
//         return;
//       }

//       notifyListeners();

//       var data = toMap(res.data["result"]["data"] as List);
//       var pro = await toProduct(data, id);

//       _products = pro;
//       hasError = false;
//       loading = false;

//       notifyListeners();
//     } catch (e) {
//       printC(e, from: "P R O D U C T  L O A D", color: PColor.red);
//       hasError = true;
//       loading = false;
//       notifyListeners();
//     }
//   }

//   void remove(int unitId) {
//     _products.removeWhere((e) => e.id == unitId);
//     notifyListeners();
//   }
// }
