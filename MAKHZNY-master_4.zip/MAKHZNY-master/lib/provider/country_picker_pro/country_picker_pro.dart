import 'package:client_1/constants/colors.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:country_picker/country_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CountryPickerPro extends ChangeNotifier {
  // String countryCode = "+966";
  // String loginCountry = "+201";
  String loginCountry = "+966";

  // String personalACCountry = "+966";
  // String bussinusACdCountry = "+966";
  // String bussinusAuthdCountry = "+966";

  void pickCountry(BuildContext context) {
    var isDark = Theme.of(context).brightness == Brightness.dark;
    var style = TextStyle(
      fontFamily: context.read<ThemePro>().font,
      color: isDark ? Colors.white : Colors.black,
      fontWeight: FontWeight.w600,
    );

    showCountryPicker(
      countryListTheme: CountryListThemeData(
        // backgroundColor: MyColor.primary,
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        bottomSheetHeight: MediaQuery.of(context).size.height / 1.5,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
        textStyle: style,
        searchTextStyle: style,
      ),
      context: context,
      onSelect: (value) {
        loginCountry = _getCountry(value);
        // printC(value.toJson());
        notifyListeners();
      },
    );
  }

  Widget getflagWidget(String country, BuildContext context) {
    final bool isRtl = Directionality.of(context) == TextDirection.rtl;
    return SizedBox(
      // the conditional 50 prevents irregularities caused by the flags in RTL mode
      width: isRtl ? 50 : null,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AppText(
            country,
            fontWeight: FontWeight.bold,
            textAlign: TextAlign.center,
            padding: const EdgeInsets.only(top: 2),
            fontSize: 20,
            color: MyColor.grey,
          ),
        ],
      ),
    );
  }

  String _getCountry(Country country) {
    return country.displayName.split('[').last.replaceAll(']', '');
  }
}




// keytool -genkey -v -keystore C:\Users\chach\Downloads\upload-keystore.jks -storetype JKS -keyalg RSA -keysize 2048 -validity 10000 -alias upload

      