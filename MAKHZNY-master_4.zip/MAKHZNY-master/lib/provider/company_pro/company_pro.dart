// ignore_for_file: non_constant_identifier_names

import 'package:flutter/foundation.dart';

class CompanyPro extends ChangeNotifier {
  int get company_id => _company_id;

  int _company_id = 2;

  void changeId(int id) {
    _company_id = id;
    notifyListeners();
  }

  String loc(int id) {
    switch (id) {
      case 2:
        return "Jeddah";
      case 3:
        return "Riyadh";
      case 4:
        return "Dammam";
      default:
        return "Unknow";
    }
  }
}
