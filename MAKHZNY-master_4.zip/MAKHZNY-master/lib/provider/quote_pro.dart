import 'package:flutter/material.dart';

enum QuoteBranchType {
  riyadh,
  dammam,
  jeddah,
}

class QuotePro extends ChangeNotifier {
  QuoteBranchType? branch;
  final List<int> _riyadhArea = [1, 2, 4, 7, 11, 12, 15, 16, 18, 21, 22, 29];
  final List<int> _dammamArea = [1, 3, 4, 6, 7, 9, 10, 12, 13, 17, 18, 19, 20];
  final List<int> _jeddahArea = [
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    11,
    12,
    13,
    14,
    15,
    16,
    18,
    19,
    20,
    22,
  ];
  List<int> get areas {
    if (branch == QuoteBranchType.dammam) return _dammamArea;
    if (branch == QuoteBranchType.riyadh) return _riyadhArea;
    if (branch == QuoteBranchType.jeddah) return _jeddahArea;
    return [];
  }

  final TextEditingController name = TextEditingController();
  final TextEditingController email = TextEditingController();
  final TextEditingController phone = TextEditingController();

  int page = 1;
  void setPage(int page) {
    if (page == this.page) return;
    this.page = page;
    notifyListeners();
  }

  List<int> area = [];
  void setArea(int page) {
    if (area.contains(page)) {
      area.remove(page);
    } else {
      area.add(page);
    }
    notifyListeners();
  }

  void clearArea() {
    area = [];
    notifyListeners();
  }

  void setBranch(QuoteBranchType branch) {
    if (branch == this.branch) return;
    this.branch = branch;
    notifyListeners();
  }

  void clear() {
    name.clear();
    email.clear();
    phone.clear();
    page = 1;
    branch = null;
    area = [];
    notifyListeners();
  }
}
