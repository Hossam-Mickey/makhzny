import 'package:client_1/constants/api.dart';
import 'package:client_1/functions/print_c.dart';
import 'package:client_1/main.dart';
import 'package:client_1/model/product_model/product_model.dart';
import 'package:client_1/provider/user_pro/user_pro.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../functions/my_dio.dart';

class MyUnitsPro extends ChangeNotifier {
  List<ProductModel> _units = [];
  List<ProductModel> get non_filter_units => _units;

  bool hasError = false;
  bool loading = false;
  String errorMes = "";

  List<ProductModel> get jeddahUnits {
    return _units.where((e) => e.company_id == 2).toList();
  }

  List<ProductModel> get riyadhUnits {
    return _units.where((e) => e.company_id == 3).toList();
  }

  List<ProductModel> get dammamUnits {
    return _units.where((e) => e.company_id == 4).toList();
  }

  Future<void> getUnits() async {
    try {
      if (loading) return;
      var user = messangerKey.currentContext!.read<UserPro>().userId;
      if (user == null) return;

      loading = true;
      hasError = false;
      errorMes = "";
      notifyListeners();

      var dio = MyDio().dio;

      // dio.options.baseUrl =
      //     "https://perfectech-me-makhzany1-testing-website-12566830.dev.odoo.com/";

      var body = {"partner_id": user};
      var res = await dio.post(API.get_units, data: body);

      if (res.statusCode != 200) {
        hasError = true;
        loading = false;
        errorMes = "";
        notifyListeners();
        return;
      }

      var data = Map<String, dynamic>.from(res.data);

      if (data.containsKey("error")) {
        hasError = true;
        loading = false;
        errorMes = data["error"]["message"];
        notifyListeners();
        return;
      }

      if (!data.containsKey("result")) {
        hasError = true;
        loading = false;
        errorMes = "";
        notifyListeners();
        return;
      }

      List<ProductModel> models = [];
      var data2 = List<Map<String, dynamic>>.from(data["result"]);
      await Future.forEach(data2, (e) {
        models.add(ProductModel.fromJson(e));
      });

      _units = models;
      hasError = false;
      loading = false;
      errorMes = "";
      notifyListeners();
    } catch (e) {
      printC(e, from: "GET UNITS", color: PColor.red);
      hasError = true;
      errorMes = "";
      loading = false;
      notifyListeners();
    }
  }

  void addToUnits(ProductModel m) {
    _units.insert(0, m);
    notifyListeners();
  }

  void clear() {
    _units = [];
    hasError = false;
    loading = false;
    errorMes = "";
    notifyListeners();
  }
}
