
import 'dart:io';

import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/functions/connectivity_check.dart';
import 'package:client_1/functions/print_c.dart';
import 'package:client_1/functions/show_snakbar.dart';
import 'package:client_1/functions/unique_id.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/model/download_model/download_model.dart';
import 'package:client_1/route.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:go_router/go_router.dart';
import 'package:mime/mime.dart';
import 'package:open_file/open_file.dart';

import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:universal_platform/universal_platform.dart';

import '../hive/functions/download_hive.dart';

class DownloadPro extends ChangeNotifier {
  List<String> loadingIds = [];

  List<DownloadModel> downloadData = [];

  Future<void> loadFromLocal() async {
    try {
      printC("INIT DOWNLOAD");
      var data = await getIt<DownloadHive>().getdata();

      printC("DOWNLOADED FILES ${data.length}");

      downloadData = data;
      notifyListeners();
    } catch (e) {
      printC(e);
    }
  }

  Future<void> dowload({String? fileName, String? link}) async {
    if (!await permissionCheck()) return;
    var connectCheck = getIt<ConnectivityCheck>();
    var network = await connectCheck.getCurrentState();
    if (!network) return;
    var dio = Dio();
    // var url =
    //     "https://assets.mixkit.co/videos/download/mixkit-going-down-a-curved-highway-through-a-mountain-range-41576-4k.mp4";
    var url = link ??
        "https://assets.mixkit.co/videos/download/mixkit-crystal-clear-water-flowing-over-the-sand-51667-medium.mp4";

    if (loadingIds.contains(link)) return;
    loadingIds.add(link!);
    notifyListeners();
    String? extGet = await getExt(dio, link);

    if (extGet == null) {
      loadingIds.remove(link);
      notifyListeners();
      printC("EXT NOT FOUND");
      MySnackBar.show(title: "Failed to download file");
      return;
    }

    var name = "${fileName ?? "down"}.$extGet";

    var slash = UniversalPlatform.isAndroid ? "/" : "\\";
    var directory = await getApplicationSupportDirectory();
    var path = "${directory.path}${slash}caches$slash$name";

    var model = await _geModel(path, url);
    model.token?.cancel();

    model.status.value = DownloadStatus.processing;
    var fileInfo = await getPath(name);
    var token = CancelToken();
    printC(fileInfo);
    model = model.copyWith(
      token: token,
      downloaded_size: ValueNotifier(fileInfo.size),
    );
    var range = fileInfo.size;
    loadingIds.remove(link);
    notifyListeners();
    try {
      _update(model);
      await dio.download(
        model.url,
        fileInfo.path,
        cancelToken: token,
        deleteOnError: false,
        options: Options(
          headers: range == 0 ? null : {'Range': 'bytes=$range-'},
        ),
        onReceiveProgress: (count, total) async {
          var downloaded = count + range;
          var size = model.size == 0 ? total : model.size;
          double progress = ((downloaded / size) * 100);
          if (model.size == 0) {
            model = model.copyWith(size: total);
            _update(model);
          }
          model.progress.value = progress;
          model.downloaded_size.value = downloaded;
          model.status.value = DownloadStatus.running;
          _updateHive(model);
          await _updateHive(model);
        },
      );
      printC("DOWNLOAD COMPLETED NEED TO MERGE");
      await mergeFiles(model.path);
      model.status.value = DownloadStatus.completed;
      model.status.value = DownloadStatus.completed;
      _updateHive(model);
      await _updateHive(model);
      var loc = GoRouter.of(navigatorKey.currentContext!).location();
      if (loc == "/settings/documents") await open(model);
    } on DioException catch (e) {
      if (e.response?.statusCode == 416) {
        await mergeFiles(model.path);
        model.status.value = DownloadStatus.completed;
        await _updateHive(model);
        _updateHive(model);
        var loc = GoRouter.of(navigatorKey.currentContext!).location();
        if (loc == "/settings/documents") await open(model);
        return;
      }
      printC(e.message);
      model.status.value = DownloadStatus.pause;
      _updateHive(model);
      _updateHive(model);
      loadingIds.remove(link);
      notifyListeners();
      MySnackBar.show(title: "Failed to download document");
    }
  }

  Future<bool> permissionCheck() async {
    if (UniversalPlatform.isAndroid) {
      final plugin = DeviceInfoPlugin();
      final android = await plugin.androidInfo;
      if (android.version.sdkInt >= 33) return true;
    }

    if (UniversalPlatform.isIOS) return true;

    var status = await Permission.storage.request();

    if (status != PermissionStatus.granted) {
      showDialog(
        context: navigatorKey.currentContext!,
        builder: (_) => Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          child: const _StoragePermmisonDialog()
              .animate()
              .shimmer(duration: 500.ms)
              .fade(duration: 800.ms),
        ),
      );
    }
    return status == PermissionStatus.granted;
  }

  Future<String?> getExt(Dio dio, String? link) async {
    try {
      var extGet = await dio.get(
        link!,
        options: Options(
          headers: {'range': 'bytes=0-1023'},
          responseType: ResponseType.bytes,
        ),
      );
      var mimeType = lookupMimeType('', headerBytes: extGet.data);
      var ext = mimeType?.split("/").last;
      return ext;
    } catch (e) {
      printC(e,from: "EXT GET",color: PColor.red);
      return null;
    }
  }

  Future<void> pause(String id) async {
    var pos = downloadData.indexWhere((e) => e.id == id);
    if (pos == -1) return;
    var model = downloadData[pos];
    model.status.value = DownloadStatus.pause;
    model.token?.cancel("USER CANCELLED");
    model.status.value = DownloadStatus.pause;
    await _updateHive(model);
    model.status.value = DownloadStatus.pause;
  }

  Future<void> _updateHive(DownloadModel model) async {
    var pos = downloadData.indexWhere((e) => e.id == model.id);
    if (pos == -1) return;
    downloadData.removeAt(pos);
    downloadData.insert(pos, model);
    await getIt<DownloadHive>().delete(model);
    await getIt<DownloadHive>().addData([model]);
  }

  void _update(DownloadModel model) {
    var pos = downloadData.indexWhere((e) => e.id == model.id);
    if (pos == -1) return;
    downloadData.removeAt(pos);
    downloadData.insert(pos, model);
    notifyListeners();
  }

  Future<DownloadModel> _geModel(String fullPath, String url) async {
    var res = downloadData.where((e) => e.url == url);
    if (res.isEmpty) {
      var downloadModel = DownloadModel(
        id: uniqueId(),
        url: url,
        path: fullPath,
        size: 0,
        progress: ValueNotifier(0),
        downloaded_size: ValueNotifier(0),
        meta: {},
        status: ValueNotifier(DownloadStatus.processing),
      );
      await getIt<DownloadHive>().addData([downloadModel]);
      downloadData.add(downloadModel);
      notifyListeners();
      return downloadModel;
    }
    return res.first;
  }

  Future<({String path, int size})> getPath(String name) async {
    var supportDir = await getApplicationSupportDirectory();

    var path = UniversalPlatform.isAndroid
        ? "${supportDir.path}/caches"
        : "${supportDir.path}\\caches";

    var dir = Directory(path);

    if (!await dir.exists()) await dir.create();
    var listSync = dir.listSync();
    var files = listSync.whereType<File>().toList();

    var ext = name.split(".").last;
    var fileName = name.split(".").first;

    var windowPath = "$path\\${fileName}_1.$ext";
    var androidPath = "$path/${fileName}_1.$ext";

    if (files.isEmpty) {
      return (
        path: UniversalPlatform.isAndroid ? androidPath : windowPath,
        size: 0,
      );
    }

    int count = 1;
    int size = 0;

    await Future.forEach(files, (e) async {
      var path = e.path;
      var split = UniversalPlatform.isAndroid ? path.split("/") : path.split("\\");

      var n = split[split.length - 1];
      var ext = n.split(".").last;
      n = n.replaceRange(n.length - ext.length - 1, n.length, "");
      if (n.startsWith(fileName)) {
        count += 1;
        size += await e.length();
      }
    });

    var windowPath1 = "$path\\${fileName}_$count.$ext";
    var androidPath1 = "$path/${fileName}_$count.$ext";
    return (path: UniversalPlatform.isAndroid ? androidPath1 : windowPath1, size: size);
  }

  Future<void> mergeFiles(String mergedFilePath) async {
    File mergedFile = File(mergedFilePath);
    IOSink sink = mergedFile.openWrite(mode: FileMode.append);
    var slash = UniversalPlatform.isAndroid ? "/" : "\\";

    var split = UniversalPlatform.isAndroid
        ? mergedFilePath.split(slash)
        : mergedFilePath.split(slash);
    var name = split.last;
    var ext = name.split(".").last;
    var realName = name;
    var path = await getPath(name);
    split = UniversalPlatform.isAndroid ? path.path.split("/") : path.path.split("\\");
    name = split.last.split(".").first;
    var count = int.parse(name.replaceAll("${realName.split(".").first}_", ''));
    List<File> files = [];
    for (var i = 1; i <= count; i++) {
      var p = UniversalPlatform.isAndroid
          ? mergedFilePath.split(slash)
          : mergedFilePath.split(slash);
      p.removeAt(p.length - 1);
      var pa = "${p.join(slash)}$slash${realName.split(".").first}_$i.$ext";

      if (await File(pa).exists()) files.add(File(pa));
    }
    try {
      for (File file in files) {
        Stream<List<int>> inputStream = file.openRead();
        await for (List<int> data in inputStream) {
          sink.add(data);
        }
      }
    } finally {
      await Future.value(
        List.generate(files.length, (i) => files[i].delete()),
      );
      await sink.close();
    }
  }

  Future<void> resume(String id) async {
    var where = downloadData.where((e) => e.id == id);
    if (where.isEmpty) return;
    var model = where.first;
    await dowload(fileName: model.fileName, link: model.url);
  }

  // Future<bool> checkStoragePermission() async {
  //   if (UniversalPlatform.isAndroid) {
  //     final DeviceInfoPlugin deviceInfoPlugin = DeviceInfoPlugin();
  //     final AndroidDeviceInfo info = await deviceInfoPlugin.androidInfo;
  //     if (info.version.sdkInt >= 29) {
  //       var res = await Permission.manageExternalStorage.request();
  //       return res.isGranted;
  //     }
  //   }
  //   var res = await Permission.storage.request();
  //   return res.isGranted;
  // }

  Future<void> open(DownloadModel model) async {
    try {
      // if (!await permissionCheck()) return;

      // var r = await getIt<DownloadHive>().getdata();
      // if (r.where((e) => e.id == model.id).isEmpty) await _updateHive(model);

      var path = model.path;
      var file = File(path);
      var exist = await file.exists();
      if (!exist) {
        var dir = file.parent;
        var dirFiles = dir.listSync().whereType<File>();
        for (var f in dirFiles) {
          var name = f.path.split("/").last.split(".").first;
          var modelName = model.fileName.split(".").first;
          if (name.contains(modelName)) await f.delete();
        }
        await _deleteLocal(model.id);
        await dowload(fileName: model.fileName, link: model.url);
        return;
      }
      await OpenFile.open(path);
    } catch (e) {
      printC(e);
    }
  }

  Future<void> _deleteLocal(String id) async {
    var pos = downloadData.indexWhere((e) => e.id == id);
    if (pos == -1) return;
    var model = downloadData[pos];
    downloadData.removeAt(pos);
    await getIt<DownloadHive>().delete(model);
  }

  Future<void> add(List<DownloadModel> dm) async {
    await Future.forEach(dm, (ee) async {
      downloadData.where((e) => e.id == ee.id);
      downloadData.removeWhere((e) => e.id == ee.id);
      await getIt<DownloadHive>().delete(ee);
    });
    downloadData.addAll(dm);
    await getIt<DownloadHive>().addData(dm);
  }

  DownloadModel? getByUrl(String s) {
    var res = downloadData.where((e) => e.url == s);
    if (res.isEmpty) return null;
    return res.first;
  }
}

class _StoragePermmisonDialog extends StatelessWidget {
  const _StoragePermmisonDialog();

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 500, maxHeight: 1500),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          sizedBoxH20,
          const AppImage(
            image: "assets/image/storage_permission.svg",
            height: 150,
            // width: 150,
          ),
          sizedBoxH10,
          AppText(
            "Storage Permission",
            fontSize: 13.spMax,
            fontWeight: FontWeight.bold,
          ),
          AppText(
            "Require storage permmsion to download documents on your device",
            fontSize: 12.spMax,
            padding: const EdgeInsets.symmetric(horizontal: 15),
            maxLines: 8,
            textAlign: TextAlign.center,
            fontWeight: FontWeight.w400,
            color: Colors.grey.shade600,
          ),
          sizedBoxH20,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              AppButton(
                width: 90,
                height: 35,
                borderRadius: BorderRadius.circular(8),
                text: "Cancel",
                fontWeight: FontWeight.bold,
                fontSize: 12,
                onPressed: () {
                  Navigator.pop(context);
                },
              ),
              AppButton(
                width: 90,
                height: 35,
                borderRadius: BorderRadius.circular(8),
                text: "Allow",
                fontWeight: FontWeight.bold,
                fontSize: 12,
                onPressed: () async {
                  await openAppSettings();
                  // ignore: use_build_context_synchronously
                  Navigator.pop(context);
                },
              ),
            ],
          ),
          sizedBoxH20,
        ],
      ),
    );
  }
}
