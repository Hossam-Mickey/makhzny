import 'package:flutter/material.dart';

class StoragePro extends ChangeNotifier {
  int selected = 0;
  
  void changeSelected(int s) {
    if (s == selected) return;
    selected = s;
    notifyListeners();
  }
}
