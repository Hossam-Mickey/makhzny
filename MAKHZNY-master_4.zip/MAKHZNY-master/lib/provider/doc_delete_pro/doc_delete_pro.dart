import 'package:client_1/functions/connectivity_check.dart';
import 'package:client_1/functions/my_dio.dart';
import 'package:client_1/functions/print_c.dart';
import 'package:client_1/functions/show_snakbar.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/model/document_model/document_model.dart';
import 'package:client_1/provider/document_pro/document_pro.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import '../../main.dart';

class DocDeletePro extends ChangeNotifier {
  List<int> ids = [];

  Future<void> delete(DocumentModel model) async {
    try {
      var connectCheck = getIt<ConnectivityCheck>();
      var network = await connectCheck.getCurrentState();
      if (!network) return;
      ids.add(model.id);
      notifyListeners();
      var dio = MyDio().dio;
      await dio.get(model.deleteurlWithBase);
      ids.remove(model.id);
      messangerKey.currentContext?.read<DocumentPro>().remove(model);
      notifyListeners();
    } catch (e) {
      printC(e, from: "DELETE DOC", color: PColor.red);
      ids.remove(model.id);
      notifyListeners();
      MySnackBar.show(title: "Document delete failed");
    }
  }
}
