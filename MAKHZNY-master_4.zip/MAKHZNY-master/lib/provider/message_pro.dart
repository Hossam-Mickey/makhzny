import 'package:flutter/material.dart';

class MessagePro extends ChangeNotifier{
  final TextEditingController controller = TextEditingController();
}