// ignore_for_file: use_build_context_synchronously

import 'package:client_1/constants/api.dart';
import 'package:client_1/functions/my_dio.dart';
import 'package:client_1/functions/preference.dart';
import 'package:client_1/functions/print_c.dart';
import 'package:client_1/functions/show_snakbar.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/main.dart';
import 'package:client_1/model/user_model/user_model.dart';
import 'package:client_1/model/user_show_model/user_show_model.dart';
import 'package:client_1/provider/account_create_pro/account_create_pro.dart';
import 'package:client_1/provider/country_picker_pro/country_picker_pro.dart';
import 'package:client_1/provider/document_pro/document_pro.dart';
import 'package:client_1/provider/invoice_pro/invoice_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/my_units_pro/my_units_pro.dart';
import 'package:client_1/route.dart';
import 'package:client_1/screen/no_login_screen/no_login_screen.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../functions/connectivity_check.dart';

class UserPro extends ChangeNotifier {
  int? userId;
  UserShowModel? userShow;

  String? errorMes;
  bool get isLogin => userId != null;

  bool loading = false;
  bool hasError = false;

  void setUser(int? id) {
    printC("SET USER $id", color: PColor.white);
    // userId = model.partner_id;
    // Preference.setUser(model);
    // notifyListeners();
    userId = id;
    Preference.setUser(id);
    notifyListeners();
  }

  Future<void> loadUserLocal() async {
    var res = await Preference.getUser();
    var show = await Preference.getUserShow();
    // 3538
    printC(res);
    // hossan 3615
    if (kDebugMode) {
      res = 3574;
      // res = 3575; // test
    }
    userId = res;
    userShow = show;
    notifyListeners();
  }

  Future<void> registerUser() async {
    var context = navigatorKey.currentContext!;
    var acPro = context.read<AccountCreatePro>();
    var isPersonal = acPro.selected == 0;

    var notValid = isPersonal ? _validatePersonal() : _validateBusiness();
    if (notValid) return;

    var name = isPersonal ? acPro.full_name.text : acPro.company_name.text;
    var email = isPersonal ? acPro.email.text : acPro.company_email.text;
    var idNumber =
        isPersonal ? acPro.id_number.text : acPro.company_id_number.text;

    var countryCode = context.read<CountryPickerPro>().loginCountry;
    // var phone = countryCode + context.read<LoginPro>().controller.text;
    var phone =
        isPersonal ? acPro.mobile_number.text : acPro.company_phone.text;

    var dobCheck = acPro.dob.text.isNotEmpty;
    var year = isPersonal && dobCheck ? acPro.dob.text.split("/").last : "";

    var month = isPersonal && dobCheck
        ? acPro.dob.text.split("/")[1].padLeft(2, "0")
        : "";

    var day = isPersonal && dobCheck
        ? acPro.dob.text.split("/").first.padLeft(2, "0")
        : "";

    var dob =
        isPersonal && dobCheck ? DateTime.tryParse("$year-$month-$day") : null;

    var authName = isPersonal ? "" : acPro.auth_person_name.text;
    var authPhone =
        isPersonal ? acPro.mobile_number.text : acPro.auth_person_number.text;
    var vat = isPersonal ? "" : acPro.vat_reg.text;
    var crNumber = isPersonal ? "" : acPro.cr_number.text;
    var address = isPersonal ? acPro.address.text : "";

    var otpNumber =
        isPersonal ? acPro.otp_number.text : acPro.business_otp_number.text;
    var model = UserModel(
      name: name,
      phone: countryCode + phone,
      email: email,
      id_number: idNumber.isEmpty ? "null" : idNumber,
      dob: dob,
      auth_name: authName,
      auth_phone: countryCode + authPhone,
      vat: vat,
      cr_number: crNumber,
      address: address,
      otp_number: otpNumber,
      // company_phone: companyPhone,
    );

    if (isPersonal) {
      var res = await _register(model);
      if (res) context.pushReplacement("/home");
    } else {
      var docPro = context.read<DocumentPro>();
      bool res;

      if (context.read<UserPro>().userId == null) {
        res = await _register(model);
        if (res == false) return;
      } else {
        res = true;
      }

      if (docPro.pickedFiles.isNotEmpty) {
        loading = true;
        notifyListeners();
        docPro.convertAllToSelected();
        var doc = await docPro.upload();
        loading = false;
        notifyListeners();
        if (doc == false) return;
      }

      if (res) context.pushReplacement("/home");
    }
  }

  Future<bool> _register(UserModel model) async {
    var context = navigatorKey.currentContext!;
    var lang = context.read<LangPro>().lang;
    try {
      Focus.of(context).unfocus();
      Map<String, dynamic> json = model.toJson();
      json.removeWhere((k, v) => v.toString().isEmpty);
      json = json.map(
          (k, v) => v.toString() == "null" ? MapEntry(k, "") : MapEntry(k, v));
      json.remove("partner_id");
      var acPro = context.read<AccountCreatePro>();

      json["nature_of_goods_stored"] = acPro.nature_of_goods.text;

      var connectCheck = getIt<ConnectivityCheck>();
      var network = await connectCheck.getCurrentState();
      if (!network) return false;

      loading = true;
      notifyListeners();

      var dio = MyDio().dio;

      printC("REGISTER");
      printC("HTTP CALL : ${dio.options.baseUrl}${API.register}");
      printC("BODY : $json");

      var res = await dio.post(API.register, data: json);

      if (res.statusCode != 200) {
        MySnackBar.show(title: lang.something_went_wrong);
        loading = false;
        notifyListeners();
        return false;
      }
      printC("RESPONSE : ${res.data}");

      var data = res.data["result"] as Map;
      if (data.containsKey("error")) {
        MySnackBar.show(title: data["error"]);
        loading = false;
        notifyListeners();
        return false;
      }

      var partnerId = data["partner_id"];
      model = model.copyWith(partner_id: partnerId);

      if (partnerId != null) setUser(partnerId);
      loading = false;
      notifyListeners();
      // LOGIN INIT
      loginInit();
      return true;
    } catch (e) {
      printC(e, from: "USER REGISTER", color: PColor.red);
      MySnackBar.show(title: lang.something_went_wrong);
      loading = false;
      notifyListeners();
      return false;
    }
  }

  void loginInit() {
    var context = messangerKey.currentContext!;
    context.read<MyUnitsPro>().getUnits();
    context.read<InvoicePro>().getInvoices();
    context.read<DocumentPro>().getUploaded();
    loadUser();
  }

  bool _validatePersonal() {
    var context = navigatorKey.currentContext!;
    var lang = context.read<LangPro>().lang;
    var acPro = context.read<AccountCreatePro>();
    if (acPro.full_name.text.isEmpty) {
      MySnackBar.show(title: lang.enter_full_name);
      return true;
    }
    // if (acPro.id_number.text.isEmpty) {
    //   MySnackBar.show(title: lang.enter_id_number);
    //   return true;
    // }
    // if (acPro.dob.text.isEmpty) {
    //   MySnackBar.show(title: lang.enter_dob);
    //   return true;
    // }

    var dob = acPro.dob.text.split("/");
    if (acPro.dob.text.isNotEmpty && dob.length != 3) {
      MySnackBar.show(title: lang.invalid_dob);
      return true;
    }

    // YEAR CHECK
    if (acPro.dob.text.isNotEmpty &&
        int.parse(dob.last) >= DateTime.now().year) {
      MySnackBar.show(title: lang.invalid_dob);
      return true;
    }

    // MONTH CHECK
    if (acPro.dob.text.isNotEmpty && int.parse(dob[1]) > 12) {
      MySnackBar.show(title: lang.invalid_dob);
      return true;
    }

    // DAY CHECK
    if (acPro.dob.text.isNotEmpty && int.parse(dob.first) > 31) {
      MySnackBar.show(title: lang.invalid_dob);
      return true;
    }

    if (acPro.address.text.isEmpty) {
      MySnackBar.show(title: lang.enter_address);
      return true;
    }

    if (acPro.mobile_number.text.isEmpty) {
      MySnackBar.show(title: lang.enter_phone_number);
      return true;
    }

    if (acPro.email.text.isEmpty) {
      MySnackBar.show(title: lang.enter_email);
      return true;
    }

    if (acPro.nature_of_goods.text.isEmpty) {
      MySnackBar.show(title: lang.nature_of_goods_stored);
      return true;
    }

    if (!EmailValidator.validate(acPro.email.text)) {
      MySnackBar.show(title: lang.invalid_email);
      return true;
    }

    if (acPro.otp_number.text.isEmpty) {
      MySnackBar.show(title: lang.enter_otp_number);
      return true;
    }
    // if (acPro.auth_person_number.text.isEmpty) {
    //     MySnackBar.show(title: lang.enter_auth_number);
    //     return true;
    //   }
    return false;
  }

  bool _validateBusiness() {
    var context = navigatorKey.currentContext!;
    var lang = context.read<LangPro>().lang;
    var acPro = context.read<AccountCreatePro>();
    if (acPro.company_name.text.isEmpty) {
      MySnackBar.show(title: lang.enter_company_name);
      return true;
    }

    if (acPro.cr_number.text.isEmpty) {
      MySnackBar.show(title: lang.enter_cr_number);
      return true;
    }

    if (acPro.vat_reg.text.isEmpty) {
      MySnackBar.show(title: lang.enter_vat_register);
      return true;
    }
    if (acPro.company_phone.text.isEmpty) {
      MySnackBar.show(title: lang.enter_company_phone);
      return true;
    }

    if (acPro.company_email.text.isEmpty) {
      MySnackBar.show(title: lang.enter_company_email);
      return true;
    }

    if (acPro.auth_person_name.text.isEmpty) {
      MySnackBar.show(title: lang.auth_person_name);
      return true;
    }

    if (acPro.company_id_number.text.isEmpty) {
      MySnackBar.show(title: lang.enter_id_number);
      return true;
    }

    if (acPro.auth_person_number.text.isEmpty) {
      MySnackBar.show(title: lang.enter_auth_number);
      return true;
    }

    if (acPro.business_otp_number.text.isEmpty) {
      MySnackBar.show(title: lang.enter_otp_number);
      return true;
    }
    if (acPro.nature_of_goods.text.isEmpty) {
      MySnackBar.show(title: lang.nature_of_goods_stored);
      return true;
    }
    // if (acPro.auth_person_number.text.isEmpty) {
    //     MySnackBar.show(title: lang.enter_auth_number);
    //     return true;
    //   }
    return false;
  }

  void notLoginDialog() {
    var context = navigatorKey.currentContext!;
    showDialog(
      context: context,
      builder: (_) => const Dialog.fullscreen(
        child: NoLoginScreen(needPop: true),
      ),
    );
  }

  Future<void> logout([bool toast = true]) async {
    // messangerKey.currentContext?.read<CartPro>().clearAll();
    var context = messangerKey.currentContext!;
    context.read<MyUnitsPro>().clear();
    context.read<InvoicePro>().clear();
    context.read<DocumentPro>().clear();
    loading = false;
    hasError = false;
    errorMes = null;
    setUser(null);
    await Preference.setUserShow(null);
    if (toast) MySnackBar.show(title: "Logout success");
  }

  Future<void> loadUser([bool fromRefersh = false]) async {
    try {
      if (loading) return;
      if (userId == null) return;
      if (userShow == null || fromRefersh) {
        loading = true;
        notifyListeners();
      }
      hasError = false;
      errorMes = "";
      notifyListeners();

      var dio = MyDio().dio;

      // dio.options.baseUrl =
      //     "https://perfectech-me-makhzany1-testing-website-12566830.dev.odoo.com/";

      var body = {"partner_id": userId};
      var res = await dio.post(API.partner_info, data: body);

      if (res.statusCode != 200) {
        hasError = true;
        loading = false;
        errorMes = "";
        notifyListeners();
        return;
      }

      var data = Map<String, dynamic>.from(res.data);

      if (data.containsKey("error")) {
        hasError = true;
        loading = false;
        errorMes = data["error"]["message"];
        notifyListeners();
        return;
      }

      if (!data.containsKey("result")) {
        hasError = true;
        loading = false;
        errorMes = "";
        notifyListeners();
        return;
      }

      var result = data["result"];
      var model = UserShowModel.fromJson(result);
      userShow = model;
      hasError = false;
      loading = false;
      errorMes = "";
      Preference.setUserShow(model);
      notifyListeners();
    } catch (e) {
      printC(e, from: "GET USER INFO", color: PColor.red);
      hasError = true;
      errorMes = "";
      loading = false;
      notifyListeners();
    }
  }

  Future<void> deleteAccount() async {
    var context = navigatorKey.currentContext!;
    var connectCheck = getIt<ConnectivityCheck>();
    var lang = context.read<LangPro>().lang;
    var network = await connectCheck.getCurrentState();
    if (!network) return;
    try {
      loading = true;
      notifyListeners();
      var dio = MyDio().dio;
      var res = await dio.post(
        API.delete_account,
        data: {"partner_id": userId},
      );
      var data = res.data;
      printC(data);
      if (res.statusCode != 200 || data["result"]["partner_id"] != userId) {
        loading = false;
        notifyListeners();
        MySnackBar.show(title: lang.something_went_wrong);
        return;
      }
      await logout(false);
      loading = false;
      notifyListeners();
      MySnackBar.show(title: "Account deleted successfully");
    } catch (e) {
      printC(e, from: "DELETE ACCOUNT", color: PColor.red);
      loading = false;
      notifyListeners();
      MySnackBar.show(title: lang.something_went_wrong);
    }
  }
}
