import 'package:client_1/functions/splash_init.dart';
import 'package:client_1/route.dart';
import 'package:flutter/material.dart';

class SplashInitPro extends ChangeNotifier {
  bool initialized = false;

  Future<void> init() async {
    var context = navigatorKey.currentContext!;
    await SplashInit.init(context);
    initialized = true;
    notifyListeners();
  }
}
