import 'package:flutter/widgets.dart';

class CarouselPro extends ChangeNotifier {

  // List<CarouselModel> carousel = [];
  
  List<String> carousel = [
    "assets/dummy/1.jpg",
    "assets/dummy/2.jpg",
    "assets/dummy/3.jpg",

  ];


  bool hasError = false;
  bool loading = false;
  String errorMes = "";

  Future<void> getCarousel() async {
  //   try {
  //     if (loading) return;

  //     loading = true;
  //     hasError = false;
  //     errorMes = "";
  //     notifyListeners();

  //     var dio = MyDio().dio;

  //     // dio.options.baseUrl =
  //     //     "https://perfectech-me-makhzany1-testing-website-12566830.dev.odoo.com/";

  //     var body = {};
  //     var res = await dio.post(API.get_offers, data: body);

  //     if (res.statusCode != 200) {
  //       hasError = true;
  //       loading = false;
  //       errorMes = "";
  //       notifyListeners();
  //       return;
  //     }

  //     var data = Map<String, dynamic>.from(res.data);

  //     if (data.containsKey("error")) {
  //       hasError = true;
  //       loading = false;
  //       errorMes = data["error"]["message"];
  //       notifyListeners();
  //       return;
  //     }

  //     if (!data.containsKey("result")) {
  //       hasError = true;
  //       loading = false;
  //       errorMes = "";
  //       notifyListeners();
  //       return;
  //     }

  //     List<CarouselModel> models = [];
  //     var data2 = List<Map<String, dynamic>>.from(data["result"]);
  //     await Future.forEach(data2, (e) {
  //       models.add(CarouselModel.fromJson(e));
  //     });

  //     carousel = models;
  //     hasError = false;
  //     loading = false;
  //     errorMes = "";
  //     notifyListeners();
  //   } catch (e) {
  //     printC(e, from: "GET CAROUSEL", color: PColor.red);
  //     hasError = true;
  //     errorMes = "";
  //     loading = false;
  //     notifyListeners();
  //   }
  }
}
