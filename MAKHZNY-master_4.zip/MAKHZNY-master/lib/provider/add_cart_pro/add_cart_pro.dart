// ignore_for_file: constant_identifier_names

import 'package:client_1/model/cart_model/cart_model.dart';
import 'package:client_1/model/product_model/product_model.dart';
import 'package:client_1/provider/rent_checkout_pro/rent_checkout_pro.dart';
import 'package:client_1/provider/user_pro/user_pro.dart';
import 'package:client_1/route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

enum InvoicePeriod {
  montly(discount: 0, duration: 1),
  quaterly(discount: 5, duration: 3),
  semi_annual(discount: 15, duration: 6),
  annual(discount: 35, duration: 12);

  final double discount;
  final int duration;

  const InvoicePeriod({required this.discount, required this.duration});
}

class AddCartPro extends ChangeNotifier {
  InvoicePeriod period = InvoicePeriod.montly;
  int quantity = 1;
  DateTime startDate = DateTime.now();

  void changeQuantity(int q, [int? max]) {
    if (quantity == max) return;
    if (q == 0) return;
    quantity = q;
    notifyListeners();
  }

  void changePeriod(InvoicePeriod pe) {
    if (pe == period) return;
    period = pe;
    notifyListeners();
  }

  void clear({int? qty, InvoicePeriod? period}) {
    quantity = qty ?? 1;
    startDate = DateTime.now();
    this.period = period ?? InvoicePeriod.montly;
    notifyListeners();
  }

  Future<void> pickDate() async {
    var res = await showDatePicker(
      context: navigatorKey.currentContext!,
      initialDate: startDate,
      firstDate: startDate,
      lastDate: startDate.add(365.days),
    );
    startDate = res ?? DateTime.now();
    notifyListeners();
  }

  double priceCalculator(double price) {
    return (price * period.duration) * quantity;
  }

  String convertToMonth(int month) {
    switch (month) {
      case 1:
        return 'Jan';
      case 2:
        return 'Feb';
      case 3:
        return 'Mar';
      case 4:
        return 'Apr';
      case 5:
        return 'May';
      case 6:
        return 'Jun';
      case 7:
        return 'Jul';
      case 8:
        return 'Aug';
      case 9:
        return 'Sep';
      case 10:
        return 'Oct';
      case 11:
        return 'Nov';
      case 12:
        return 'Dec';
      default:
        return ''; // Handle invalid month
    }
  }

  String periodToString(int period) {
    switch (period) {
      case 1:
        return 'Monthly';
      case 3:
        return 'Quarterly';
      case 6:
        return 'Semi Annual';
      case 12:
        return 'Annual';
      default:
        return 'monthly'; // Default value
    }
  }

  InvoicePeriod intToPeriod(int value) {
    switch (value) {
      case 1:
        return InvoicePeriod.montly;
      case 3:
        return InvoicePeriod.quaterly;
      case 6:
        return InvoicePeriod.semi_annual;
      case 12:
        return InvoicePeriod.annual;
      default:
        return InvoicePeriod.montly; // Default value
    }
  }

  void add(ProductModel product) {
    var context = navigatorKey.currentContext!;
    var model = CartModel(
      partner_id: context.read<UserPro>().userId!,
      branch_id: product.company_id,
      unit_id: product.id,
      installment_duration: period.duration,
      sign: "",
    );
    context.read<RentCheckOutPro>().changeRent(model);
    Navigator.pop(context);
    var loc = GoRouter.of(context).location();
    context.go("$loc/signature");
  }
}
