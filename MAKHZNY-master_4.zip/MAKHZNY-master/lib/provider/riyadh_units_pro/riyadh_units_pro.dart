import 'package:client_1/constants/api.dart';
import 'package:client_1/functions/my_dio.dart';
import 'package:client_1/functions/print_c.dart';
import 'package:client_1/model/product_model/product_model.dart';
import 'package:client_1/provider/jeddah_units_pro/jeddah_units_pro.dart';
import 'package:flutter/material.dart';

class RiyadhUnitsPro extends ChangeNotifier {
  final TextEditingController controller = TextEditingController();
  final FocusNode node = FocusNode();

  List<ProductModel> _products = [];

  List<ProductModel> get non_filter_product => _products;

  List<ProductModel> get products {
    var data = _products.toList();
    if (priceRange != null) {
      data = data
          .where(
              (e) => e.price >= priceRange!.start && e.price <= priceRange!.end)
          .toList();
    }
    if (sizeRange != null) {
      data = data
          .where((e) => e.area >= sizeRange!.start && e.area <= sizeRange!.end)
          .toList();
    }
    if (controller.text.isEmpty) return data;
    data = data.where((e) {
      var text = controller.text.toLowerCase();
      var contains = e.title.toLowerCase().contains(text);
      return contains;
    }).toList();
    return data;
  }

  RangeValues? priceRange;

  RangeValues? sizeRange;

  bool get haveFilter => priceRange != null || sizeRange != null;

  void clearRange() {
    priceRange = null;
    sizeRange = null;
    notifyListeners();
  }

  void setPriceRange(RangeValues range) {
    priceRange = range;
    notifyListeners();
  }

  void setSizeeRange(RangeValues range) {
    sizeRange = range;
    notifyListeners();
  }

  void searchUpdate() {
    notifyListeners();
  }

  bool hasError = false;
  bool loading = false;

  ProductModel findById(int unitId) {
    return non_filter_product.where((e) => e.id == unitId).first;
  }

  Future<void> getProduct() async {
    try {
      if (loading) return;
      loading = true;
      hasError = false;
      notifyListeners();

      var dio = MyDio().dio;
      var id = 3;
      var res = await dio.post(API.getProduct, data: {"company_id": id});

      if (res.statusCode != 200) {
        hasError = true;
        loading = false;
        notifyListeners();
        return;
      }

      notifyListeners();

      var data = toMap(res.data["result"]["data"] as List);
      var pro = await toProduct(data, id);

      _products = pro;
      hasError = false;
      loading = false;
      notifyListeners();
    } catch (e) {
      printC(e, from: "P R O D U C T  L O A D", color: PColor.red);
      hasError = true;
      loading = false;
      notifyListeners();
    }
  }

  void remove(int unitId) {
    _products.removeWhere((e) => e.id == unitId);
    notifyListeners();
  }
}
