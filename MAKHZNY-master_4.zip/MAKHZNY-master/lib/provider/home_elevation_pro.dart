import 'package:flutter/material.dart';

class HomeElevationPro extends ChangeNotifier {
  bool show = false;

  void set(bool v) {
    if (show == v) return;
    show = v;
    notifyListeners();
  }
}
