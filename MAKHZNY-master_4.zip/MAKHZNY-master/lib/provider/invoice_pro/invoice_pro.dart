import 'package:client_1/constants/api.dart';
import 'package:client_1/functions/my_dio.dart';
import 'package:client_1/functions/print_c.dart';
import 'package:client_1/main.dart';
import 'package:client_1/model/invoice_model/invoice_model.dart';
import 'package:client_1/provider/user_pro/user_pro.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class InvoicePro extends ChangeNotifier {
  final TextEditingController paidController = TextEditingController();
  final FocusNode paidNode = FocusNode();
  final TextEditingController unpaidController = TextEditingController();
  final FocusNode unpaidNode = FocusNode();
  final TextEditingController rejectedController = TextEditingController();
  final FocusNode rejectedNode = FocusNode();

  int selected = 0;

  bool hasError = false;
  bool loading = false;

  List<InvoiceModel> _paid = [];
  List<InvoiceModel> _unpaid = [];
  List<InvoiceModel> _rejected = [];

  List<InvoiceModel> get non_filter_paid => _paid;
  List<InvoiceModel> get non_filter_unpaid => _unpaid;
  List<InvoiceModel> get non_filter_rejected => _rejected;

  List<InvoiceModel> get paid {
    if (paidController.text.isEmpty) return _paid;
    var list = _paid.where((e) {
      var text = paidController.text.toLowerCase();
      var contains = e.name.toLowerCase().contains(text);
      return contains;
    }).toList();
    return list;
  }

  List<InvoiceModel> get unpaid {
    if (unpaidController.text.isEmpty) return _unpaid;
    var list = _unpaid.where((e) {
      var text = unpaidController.text.toLowerCase();
      var contains = e.name.toLowerCase().contains(text);
      return contains;
    }).toList();
    return list;
  }

  List<InvoiceModel> get rejected {
    if (rejectedController.text.isEmpty) return _rejected;
    var list = _rejected.where((e) {
      var text = rejectedController.text.toLowerCase();
      var contains = e.name.toLowerCase().contains(text);
      return contains;
    }).toList();
    return list;
  }

  void searchUpdate() {
    notifyListeners();
  }

  void changeSelected(int s) {
    if (s == selected) return;
    selected = s;
    notifyListeners();
  }

  Future<void> getInvoices() async {
    try {
      if (loading) return;
      var user = messangerKey.currentContext!.read<UserPro>().userId;
      if (user == null) return;

      loading = true;
      hasError = false;
      notifyListeners();

      var dio = MyDio().dio;

      // dio.options.baseUrl =
      //     "https://perfectech-me-makhzany1-testing-website-12566830.dev.odoo.com/";

      var body = {"partner_id": user};
      var res = await dio.post(API.get_invoices, data: body);

      if (res.statusCode != 200) {
        hasError = true;
        loading = false;
        notifyListeners();
        return;
      }

      var data = Map<String, dynamic>.from(res.data);

      if (!data.containsKey("result")) {
        hasError = true;
        loading = false;
        notifyListeners();
        return;
      }

      var result = Map<String, dynamic>.from(data["result"]);
      List<InvoiceModel> pmodels = [];
      List<InvoiceModel> umodels = [];
      List<InvoiceModel> rmodels = [];

      var pdata = List<Map<String, dynamic>>.from(result["paid"] ?? []);
      var udata = List<Map<String, dynamic>>.from(result["unpaid"] ?? []);
      var rdata = List<Map<String, dynamic>>.from(result["rejected"] ?? []);

      await Future.forEach(pdata, (e) => pmodels.add(InvoiceModel.fromJson(e)));
      await Future.forEach(udata, (e) => umodels.add(InvoiceModel.fromJson(e)));
      await Future.forEach(rdata, (e) => rmodels.add(InvoiceModel.fromJson(e)));

      _paid = pmodels;
      _unpaid = umodels;
      _rejected = rmodels;
      // units = models;
      hasError = false;
      loading = false;
      notifyListeners();
    } catch (e) {
      printC(e, from: "GET INVOICES", color: PColor.red);
      hasError = true;
      loading = false;
      notifyListeners();
    }
  }

  void clear() {
    _paid = [];
    _unpaid = [];
    _rejected = [];
    hasError = false;
    loading = false;
    notifyListeners();
  }

  void add(InvoiceModel invModel) {
    _paid.insert(0, invModel);
    notifyListeners();
  }

  InvoiceModel getByReservation(String? id) {
    var res = _unpaid.where((e) => e.reservation_id.toString() == id);
    return res.first;
  }

  void changeToPaid(int id) {
    var model = _unpaid.where((e) => e.reservation_id == id).first;
    _unpaid.removeWhere((e) => e.reservation_id == id);
    _paid.add(model.copyWith(status: "paid"));
    notifyListeners();
  }
}
