import 'package:client_1/constants/api.dart';
import 'package:client_1/functions/connectivity_check.dart';
import 'package:client_1/functions/my_dio.dart';
import 'package:client_1/functions/print_c.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/main.dart';
import 'package:client_1/model/cart_model/cart_model.dart';
import 'package:client_1/model/invoice_model/invoice_model.dart';
import 'package:client_1/model/product_model/product_model.dart';
import 'package:client_1/provider/add_cart_pro/add_cart_pro.dart';
import 'package:client_1/provider/dammam_units_pro/dammam_units_pro.dart';
import 'package:client_1/provider/invoice_pro/invoice_pro.dart';
import 'package:client_1/provider/jeddah_units_pro/jeddah_units_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/my_units_pro/my_units_pro.dart';
import 'package:client_1/provider/riyadh_units_pro/riyadh_units_pro.dart';
import 'package:client_1/route.dart';
import 'package:client_1/screen/add_cart_dialog/add_cart_dialog.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../functions/show_snakbar.dart';

class RentCheckOutPro extends ChangeNotifier {
  CartModel? cart;

  bool loading = false;
  int? contract_id;

  void changeRent(CartModel model) {
    contract_id = null;
    cart = model;
    notifyListeners();
  }

  Future<bool> checkOut(String sign) async {
    if (cart == null) return false;
    var context = navigatorKey.currentContext;
    final lang = context?.read<LangPro>().lang;
    try {
      var connectCheck = getIt<ConnectivityCheck>();
      var network = await connectCheck.getCurrentState();
      if (!network) return false;

      loading = true;
      notifyListeners();

      var dio = MyDio().dio;
      cart = cart?.copyWith(sign: sign);

      var res = await dio.post(API.rent, data: cart!.toJson());

      loading = false;
      notifyListeners();

      if (res.statusCode != 200) {
        MySnackBar.show(title: lang!.something_went_wrong);
        return false;
      }

      var data = Map.from(res.data);

      if (data.containsKey("error")) {
        MySnackBar.show(title: data["error"]["message"]);
        return false;
      }

      if (data["result"]["data"]["success"] != true) {
        MySnackBar.show(title: lang!.something_went_wrong);
        return false;
      }

      contract_id = data["result"]["data"]["contract_id"];

      return true;
    } catch (e) {
      printC(e, from: "CART CHECKOUT", color: PColor.red);
      MySnackBar.show(title: lang!.something_went_wrong);
      loading = false;
      notifyListeners();
      return false;
    }
  }

  (ProductModel, double) product_details() {
    var context = messangerKey.currentContext!;
    var products = [
      ...context.read<JeddahUnitsPro>().non_filter_product,
      ...context.read<RiyadhUnitsPro>().non_filter_product,
      ...context.read<DammamUnitsPro>().non_filter_product,
    ];

    var product = products.where((e) => e.id == cart?.unit_id).first;

    var vat = (product.price * cart!.installment_duration) * product.vat;
    var total = (product.price * cart!.installment_duration) + vat;
    var dis = context.read<AddCartPro>().period.discount;
    var disMin = total * (dis / 100);
    var price = total - disMin;

    return (product, price.roundToNearestTen().toDouble());
  }

  void successRemove() {
    var context = messangerKey.currentContext!;
    if (cart == null) return;
    var myUnits = context.read<MyUnitsPro>();
    var invoicePro = context.read<InvoicePro>();
    var details = product_details();
    var product = details.$1;
    var price = details.$2;
    myUnits.addToUnits(product);
    var invModel = InvoiceModel(
      name: product.title,
      image: product.image,
      price: price,
      status: "paid",
      date: DateTime.now(),
      reservation_id: contract_id ?? 0,
      contract_id: contract_id ?? 0,
      invoice_url: "",
    );

    invoicePro.add(invModel);

    if (cart!.branch_id == 2) {
      context.read<JeddahUnitsPro>().remove(cart!.unit_id);
    } else if (cart!.branch_id == 3) {
      context.read<RiyadhUnitsPro>().remove(cart!.unit_id);
    } else if (cart!.branch_id == 4) {
      context.read<DammamUnitsPro>().remove(cart!.unit_id);
    }
  }
}
