import 'dart:async';

import 'package:client_1/constants/api.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/functions/connectivity_check.dart';
import 'package:client_1/functions/my_dio.dart';
import 'package:client_1/functions/print_c.dart';
import 'package:client_1/functions/show_dialog.dart';
import 'package:client_1/functions/show_snakbar.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/main.dart';
import 'package:client_1/provider/country_picker_pro/country_picker_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/user_pro/user_pro.dart';
import 'package:client_1/route.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../account_create_pro/account_create_pro.dart';

class LoginPro extends ChangeNotifier {
  final TextEditingController controller = TextEditingController();
  final TextEditingController otpcontroller = TextEditingController();
  int remainingSeconds = 0;
  Timer? _time;
  bool loading = false;
  String? otpID;

  Future<void> login() async {
    try {
      var connectCheck = getIt<ConnectivityCheck>();
      var network = await connectCheck.getCurrentState();
      if (!network) return;
      var context = messangerKey.currentContext;
      var lang = context?.read<LangPro>().lang;
      if (controller.text.isEmpty) {
        MySnackBar.show(title: lang?.enter_your_phone_number ?? "");
        return;
      }

      loading = true;
      notifyListeners();

      ///   FIRST CHECK FOR USER EXIST
      var dio = MyDio().dio;

      var countryCode = context?.read<CountryPickerPro>().loginCountry ?? "";
      var body = {
        "phone": countryCode + controller.text,
        "otp": otpcontroller.text,
      };

      printC("CHECKING USER EXIST");
      printC("HTTP CALL : ${API.baseUrl}${API.cumtomerLogin}");
      printC("BODY : $body");

      var check = await dio.post(API.cumtomerLogin, data: body);

      if (check.statusCode != 200) {
        MySnackBar.show(title: lang!.something_went_wrong);
        loading = false;
        notifyListeners();
        return;
      }

      printC("RESPONSE : ${check.data}");

      var data = Map<String, dynamic>.from(check.data);
      var result = Map<String, dynamic>.from(data["result"]);

      if (result.containsKey("error")) {
        var err = result["error"];
        if (err == "Phone Number Does Not Exist") {
          _noAccountAvilable();
          loading = false;
          notifyListeners();
          return;
        }
        printC(err);
      }

      ///   FIRST CHECK FOR USER EXIST

      var res = await _generateOTP();

      if (res.$1) {
        MySnackBar.show(title: res.$2);
        loading = false;
        notifyListeners();
        return;
      }
      _resendTime();
      loading = false;
      otpID = res.$2;
      notifyListeners();
      var loc = GoRouter.of(navigatorKey.currentContext!).location();
      navigatorKey.currentContext?.go("$loc/otp");
    } on DioException catch (e) {
      MySnackBar.show(title: e.message ?? "Login failed");
      loading = false;
      notifyListeners();
    }
  }

  Future<(bool error, String res)> _generateOTP([String? number]) async {
    var context = messangerKey.currentContext;
    var lang = context?.read<LangPro>().lang;
    try {
      var dio = MyDio().dio;
      var countryCode = context?.read<CountryPickerPro>().loginCountry ?? "";
      var body = {
        "phone_number": number ?? countryCode + controller.text,
      };

      printC("GENRETAE OTP");
      printC("HTTP CALL : ${API.baseUrl}${API.generateOTP}");
      printC("BODY : $body");

      var res = await dio.post(API.generateOTP, data: body);
      var lang = context?.read<LangPro>().lang;

      if (res.statusCode != 200) return (true, lang!.something_went_wrong);

      printC("RESPONSE : ${res.data}");

      var otpID = res.data["result"]["data"]["otp_id"].toString();
      return (false, otpID);
    } catch (e) {
      printC(e, from: "G E N E R A T E  O T P", color: PColor.red);
      return (true, lang!.something_went_wrong);
    }
  }

  Future<void> sendOTP(String number) async {
    var connectCheck = getIt<ConnectivityCheck>();
    var network = await connectCheck.getCurrentState();
    var context = messangerKey.currentContext;
    var lang = context?.read<LangPro>().lang;
    try {
      if (!network) return;
      loading = true;
      notifyListeners();

      var res = await _generateOTP(number);

      if (res.$1) {
        MySnackBar.show(title: res.$2);
        loading = false;
        notifyListeners();
        return;
      }
      MySnackBar.show(title: "${lang?.otp_successfully_send} $number");
      loading = false;
      notifyListeners();
      _resendTime();
    } catch (e) {
      MySnackBar.show(title: "${lang?.otp_failed_send} $number");
      loading = false;
      notifyListeners();
    }
  }

  void _resendTime() {
    remainingSeconds = 60;
    notifyListeners();
    _time = Timer.periodic(1.seconds, (timer) {
      remainingSeconds--;
      notifyListeners();
      if (remainingSeconds <= 0) timer.cancel();
    });
  }

  Future<void> resendOTP() async {
    var connectCheck = getIt<ConnectivityCheck>();
    var network = await connectCheck.getCurrentState();
    if (!network) return;

    loading = true;
    notifyListeners();

    var res = await _generateOTP();

    if (res.$1) {
      MySnackBar.show(title: res.$2);
      loading = false;
      notifyListeners();
      return;
    }

    _resendTime();
    loading = false;
    otpID = res.$2;
    notifyListeners();
  }

  Future<void> confirmOTP() async {
    var connectCheck = getIt<ConnectivityCheck>();
    var network = await connectCheck.getCurrentState();
    if (!network) return;
    var context = navigatorKey.currentContext;
    var lang = context?.read<LangPro>().lang;
    try {
      if (otpcontroller.text.isEmpty) {
        MySnackBar.show(title: lang?.enter_otp_send ?? "");
        return;
      }

      loading = true;
      notifyListeners();

      var dio = MyDio().dio;

      var countryCode = context?.read<CountryPickerPro>().loginCountry ?? "";
      var body = {
        "phone": countryCode + controller.text,
        "otp": otpcontroller.text,
      };

      printC("LOGIN");
      printC("HTTP CALL : ${API.baseUrl}${API.cumtomerLogin}");
      printC("BODY : $body");

      var res = await dio.post(API.cumtomerLogin, data: body);

      if (res.statusCode != 200) {
        MySnackBar.show(title: lang!.something_went_wrong);
        loading = false;
        notifyListeners();
        return;
      }

      printC("RESPONSE : ${res.data}");

      var data = Map<String, dynamic>.from(res.data);
      var result = Map<String, dynamic>.from(data["result"]);

      if (result.containsKey("error")) {
        loading = false;
        notifyListeners();
        var err = result["error"];
        if (err == "Otp Is invalid or expired") {
          MySnackBar.show(title: err);
        } else if (err == "Phone Number Does Not Exist") {
          _noAccountAvilable();
        } else {
          MySnackBar.show(title: err);
        }
        return;
      }

      if (result.containsKey("partner_id")) {
        context?.read<UserPro>().setUser(result["partner_id"]);
      }
      loading = false;
      notifyListeners();
      _time?.cancel();

      context?.read<UserPro>().loginInit();

      context?.pushReplacement("/home");
    } catch (e) {
      printC(e, from: "CONFIRM OTP", color: PColor.red);
      MySnackBar.show(title: lang!.something_went_wrong);
      loading = false;
      notifyListeners();
    }
  }

  void _noAccountAvilable() {
    var context = navigatorKey.currentContext;
    var lang = context?.read<LangPro>().lang;
    showAlertdialogMessage(
      lang?.register,
      lang?.you_do_not_have_ac,
      (_) => [
        TextButton(
          onPressed: () => Navigator.pop(_),
          child: AppText(
            lang!.cancel,
            fontWeight: FontWeight.bold,
            color: Colors.redAccent,
          ),
        ),
        TextButton(
          onPressed: () {
            stopTimer();
            var loc = GoRouter.of(context).location();
            loc = loc.replaceAll("/otp", "");
            context.read<AccountCreatePro>().setNumber();
            context.go("$loc/account");
          },
          child: AppText(
            lang.create,
            fontWeight: FontWeight.bold,
            color: Theme.of(context!).primaryColor,
          ),
        ),
        sizedBoxW10,
      ],
    );
  }

  void stopTimer() {
    _time?.cancel();
    remainingSeconds = 0;
    notifyListeners();
  }
}
