import 'package:client_1/constants/colors.dart';
import 'package:client_1/functions/preference.dart';
import 'package:client_1/functions/print_c.dart';
import 'package:client_1/main.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

enum ThemeType { light, dark, auto }

class ThemePro extends ChangeNotifier {
  ThemeType type = ThemeType.light;

  static final String? _font = GoogleFonts.poppins().fontFamily;

  ThemeMode get model {
    switch (type) {
      case ThemeType.light:
        return ThemeMode.light;
      case ThemeType.dark:
        return ThemeMode.dark;
      case ThemeType.auto:
        return ThemeMode.system;
      default:
        return ThemeMode.light;
    }
  }

  Color get grey {
    if (theme.brightness == Brightness.dark) {
      return Colors.grey.shade600;
    } else {
      return MyColor.grey;
    }
  }

  Color get cardColor {
    if (theme.brightness == Brightness.dark) {
      return const Color.fromARGB(255, 20, 19, 19);
    } else {
      return Colors.white;
    }
  }

  String? get font => _font;

  ThemeData get theme {
    switch (type) {
      case ThemeType.light:
        return light;
      case ThemeType.dark:
        return dark;
      case ThemeType.auto:
        var brightness =
            WidgetsBinding.instance.platformDispatcher.platformBrightness;
        bool isDarkMode = brightness == Brightness.dark;
        return isDarkMode ? dark : light;
      default:
        return light;
    }
  }

  ThemeData light = ThemeData(
    primaryColor: MyColor.btnColor,
    colorScheme: ColorScheme.fromSeed(
      seedColor: MyColor.btnColor,
      brightness: Brightness.light,
    ),
    fontFamily: _font,
    brightness: Brightness.light,
    scaffoldBackgroundColor: MyColor.scaffoldBG,
    textTheme: Typography.blackCupertino,
    useMaterial3: true,
  );

  ThemeData dark = ThemeData(
    primaryColor: const Color.fromARGB(255, 115, 50, 150),
    colorScheme: ColorScheme.fromSeed(
      seedColor: const Color.fromARGB(255, 115, 50, 150),
      brightness: Brightness.dark,
    ),
    fontFamily: _font,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: const Color(0xff0C0C0C),
    textTheme: Typography.whiteCupertino,
    useMaterial3: true,
  );

  void change(ThemeType type) {
    if (this.type == type) return;
    this.type = type;
    Preference.setTheme(type);
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        systemNavigationBarColor: theme.scaffoldBackgroundColor,
        statusBarIconBrightness: theme.brightness == Brightness.dark
            ? Brightness.light
            : Brightness.dark,
      ),
    );
    notifyListeners();
  }

  Future<void> init() async {
    var res = await Preference.getTheme();
    change(res);
  }

  void platformChange() {
    if (type != ThemeType.auto) return;
    printC("T H E M E  P L A T F O R M  C H A N G E D");
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        systemNavigationBarColor: theme.scaffoldBackgroundColor,
        statusBarIconBrightness: theme.brightness == Brightness.dark
            ? Brightness.light
            : Brightness.dark,
      ),
    );
    notifyListeners();
  }
}

class ThemeObserver extends WidgetsBindingObserver {
  ThemeObserver() {
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangePlatformBrightness() {
    messangerKey.currentContext?.read<ThemePro>().platformChange();
    super.didChangePlatformBrightness();
  }
}
