// ignore_for_file: use_build_context_synchronously

import 'dart:async';
import 'dart:convert';

import 'package:client_1/functions/connectivity_check.dart';
import 'package:client_1/functions/show_snakbar.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/provider/checkout_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/provider/rent_checkout_pro/rent_checkout_pro.dart';
import 'package:client_1/route.dart';
import 'package:client_1/screen/payment_proccess_screen/payment_proccess_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:signature/signature.dart';
import 'package:image/image.dart' as image;
import 'package:universal_platform/universal_platform.dart';

enum PenStock {
  small,
  medium,
  large,
}

class SignaturePro extends ChangeNotifier {
  PenStock stock = PenStock.medium;
  bool checkBox = false;
  bool loading = false;

  final ScrollController scrollController = ScrollController();

  var controller = SignatureController(
    penStrokeWidth: 6.5,
    strokeJoin: StrokeJoin.round,
    strokeCap: StrokeCap.round,
    exportBackgroundColor: Colors.transparent,
  );

  void changeCheckBox(bool v) {
    if (v == checkBox) return;
    checkBox = v;
    notifyListeners();
  }

  void changeStock(PenStock s) {
    if (s == stock) return;
    stock = s;
    var points = controller.points;
    controller = SignatureController(
      penStrokeWidth: _penStock(),
      strokeJoin: StrokeJoin.round,
      strokeCap: StrokeCap.round,
      exportBackgroundColor: Colors.grey.shade300,
      points: points,
    );
    notifyListeners();
  }

  Future<void> next() async {
    var connectCheck = getIt<ConnectivityCheck>();
    var network = await connectCheck.getCurrentState();
    if (!network) return;
    var context = navigatorKey.currentContext!;
    var lang = context.read<LangPro>().lang;
    if (checkBox == false) {
      MySnackBar.show(title: lang.to_continue_accept_terms_condintion);
      return;
    }
    if (controller.isEmpty) {
      MySnackBar.show(title: lang.to_continue_give_your_signature);
      return;
    }
    var rentPro = context.read<RentCheckOutPro>();
    if (rentPro.cart == null) {
      MySnackBar.show(title: "Cart is empty");
      context.pop();
    }
    try {
      loading = true;
      notifyListeners();
      var pngBytes = await controller.toPngBytes();
      if (pngBytes == null) {
        MySnackBar.show(title: lang.something_went_wrong);
        loading = false;
        notifyListeners();
        return;
      }
      pngBytes = resizeImage(pngBytes, 500, 500);
      var base64Img = base64Encode(pngBytes);
      var image = "data:image/png;base64,$base64Img";

      var checkout = await rentPro.checkOut(image);

      if (!checkout) {
        loading = false;
        notifyListeners();
        return;
      }

      // code for signature upload //
      loading = false;
      notifyListeners();
      if (UniversalPlatform.isIOS || UniversalPlatform.isAndroid) {
        // var uri = Uri.parse("${API.baseUrl}mobile/cart/${rentPro.contract_id}");
        var id = rentPro.contract_id?.toString();
        if (id != null) context.read<CheckoutPro>().init(reservation_id: id);
      } else {
        // var id = rentPro.contract_id?.toString();
        // if (id != null) context.read<CheckoutPro>().init(reservation_id: id);
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => PaymentProcessScreen(id: rentPro.contract_id!),
          ),
        );
      }
    } catch (e) {
      MySnackBar.show(title: lang.something_went_wrong);
      loading = false;
      notifyListeners();
    }
  }

  double _penStock() {
    switch (stock) {
      case PenStock.small:
        return 3.0;
      case PenStock.medium:
        return 6.5;
      case PenStock.large:
        return 10.5;
      default:
        return 3.0;
    }
  }

  Future<void> clearSign() async {
    controller.clear();
  }

  Uint8List resizeImage(
    Uint8List imageData,
    int newWidth,
    int newHeight,
  ) {
    // Decode the image data
    image.Image? originalImage = image.decodeImage(imageData);
    if (originalImage == null) return Uint8List.fromList([]);
    // Ensure new dimensions are not smaller than original dimensions
    // int width = newWidth > originalImage.width ? newWidth : originalImage.width;
    // int height =
    //     newHeight > originalImage.height ? newHeight : originalImage.height;

    // Resize the image without shrinking
    image.Image resizedImage =
        image.copyResize(originalImage, width: newWidth, height: newHeight);

    // Encode the resized image back to Uint8List
    Uint8List resizedImageData =
        Uint8List.fromList(image.encodePng(resizedImage));

    return resizedImageData;
  }

  void reset() {
    clearSign();
    checkBox = false;
    stock = PenStock.medium;
    notifyListeners();
  }
}
