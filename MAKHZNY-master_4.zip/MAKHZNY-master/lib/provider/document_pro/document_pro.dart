// ignore_for_file: use_build_context_synchronously

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:client_1/constants/api.dart';
import 'package:client_1/functions/my_dio.dart';
import 'package:client_1/main.dart';
import 'package:client_1/model/document_model/document_model.dart';
import 'package:client_1/model/download_model/download_model.dart';
import 'package:client_1/provider/download_pro.dart';
import 'package:client_1/provider/user_pro/user_pro.dart';
import 'package:mime/mime.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/functions/connectivity_check.dart';
import 'package:client_1/functions/print_c.dart';
import 'package:client_1/functions/show_snakbar.dart';
import 'package:client_1/get_it.dart';
import 'package:client_1/provider/current_route_pro/current_route_pro.dart';
import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:client_1/route.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/text_field.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:flutter_doc_scanner/flutter_doc_scanner.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:universal_platform/universal_platform.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;

class DocumentPro extends ChangeNotifier {
  bool loading = false;
  bool hasError = false;

  final TextEditingController controller = TextEditingController();
  final FocusNode node = FocusNode();

  List<PickedFile> pickedFiles = [];
  List<PickedFile> selectedFiles = [];

  List<DocumentModel> _uploaded = [];

  List<DocumentModel> get non_filter_uploaded => _uploaded;

  List<DocumentModel> get uploaded {
    if (controller.text.isEmpty) return _uploaded;
    var list = _uploaded.where((e) {
      var text = controller.text.toLowerCase();
      var contains = e.name.toLowerCase().contains(text);
      return contains;
    }).toList();
    return list;
  }

  void searchUpdate() {
    notifyListeners();
  }

  Future<void> getUploaded() async {
    try {
      if (loading) return;
      var user = messangerKey.currentContext!.read<UserPro>().userId;
      if (user == null) return;

      loading = true;
      hasError = false;
      notifyListeners();

      var dio = MyDio().dio;

      // dio.options.baseUrl =
      //     "https://perfectech-me-makhzany1-testing-website-12566830.dev.odoo.com/";

      var body = {"partner_id": user};
      var res = await dio.post(API.get_docs, data: body);

      if (res.statusCode != 200) {
        hasError = true;
        loading = false;
        notifyListeners();
        return;
      }

      var data = Map<String, dynamic>.from(res.data);

      if (!data.containsKey("result")) {
        hasError = true;
        loading = false;
        notifyListeners();
        return;
      }

      List<DocumentModel> models = [];
      var data2 = List<Map<String, dynamic>>.from(data["result"]);
      await Future.forEach(data2, (e) {
        models.add(DocumentModel.fromJson(e));
      });

      _uploaded = models;
      hasError = false;
      loading = false;
      notifyListeners();
    } catch (e) {
      printC(e, from: "GET DOCUMENTS", color: PColor.red);
      hasError = true;
      loading = false;
      notifyListeners();
    }
  }

  Future<void> pickDocs([bool clear = false]) async {
    try {
      if (clear) {
        pickedFiles.clear();
        selectedFiles.clear();
        notifyListeners();
      }
      var res = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        type: FileType.custom,
        allowedExtensions: ["pdf", "png", "jpg", "doc", "docx"],
      );

      if (res == null) return;
      for (var file in res.files) {
        var path = UniversalPlatform.isWeb ? file.xFile.path : file.path;
        if (path == null) continue;
        var name = UniversalPlatform.isWeb ? file.xFile.name : file.name;
        var contain =
            pickedFiles.where((e) => "${e.name}.${e.ext}" == name).toList();
        if (contain.isNotEmpty) return;
        if (!UniversalPlatform.isWeb) {
          var split = name.split(".");
          split.removeLast();
          name = split.join();
        }
        pickedFiles.insert(
          0,
          PickedFile(
            name: name,
            path: path,
            ext: file.extension!,
          ),
        );
      }
      notifyListeners();
      var context = navigatorKey.currentContext!;
      var loc = context.read<CurrentRoutePro>().loc;
      if (loc == "/settings/documents") {
        context.push("$loc/selected");
      }
    } catch (e) {
      printC(e);
      MySnackBar.show(title: "Failed to open");
    }
  }

  Future<void> pickDocScanner([bool clear = false]) async {
    try {
      if (clear) {
        pickedFiles.clear();
        selectedFiles.clear();
        notifyListeners();
      }
      var fileName = await _scanDocName();
      if (fileName == null) return;
      var res = await FlutterDocScanner().getScanDocuments();
      var path = res["pdfUri"].toString().replaceAll("file:///", "/");

      pickedFiles.insert(0, PickedFile(name: fileName, path: path, ext: "pdf"));
      notifyListeners();

      var context = navigatorKey.currentContext!;
      var loc = context.read<CurrentRoutePro>().loc;
      if (loc == "/settings/documents") {
        context.push("$loc/selected");
      }
    } on PlatformException catch (e) {
      if (e.code != "SCAN_FAILED") MySnackBar.show(title: "Failed to open");
      printC(e);
    }
  }

  Future<String?> _scanDocName() async {
    var context = navigatorKey.currentContext!;
    var controller = TextEditingController();
    var res = await showDialog<String>(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(6),
        ),
        child: _Dialog(controller: controller),
      ),
    );
    if (res == "done" && controller.text.isNotEmpty) return controller.text;
    return null;
  }

  void toggleSelect(PickedFile se) {
    var contain = selectedFiles.where((e) => e.path == se.path);
    if (contain.isEmpty) {
      selectedFiles.add(se);
    } else {
      selectedFiles.removeWhere((e) => e.path == se.path);
    }
    notifyListeners();
  }

  bool isSelected(PickedFile se) {
    var contain = selectedFiles.where((e) => e.path == se.path);
    return contain.isNotEmpty;
  }

  Future<bool> upload() async {
    try {
      var connectCheck = getIt<ConnectivityCheck>();
      var network = await connectCheck.getCurrentState();
      var user = messangerKey.currentContext!.read<UserPro>().userId;
      if (user == null) return false;
      if (!network) return false;
      var context = navigatorKey.currentContext!;
      var lang = context.read<LangPro>().lang;
      if (selectedFiles.isEmpty) {
        MySnackBar.show(title: lang.select_doc_you_want);
        return false;
      }

      loading = true;
      notifyListeners();

      List<({String name, String base, String path})> files = [];

      await Future.forEach(selectedFiles, (e) async {
        Uint8List readAsByte;
        String? mime;
        if (UniversalPlatform.isWeb) {
          var res = await http.get(Uri.parse(e.path));
          readAsByte = res.bodyBytes;
          printC(res.headers);
          var imgext = ["png", "jpg"];
          printC("mime is ${res.headers['Content-Type']}");
          mime = imgext.contains(e.ext)
              ? "image/${e.ext}"
              : "application/${e.ext}";
        } else {
          var filePath = File(e.path);
          readAsByte = await filePath.readAsBytes();
          mime = lookupMimeType(e.path);
        }
        var encoded = base64.encode(readAsByte);
        if (mime == null) return;
        var fullBase = 'data:$mime;base64,$encoded';
        files.add((name: e.name, base: fullBase, path: e.path));
      });
      // loading = false;
      // notifyListeners();
      // return false;

      var dio = MyDio().dio;

      // dio.options.baseUrl =
      //     "https://perfectech-me-makhzany1-testing-website-12566830.dev.odoo.com/";

      List<DownloadModel> dm = [];

      await Future.forEach(files, (e) async {
        var body = {
          "partner_id": user,
          "attachment_name": e.name,
          "attach_data": e.base,
        };

        var res = await dio.post(API.upload_doc, data: body);

        if (res.statusCode != 200) return;
        var data = Map.from(res.data);
        printC(res.data, color: PColor.white);
        if (!data.containsKey("result")) return;
        if (!UniversalPlatform.isWeb) {
          var d = await _addToDownload(data["result"], e);
          dm.add(d);
        }
      });
      printC("reached");
      if (!UniversalPlatform.isWeb) await context.read<DownloadPro>().add(dm);

      loading = false;
      notifyListeners();
      MySnackBar.show(title: "Document uploaded success");
      return true;
    } catch (e) {
      printC(e, color: PColor.red, from: "DOCUMENT UPLOAD");
      MySnackBar.show(title: "Failed to upload documents");
      loading = false;
      notifyListeners();
      return false;
    }
  }

  Future<DownloadModel> _addToDownload(
    Map data,
    ({String name, String base, String path}) e,
  ) async {
    var size = await _fileSize(e.path);

    Map<String, dynamic> data2 = data["data"]["attach_data"];
    data2.addAll({"delete_url": "/my/documents/delete/${data2["id"]}"});
    var documentModel = DocumentModel.fromJson(data2);

    var model = DownloadModel(
      id: documentModel.id.toString(),
      url: documentModel.urlWithBase,
      path: e.path,
      size: size,
      progress: ValueNotifier(100),
      downloaded_size: ValueNotifier(size),
      meta: {},
      status: ValueNotifier(DownloadStatus.completed),
    );
    _uploaded.insert(0, documentModel);
    return model;
  }

  Future<int> _fileSize(String path) async {
    var file = File(path);
    return await file.length();
  }

  void clear() {
    loading = false;
    hasError = false;
    pickedFiles = [];
    selectedFiles = [];
    _uploaded = [];
    notifyListeners();
  }

  void removePickedFile(PickedFile file) {
    pickedFiles.removeWhere((e) => e.path == file.path);
    notifyListeners();
  }

  void convertAllToSelected() {
    selectedFiles = pickedFiles.toList();
    pickedFiles = [];
    notifyListeners();
  }

  void remove(DocumentModel doc) {
    uploaded.removeWhere((e) => e.id == doc.id);
    notifyListeners();
  }
}

class _Dialog extends StatelessWidget {
  const _Dialog({required this.controller});

  final TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    GlobalKey<FormState> form = GlobalKey<FormState>();
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Form(
            key: form,
            child: CusTextField(
              validator: (_) {
                if (_ == null) return "";
                if (_.isEmpty) return "Fill this for continue";
              },
              control: controller,
              hintText: "Enter document name",
            ),
          ),
          sizedBoxH30,
          Row(
            children: [
              const Spacer(),
              AppButton(
                height: 35,
                width: 100,
                borderRadius: BorderRadius.circular(6),
                text: lang.cancel,
                fontWeight: FontWeight.w600,
                fontSize: 14.spMin,
                onPressed: () => Navigator.pop(context),
              ),
              sizedBoxW20,
              AppButton(
                height: 35,
                width: 100,
                borderRadius: BorderRadius.circular(6),
                text: lang.continue_text,
                fontWeight: FontWeight.w600,
                fontSize: 14.spMin,
                onPressed: () async {
                  var res = form.currentState?.validate();
                  if (res != true) return;
                  Navigator.pop(context, "done");
                },
              ),
            ],
          )
        ],
      ),
    );
  }
}

class PickedFile {
  final String name;
  final String path;
  final String ext;

  PickedFile({required this.name, required this.path, required this.ext});
}
