// ignore_for_file: use_build_context_synchronously

import 'dart:developer';

import 'package:client_1/constants/api.dart';
import 'package:client_1/functions/print_c.dart';
import 'package:client_1/functions/show_snakbar.dart';
import 'package:client_1/provider/invoice_pro/invoice_pro.dart';
import 'package:client_1/provider/rent_checkout_pro/rent_checkout_pro.dart';
import 'package:client_1/provider/user_pro/user_pro.dart';
import 'package:client_1/route.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:geideapay/api/response/order_api_response.dart';
import 'package:geideapay/common/geidea.dart';
import 'package:geideapay/common/server_environments.dart';
import 'package:geideapay/widgets/checkout/checkout_options.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

class CheckoutPro extends ChangeNotifier {
  final _plugin = GeideapayPlugin();
  String? _contract_id;
  String? _reservation_id;
  double price = 0;
  bool loading = false;
  Future<void> init({
    required String reservation_id,
    String contract_id = "",
    double? price,
  }) async {
    _reservation_id = reservation_id;
    _contract_id = contract_id;
    loading = true;
    var context = navigatorKey.currentContext!;
    var read = context.read<RentCheckOutPro>();
    this.price = price ?? read.product_details().$2;
    notifyListeners();
    _plugin.initialize(
      //TEST
      // publicKey: "023b2e0a-d1cf-4bdd-bef6-5a5609f67cd7",
      // apiPassword: "6ae043b8-aef2-4fcc-b386-952ccb085827",

      //REAL
      publicKey: "73fe7e42-a52d-48b7-bf43-996b0bfb898c",
      apiPassword: "58cd1bed-310a-42d4-b2a1-a133d023aec3",
      serverEnvironment: ServerEnvironmentModel.KSA_PROD(),
    );
    await _checkoutFunction();
  }

  Future<void> _checkoutFunction() async {
    var context = navigatorKey.currentContext!;
    try {
      var user = context.read<UserPro>();
      var read = context.read<RentCheckOutPro>();
      if (user.userId == null) {
        loading = false;
        notifyListeners();
        return;
      }

      var option = CheckoutOptions(
        price,
        "SAR",
        merchantReferenceID: user.userId.toString(),
        customerEmail: user.userShow?.email,
        paymentOperation: "Pay",
        callbackUrl: _callback_url(),
        returnUrl: "https://www.makhzny.com/contactus-thank-you",
      );

      OrderApiResponse response = await _plugin.checkout(
        context: context,
        checkoutOptions: option,
      );

      loading = false;
      notifyListeners();
      if (response.responseCode == "-1") {
        MySnackBar.show(
          title: response.detailedResponseCode ?? "",
          duration: 4.seconds,
        );
        Navigator.pop(context);
        return;
      }

      if (response.responseCode == "000") {
        var loc = GoRouter.of(context).location();
        if (loc.contains("/signature")) {
          log("SIGNATURE");
          read.successRemove();
        } else {
          var inv = context.read<InvoicePro>();
          inv.changeToPaid(int.tryParse(_reservation_id!) ?? 0);
        }
      }

      MySnackBar.show(
        title: response.detailedResponseMessage ?? "",
        duration: 4.seconds,
      );
    } catch (e) {
      Navigator.of(context).pop();
      MySnackBar.show(title: e.toString().trim(), duration: 4.seconds);
      printC(e, color: PColor.cyan);
      loading = false;
      notifyListeners();
    }
  }

  String _callback_url() {
    var context = navigatorKey.currentContext!;
    var loc = GoRouter.of(context).location();
    String url = "";
    if (loc.contains("/signature")) {
      url = "${API.baseUrl}${API.callback}/$_reservation_id";
    } else {
      url = "${API.baseUrl}${API.callback}/$_reservation_id/$_contract_id";
    }
    return url;
  }
}
