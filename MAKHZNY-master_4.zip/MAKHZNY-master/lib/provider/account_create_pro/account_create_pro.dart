// ignore_for_file: non_constant_identifier_names

import 'package:client_1/provider/login_pro/login_pro.dart';
import 'package:client_1/route.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AccountCreatePro extends ChangeNotifier {
  // P E R S O N A L
  final TextEditingController full_name = TextEditingController();
  final TextEditingController id_number = TextEditingController();
  final TextEditingController dob = TextEditingController();
  final TextEditingController address = TextEditingController();
  final TextEditingController mobile_number = TextEditingController();
  final TextEditingController email = TextEditingController();
  final TextEditingController otp_number = TextEditingController();
  final TextEditingController nature_of_goods = TextEditingController();

  final FocusNode full_nameF = FocusNode();
  final FocusNode id_numberF = FocusNode();
  final FocusNode dobF = FocusNode();
  final FocusNode addressF = FocusNode();
  final FocusNode mobile_numberF = FocusNode();
  final FocusNode emailF = FocusNode();
  final FocusNode otp_numberF = FocusNode();
  final FocusNode nature_of_goodsF = FocusNode();

  // B U S I N E S S
  final TextEditingController company_name = TextEditingController();
  final TextEditingController cr_number = TextEditingController();
  final TextEditingController vat_reg = TextEditingController();
  final TextEditingController company_phone = TextEditingController();
  final TextEditingController company_email = TextEditingController();
  final TextEditingController auth_person_name = TextEditingController();
  final TextEditingController company_id_number = TextEditingController();
  final TextEditingController auth_person_number = TextEditingController();
  final TextEditingController business_otp_number = TextEditingController();

  final FocusNode company_nameF = FocusNode();
  final FocusNode cr_numberF = FocusNode();
  final FocusNode vat_regF = FocusNode();
  final FocusNode company_phoneF = FocusNode();
  final FocusNode company_emailF = FocusNode();
  final FocusNode auth_person_nameF = FocusNode();
  final FocusNode company_id_numberF = FocusNode();
  final FocusNode auth_person_numberF = FocusNode();
  final FocusNode business_otp_numberF = FocusNode();

  void personalClear() {
    full_name.clear();
    id_number.clear();
    dob.clear();
    address.clear();
    mobile_number.clear();
    email.clear();
    nature_of_goods.clear();
  }

  void businessClear() {
    company_name.clear();
    cr_number.clear();
    vat_reg.clear();
    company_phone.clear();
    company_email.clear();
    auth_person_name.clear();
    company_id_number.clear();
    auth_person_number.clear();
    nature_of_goods.clear();
  }

  int selected = 0;

  void changeSelected(int s) {
    if (s == selected) return;
    selected = s;
    notifyListeners();
  }

  void setOTPnumber(String s) {
    otp_number.text = s;
    business_otp_number.text = s;
  }

  void setNumber() {
    var context = navigatorKey.currentContext!;
    var number = context.read<LoginPro>().controller.text;
    company_phone.text = number;
    auth_person_number.text = number;
    mobile_number.text = number;
  }
}
