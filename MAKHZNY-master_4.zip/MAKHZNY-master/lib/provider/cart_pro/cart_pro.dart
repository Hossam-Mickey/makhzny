// import 'package:client_1/constants/api.dart';
// import 'package:client_1/functions/connectivity_check.dart';
// import 'package:client_1/functions/my_dio.dart';
// import 'package:client_1/functions/print_c.dart';
// import 'package:client_1/functions/show_snakbar.dart';
// import 'package:client_1/get_it.dart';
// import 'package:client_1/hive/functions/cart_fucntion.dart';
// import 'package:client_1/main.dart';
// import 'package:client_1/model/product_model/product_model.dart';
// import 'package:client_1/provider/add_cart_pro/add_cart_pro.dart';
// import 'package:client_1/provider/lang_pro/lang_pro.dart';
// import 'package:client_1/route.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';

// import '../../model/cart_model/cart_model.dart';

// class CartPro extends ChangeNotifier {
//   List<CartModel> cart = [];
//   bool loading = false;

//   void addToCart(CartModel model) {
//     cart.removeWhere((e) => e.unit_id == model.unit_id);
//     cart.add(model);
//     getIt<CartHive>().addData([model]);
//     notifyListeners();
//   }

//   Future<void> loadFromLocal() async {
//     cart = await getIt<CartHive>().getdata();
//     notifyListeners();
//   }

//   void remove(CartModel model) {
//     cart.removeWhere((e) => e.unit_id == model.unit_id);
//     getIt<CartHive>().delete(model);
//     notifyListeners();
//   }

//   void clearAll() {
//     if (cart.isEmpty) return;
//     cart = [];
//     getIt<CartHive>().deleteAll();
//     notifyListeners();
//   }

//   Future<void> checkOut() async {
//     if (cart.isEmpty) return;
//     var context = navigatorKey.currentContext;
//     var lang = context?.read<LangPro>().lang;
//     try {
//       var connectCheck = getIt<ConnectivityCheck>();
//       var network = await connectCheck.getCurrentState();
//       if (!network) return;

//       loading = true;
//       notifyListeners();

//       var dio = MyDio().dio;
//       var ids = <int>[];

//       await Future.forEach(cart, (e) async {
//         var res = await dio.post(API.rent, data: e.toJson());
//         if (res.statusCode == 200 &&
//             res.data["result"]["data"]["success"] == true) {
//           ids.add(e.unit_id);
//         }
//       });

//       await Future.forEach(ids, (e) {
//         cart.removeWhere((ee) => ee.unit_id == e);
//       });

//       MySnackBar.show(title: "Checkout success");
//       loading = false;
//       notifyListeners();
//     } catch (e) {
//       printC(e, from: "CART CHECKOUT", color: PColor.red);
//       MySnackBar.show(title: lang!.something_went_wrong);
//       loading = false;
//       notifyListeners();
//     }
//   }

//   ({double total, double vat}) total(List<ProductModel> product) {
//     var sortProduct = <ProductModel>[];
//     var context = messangerKey.currentContext!;
//     double total = 0;
//     double vat = 0;
//     for (var c in cart) {
//       var res = product.where((e) => e.id == c.unit_id);
//       if (res.isNotEmpty) {
//         sortProduct.add(res.first);
//         var read = context.read<AddCartPro>();
//         var intToPeriod = read.intToPeriod(c.installment_duration);
//         var periodCalc = read.periodCalc(intToPeriod);
//         total += res.first.price * periodCalc;
//         vat += res.first.vat;
//       }
//     }
//     return (total: total, vat: vat);
//   }
// }
