import 'package:client_1/constants/api.dart';
import 'package:client_1/functions/print_c.dart';
import 'package:client_1/provider/invoice_pro/invoice_pro.dart';
import 'package:client_1/provider/quote_pro.dart';
import 'package:client_1/provider/splash_init_pro.dart';
import 'package:client_1/screen/account_create_screen/account_create_screen.dart';
import 'package:client_1/screen/add_card_screen/add_card_screen.dart';
import 'package:client_1/screen/appearance_screen/appearance_screen.dart';
import 'package:client_1/screen/document_screen/document_screen.dart';
import 'package:client_1/screen/document_select_screen/document_select_screen.dart';
import 'package:client_1/screen/home_screen/home_screen.dart';
import 'package:client_1/screen/home_screen/widgets/home_ad_dialog.dart';
import 'package:client_1/screen/invoice_screen/invoice_screen.dart';
import 'package:client_1/screen/language_screen/language_screen.dart';
import 'package:client_1/screen/login_screen/login_screen.dart';
import 'package:client_1/screen/message_screen/message_screen.dart';
import 'package:client_1/screen/my_storage_screen/my_storage_screen.dart';
import 'package:client_1/screen/otp_screen/otp_screen.dart';
import 'package:client_1/screen/payment_proccess_screen/payment_proccess_screen.dart';
import 'package:client_1/screen/quote_screen/quote_screen.dart';
import 'package:client_1/screen/saved_payment_screen/saved_payment_screen.dart';
import 'package:client_1/screen/signature_screen/signature_screen.dart';
import 'package:client_1/screen/terms_condition_screen/terms_condition_screen.dart';
import 'package:client_1/screen/user_info_screen/user_info_screen.dart';
import 'package:client_1/widgets/rtl_layout.dart';
import 'package:flutter/widgets.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import 'screen/gate_access_screen/gate_access_screen.dart';
import 'screen/settings_screen/settings_screen.dart';
import 'screen/splash_screen/splash_screen.dart';
import 'screen/store_screen/store_screen.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

class MyRouter {
  static String login() => "/login";
  static String splash() => "/splash";
  static String otp() => "${login()}/otp";
  static String home() => "/home";

  static GoRouter router = GoRouter(
    debugLogDiagnostics: true,
    initialLocation: "/splash",
    navigatorKey: navigatorKey,
    redirect: (context, state) {
      printC(state.uri);
      var splashInit = context.read<SplashInitPro>();
      if (!splashInit.initialized && state.uri.path != "/splash") {
        printC("NOT INITILIZED", color: PColor.red);
        printC(state.uri.path, color: PColor.red);
        return "/splash?path=${state.uri.path}";
      }
      if (state.uri.path == "/home") showCarouselAd();
      return null;
    },
    routes: [
      GoRoute(
        path: "/splash",
        builder: (context, state) {
          var path = state.uri.queryParameters["path"];
          return RTLLayout(child: SplashScreen(path: path));
        },
      ),
      GoRoute(
        path: "/home",
        pageBuilder: (_, s) => const NoTransitionPage(child: HomeScreen(null)),
        routes: [
          cart(),
          loginScreen(),
          message(),
        ],
      ),
      GoRoute(
        path: "/store",
        pageBuilder: (_, s) => const NoTransitionPage(
          child: HomeScreen(StoreScreen()),
        ),
        routes: [
          loginScreen(),
          cart(),
          message(),
        ],
      ),
      GoRoute(
        path: "/quote",
        redirect: (_, s) {
          _.read<QuotePro>().clear();
          return null;
        },
        routes: [
          message(),
        ],
        pageBuilder: (_, s) => const NoTransitionPage(
          child: HomeScreen(QuoteScreen()),
        ),
      ),
      GoRoute(
        path: "/storage",
        pageBuilder: (_, s) => const NoTransitionPage(
          child: HomeScreen(MyStorageScreen()),
        ),
        routes: [
          loginScreen(),
          cart(),
          message(),
        ],
      ),
      GoRoute(
        path: "/gate_access",
        pageBuilder: (_, s) => const NoTransitionPage(
          child: HomeScreen(GateAccessScreen()),
        ),
        routes: [
          loginScreen(),
          cart(),
          message(),
        ],
      ),
      GoRoute(
        path: "/settings",
        pageBuilder: (_, s) => const NoTransitionPage(
          child: HomeScreen(SettingsScreen()),
        ),
        routes: [
          loginScreen(),
          cart(),
          message(),
          accountCreate(),
          GoRoute(
            path: "user_info",
            builder: (context, state) =>
                const RTLLayout(child: UserInfoScreen()),
          ),
          GoRoute(
              path: "invoice",
              builder: (context, state) =>
                  const RTLLayout(child: InvoiceScreen()),
              routes: [
                GoRoute(
                  path: "pay/:reservation_id",
                  builder: (context, state) {
                    var id = state.pathParameters["reservation_id"];
                    var invoice =
                        context.read<InvoicePro>().getByReservation(id);
                    var link =
                        '${API.baseUrl}mobile/cart/${invoice.reservation_id}/${invoice.contract_id}';
                    return PaymentProcessScreen(id: int.parse(id!), link: link);
                  },
                ),
              ]),
          GoRoute(
            path: "documents",
            builder: (context, state) =>
                const RTLLayout(child: DocumentScreen()),
            routes: [
              GoRoute(
                path: "selected",
                builder: (context, state) => const RTLLayout(
                  child: DocumentSelectScreen(),
                ),
              )
            ],
          ),
          GoRoute(
            path: "saved_payment",
            builder: (context, state) =>
                const RTLLayout(child: SavedPaymentScreen()),
            routes: [
              GoRoute(
                path: "add",
                builder: (context, state) => const AddCardScreen(),
              ),
            ],
          ),
          GoRoute(
            path: "appearance",
            builder: (context, state) =>
                const RTLLayout(child: AppearanceScreen()),
          ),
          GoRoute(
            path: "language",
            builder: (context, state) =>
                const RTLLayout(child: LanguageScreen()),
          ),
        ],
      ),
      loginScreen(true),
      accountCreate(true),
    ],
  );

  static GoRoute loginScreen([bool slash = false]) => GoRoute(
        path: slash ? "/login" : "login",
        builder: (context, state) => const RTLLayout(child: LoginScreen()),
        routes: [
          GoRoute(
            path: "otp",
            builder: (context, state) => const RTLLayout(child: OTPScreen()),
          ),
          accountCreate(),
        ],
      );
  static GoRoute message([bool slash = false]) => GoRoute(
        path: slash ? "/message" : "message",
        builder: (context, state) => const RTLLayout(child: MessageScreen()),
        // routes: [],
      );

  static GoRoute cart([bool slash = false]) {
    return GoRoute(
      path: "signature",
      builder: (context, state) {
        return const RTLLayout(child: SignatureScreen());
      },
      routes: [
        GoRoute(
          path: "terms_conditions",
          builder: (context, state) {
            return const TermsConditionScreen();
          },
        ),
      ],
    );
    // return GoRoute(
    //     path: slash ? "/cart" : "cart",
    //     builder: (context, state) => const RTLLayout(child: CartScreen()),
    //     routes: [
    //       GoRoute(
    //         path: "payment_method",
    //         builder: (context, state) {
    //           return const RTLLayout(child: PaymentMethodScreen());
    //         },
    //       ),
    //       GoRoute(
    //         path: "signature",
    //         builder: (context, state) {
    //           return const RTLLayout(child: SignatureScreen());
    //         },
    //       ),
    //     ],
    //   );
  }

  static GoRoute accountCreate([bool slash = false]) => GoRoute(
        path: slash ? "/account" : "account",
        builder: (context, state) =>
            const RTLLayout(child: AccountCreateScreen()),
        routes: [
          GoRoute(
            path: "document",
            builder: (context, state) => const RTLLayout(
              child: DocumentSelectScreen(),
            ),
          )
        ],
      );
}

extension GoRouterExtension on GoRouter {
  String location() {
    final RouteMatch lastMatch = routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : routerDelegate.currentConfiguration;
    final String location = matchList.uri.toString();
    return location;
  }
}
