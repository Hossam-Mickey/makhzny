// ignore_for_file: non_constant_identifier_names

class MyString {
  static String appTitle = "MAKHZNY";
  static int imageSize = 1000000;

  static String version = "1.3.1";
  static double webWidth = 700;
  static String terms =
      "https://makhzny.odoo.com/makhzany_website_pages/static/terms.pdf";
  static double rangeWidth = 830;
}
