// ignore_for_file: non_constant_identifier_names

class MyImage {
  // Image folder path
  static String imagePath = 'assets/image';

  static String logo = '$imagePath/logo.svg';
  static String logo_vert = '$imagePath/logo_vert.png';

  static String send_plane = '$imagePath/send_plane.svg';
  static String image_circle = '$imagePath/image_circle.svg';

  static String keypad_back = '$imagePath/keypad_back.svg';

  static String gate_access = '$imagePath/gate_access.svg';
  static String home = '$imagePath/home.svg';
  static String my_storage = '$imagePath/my_storage.svg';
  static String settings = '$imagePath/settings.svg';
  static String store = '$imagePath/store.svg';

  static String welcome_frnd = '$imagePath/welcome_frnd.svg';
  static String welcome_frnd_bg = '$imagePath/welcome_frnd_bg.svg';

  static String cart = '$imagePath/cart.svg';

  static String rent_now = '$imagePath/rent_now.svg';
  static String download_icon = '$imagePath/download_icon.svg';
  static String no_login = '$imagePath/no_login.svg';
  static String location = '$imagePath/location.svg';
  static String auto_renew = '$imagePath/auto_renew.svg';
  static String auto_renew_off = '$imagePath/auto_renew_off.svg';
  static String no_storage_data = '$imagePath/no_storage_data.svg';
  static String add = '$imagePath/add.svg';
  static String minuse = '$imagePath/minuse.svg';
  static String gate_close = '$imagePath/gate_close.svg';
  static String eye = '$imagePath/eye.svg';
  static String delete = '$imagePath/delete.svg';
  static String light_mode = '$imagePath/light_mode.svg';
  static String dark_mode = '$imagePath/dark_mode.svg';
  static String auto_mode = '$imagePath/auto_mode.svg';
  static String visa = '$imagePath/visa.svg';
  static String document = '$imagePath/document.svg';
  static String cart_empty = '$imagePath/cart_empty.svg';
  static String sadad = '$imagePath/sadad.svg';
  static String bank_transfer = '$imagePath/bank_transfer.svg';
  static String error = '$imagePath/error.svg';
  static String maintainance = '$imagePath/maintainance.png';
  static String take_tour = '$imagePath/take_tour.jpg';

  // static String imgLock = '$imagePath/img_lock.png';

  // // chats Five images
  // static String imgCheckmark = '$imagePath/img_checkmark.png';

  // // Common images
  // static String imgGroup = '$imagePath/img_group.svg';

  // static String search = '$imagePath/search.png';

  // static String google = '$imagePath/google.png';

  // static String attach = '$imagePath/img_attach.png';

  // static String send = '$imagePath/img_group_23.png';
}
