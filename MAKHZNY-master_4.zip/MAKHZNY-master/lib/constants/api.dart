class API {
  // static String baseUrl =
  //     "https://makhzny-testing-website-14853522.dev.odoo.com/";
  static String baseUrl = "https://makhzny.odoo.com/";

  // static String baseDocUrl = "https://makhzny-testing-website-14853522.dev.odoo.com/";
  static String baseDocUrl = "https://makhzny.odoo.com/";
  static String callback = "payment_callback";


  static String getProduct = "get_products";
  static String generateOTP = "generate_otp";
  static String cumtomerLogin = "web/customer_login_api";
  static String register = "web/register_new_customer_api";
  static String rent = "rent_api";
  static String get_units = "get_units";
  static String get_invoices = "get_invoices";
  static String upload_doc = "upload_document";

  static String get_docs = "get_docs";

  static String partner_info = "get_partner_data";

  static String get_offers = "get_offers";
  static String delete_account = "delete_account";
}
