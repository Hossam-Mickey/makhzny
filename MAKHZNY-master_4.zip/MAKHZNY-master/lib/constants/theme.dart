// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';

// import 'color.dart';

import 'package:flutter/material.dart';

import 'colors.dart';

class AppTheme {
  static String? defaultFont = "Maven Pro";

  // static InputDecorationTheme inputdecoration() {
  //   const Color blue = Color(0xff014FB4);

  //   var border = OutlineInputBorder(
  //     borderRadius: BorderRadius.circular(6),
  //     borderSide: const BorderSide(
  //       color: blue,
  //       width: 1,
  //     ),
  //   );

  //   return InputDecorationTheme(
  //     fillColor: const Color(0xff071526),
  //     filled: true,
  //     hintStyle: TextStyle(
  //       fontFamily: AppTheme.defaultFont,
  //       fontWeight: FontWeight.bold,
  //       fontSize: 16,
  //       color: const Color(0xff0B3D7A),
  //     ),
  //     enabledBorder: border,
  //     focusedBorder: border,
  //   );
  // }

  static ThemeData themeData = ThemeData(
      fontFamily: defaultFont,
      useMaterial3: true,
      primaryColor: MyColor.primary,
      colorScheme: ColorScheme.fromSeed(seedColor: MyColor.primary)
      // inputDecorationTheme: inputdecoration(),
      );

  static ({Color light, Color dark}) scheme(
      {double lightFact = 0.1, double darkFact = 0.1}) {
    return (
      light: lightenColor(MyColor.primary, lightFact),
      dark: darkenColor(MyColor.primary, darkFact),
    );
  }

  static Color darkenColor(Color color, double factor) {
    assert(
      factor >= 0.0 && factor <= 1.0,
      'Factor should be between 0.0 and 1.0',
    );
    final int red = (color.red * (1 - factor)).round();
    final int green = (color.green * (1 - factor)).round();
    final int blue = (color.blue * (1 - factor)).round();
    return Color.fromRGBO(red, green, blue, 1.0);
  }

  static Color lightenColor(Color color, double factor) {
    assert(
        factor >= 0.0 && factor <= 1.0, 'Factor should be between 0.0 and 1.0');
    int red = (color.red + ((255 - color.red) * factor)).round();
    int green = (color.green + ((255 - color.green) * factor)).round();
    int blue = (color.blue + ((255 - color.blue) * factor)).round();
    red = red.clamp(0, 255);
    green = green.clamp(0, 255);
    blue = blue.clamp(0, 255);
    return Color.fromRGBO(red, green, blue, 1.0);
  }
}
