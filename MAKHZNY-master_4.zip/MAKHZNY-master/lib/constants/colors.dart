// ignore_for_file: constant_identifier_names

import 'package:client_1/route.dart';
import 'package:flutter/material.dart';

class MyColor {
  static const Color primary = Color(0xffD16800);

  static const Color grey = Color(0xffA3A4A8);
  static const Color blue = Color(0xff7F7CFF);
  static const Color green = Color(0xff00FF19);

  static const Color scaffoldBG = Colors.white;

  static const Color btnColor = Color(0xff410B5F);

  static const Color lightGrey = Color(0xffF0F0F0);

  static Color? get refreshColor {
    var context = navigatorKey.currentContext!;
    return Theme.of(context).brightness == Brightness.dark
        ? Colors.grey.shade800
        : null;
  }
}
