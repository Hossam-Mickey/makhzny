import 'package:flutter/material.dart';

const extent = SliverGridDelegateWithMaxCrossAxisExtent(
  crossAxisSpacing: 10.0,
  mainAxisSpacing: 10.0,
  mainAxisExtent: 260,
  maxCrossAxisExtent: 260,
);
