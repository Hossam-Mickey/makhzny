import 'package:freezed_annotation/freezed_annotation.dart';
part 'invoice_model.freezed.dart';
part 'invoice_model.g.dart';

@freezed
class InvoiceModel with _$InvoiceModel {
  const factory InvoiceModel({
    required String name,
    required String image,
    required double price,
    required String status,
    required int reservation_id,
    required int contract_id,
    required String invoice_url,
    @InvoiceDateConvertor() required DateTime date,
  }) = _InvoiceModel;

  factory InvoiceModel.fromJson(Map<String, dynamic> json) =>
      _$InvoiceModelFromJson(json);
}

class InvoiceDateConvertor implements JsonConverter<DateTime, String> {
  const InvoiceDateConvertor();

  @override
  DateTime fromJson(String json) => DateTime.parse(json);

  @override
  String toJson(DateTime obj) {
    var year = obj.year;
    var day = obj.day.toString().padLeft(2, "0");
    var month = obj.month.toString().padLeft(2, "0");
    return "$year-$month-$day";
  }
}
