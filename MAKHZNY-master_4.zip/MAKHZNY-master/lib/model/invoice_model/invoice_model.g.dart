// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'invoice_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$InvoiceModelImpl _$$InvoiceModelImplFromJson(Map<String, dynamic> json) =>
    _$InvoiceModelImpl(
      name: json['name'] as String,
      image: json['image'] as String,
      price: (json['price'] as num).toDouble(),
      status: json['status'] as String,
      reservation_id: (json['reservation_id'] as num).toInt(),
      contract_id: (json['contract_id'] as num).toInt(),
      invoice_url: json['invoice_url'] as String,
      date: const InvoiceDateConvertor().fromJson(json['date'] as String),
    );

Map<String, dynamic> _$$InvoiceModelImplToJson(_$InvoiceModelImpl instance) =>
    <String, dynamic>{
      'name': instance.name,
      'image': instance.image,
      'price': instance.price,
      'status': instance.status,
      'reservation_id': instance.reservation_id,
      'contract_id': instance.contract_id,
      'invoice_url': instance.invoice_url,
      'date': const InvoiceDateConvertor().toJson(instance.date),
    };
