import 'package:client_1/constants/api.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
part 'document_model.freezed.dart';
part 'document_model.g.dart';

@freezed
class DocumentModel with _$DocumentModel {
  const DocumentModel._();
  const factory DocumentModel({
    required String name,
    required int id,
    required String download_url,
    required bool can_delete,
    required String delete_url,
  }) = _DocumentModel;

  factory DocumentModel.fromJson(Map<String, dynamic> json) =>
      _$DocumentModelFromJson(json);

  String get urlWithBase {
    var url = download_url.replaceRange(0, 1, "");
    return API.baseDocUrl + url;
  }

  String get deleteurlWithBase {
    var url = delete_url.replaceRange(0, 1, "");
    return API.baseDocUrl + url;
  }
}
