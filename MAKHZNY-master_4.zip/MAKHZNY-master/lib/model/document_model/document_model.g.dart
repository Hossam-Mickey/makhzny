// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'document_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$DocumentModelImpl _$$DocumentModelImplFromJson(Map<String, dynamic> json) =>
    _$DocumentModelImpl(
      name: json['name'] as String,
      id: (json['id'] as num).toInt(),
      download_url: json['download_url'] as String,
      can_delete: json['can_delete'] as bool,
      delete_url: json['delete_url'] as String,
    );

Map<String, dynamic> _$$DocumentModelImplToJson(_$DocumentModelImpl instance) =>
    <String, dynamic>{
      'name': instance.name,
      'id': instance.id,
      'download_url': instance.download_url,
      'can_delete': instance.can_delete,
      'delete_url': instance.delete_url,
    };
