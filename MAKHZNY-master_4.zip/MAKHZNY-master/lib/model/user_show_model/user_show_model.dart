// ignore_for_file: invalid_annotation_target

import 'package:freezed_annotation/freezed_annotation.dart';
part 'user_show_model.freezed.dart';
part 'user_show_model.g.dart';

@freezed
class UserShowModel with _$UserShowModel {
  const factory UserShowModel({
    @JsonKey(fromJson: _boolToString, includeFromJson: true)
    required String name,
    @JsonKey(fromJson: _boolToString, includeFromJson: true)
    required String email,
    @JsonKey(fromJson: _boolToString, includeFromJson: true)
    required String phone,
  }) = _UserShowModel;

  factory UserShowModel.fromJson(Map<String, dynamic> json) =>
      _$UserShowModelFromJson(json);
}

String _boolToString(dynamic value) {
  // if (value is bool) {
  //   return (value).toString();
  // }
  return value.toString();
}
