// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user_show_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

UserShowModel _$UserShowModelFromJson(Map<String, dynamic> json) {
  return _UserShowModel.fromJson(json);
}

/// @nodoc
mixin _$UserShowModel {
  @JsonKey(fromJson: _boolToString, includeFromJson: true)
  String get name => throw _privateConstructorUsedError;
  @JsonKey(fromJson: _boolToString, includeFromJson: true)
  String get email => throw _privateConstructorUsedError;
  @JsonKey(fromJson: _boolToString, includeFromJson: true)
  String get phone => throw _privateConstructorUsedError;

  /// Serializes this UserShowModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of UserShowModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $UserShowModelCopyWith<UserShowModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserShowModelCopyWith<$Res> {
  factory $UserShowModelCopyWith(
          UserShowModel value, $Res Function(UserShowModel) then) =
      _$UserShowModelCopyWithImpl<$Res, UserShowModel>;
  @useResult
  $Res call(
      {@JsonKey(fromJson: _boolToString, includeFromJson: true) String name,
      @JsonKey(fromJson: _boolToString, includeFromJson: true) String email,
      @JsonKey(fromJson: _boolToString, includeFromJson: true) String phone});
}

/// @nodoc
class _$UserShowModelCopyWithImpl<$Res, $Val extends UserShowModel>
    implements $UserShowModelCopyWith<$Res> {
  _$UserShowModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of UserShowModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? email = null,
    Object? phone = null,
  }) {
    return _then(_value.copyWith(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$UserShowModelImplCopyWith<$Res>
    implements $UserShowModelCopyWith<$Res> {
  factory _$$UserShowModelImplCopyWith(
          _$UserShowModelImpl value, $Res Function(_$UserShowModelImpl) then) =
      __$$UserShowModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(fromJson: _boolToString, includeFromJson: true) String name,
      @JsonKey(fromJson: _boolToString, includeFromJson: true) String email,
      @JsonKey(fromJson: _boolToString, includeFromJson: true) String phone});
}

/// @nodoc
class __$$UserShowModelImplCopyWithImpl<$Res>
    extends _$UserShowModelCopyWithImpl<$Res, _$UserShowModelImpl>
    implements _$$UserShowModelImplCopyWith<$Res> {
  __$$UserShowModelImplCopyWithImpl(
      _$UserShowModelImpl _value, $Res Function(_$UserShowModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of UserShowModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? email = null,
    Object? phone = null,
  }) {
    return _then(_$UserShowModelImpl(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$UserShowModelImpl implements _UserShowModel {
  const _$UserShowModelImpl(
      {@JsonKey(fromJson: _boolToString, includeFromJson: true)
      required this.name,
      @JsonKey(fromJson: _boolToString, includeFromJson: true)
      required this.email,
      @JsonKey(fromJson: _boolToString, includeFromJson: true)
      required this.phone});

  factory _$UserShowModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$UserShowModelImplFromJson(json);

  @override
  @JsonKey(fromJson: _boolToString, includeFromJson: true)
  final String name;
  @override
  @JsonKey(fromJson: _boolToString, includeFromJson: true)
  final String email;
  @override
  @JsonKey(fromJson: _boolToString, includeFromJson: true)
  final String phone;

  @override
  String toString() {
    return 'UserShowModel(name: $name, email: $email, phone: $phone)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UserShowModelImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.phone, phone) || other.phone == phone));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, name, email, phone);

  /// Create a copy of UserShowModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$UserShowModelImplCopyWith<_$UserShowModelImpl> get copyWith =>
      __$$UserShowModelImplCopyWithImpl<_$UserShowModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$UserShowModelImplToJson(
      this,
    );
  }
}

abstract class _UserShowModel implements UserShowModel {
  const factory _UserShowModel(
      {@JsonKey(fromJson: _boolToString, includeFromJson: true)
      required final String name,
      @JsonKey(fromJson: _boolToString, includeFromJson: true)
      required final String email,
      @JsonKey(fromJson: _boolToString, includeFromJson: true)
      required final String phone}) = _$UserShowModelImpl;

  factory _UserShowModel.fromJson(Map<String, dynamic> json) =
      _$UserShowModelImpl.fromJson;

  @override
  @JsonKey(fromJson: _boolToString, includeFromJson: true)
  String get name;
  @override
  @JsonKey(fromJson: _boolToString, includeFromJson: true)
  String get email;
  @override
  @JsonKey(fromJson: _boolToString, includeFromJson: true)
  String get phone;

  /// Create a copy of UserShowModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$UserShowModelImplCopyWith<_$UserShowModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
