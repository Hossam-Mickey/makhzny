// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_show_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$UserShowModelImpl _$$UserShowModelImplFromJson(Map<String, dynamic> json) =>
    _$UserShowModelImpl(
      name: _boolToString(json['name']),
      email: _boolToString(json['email']),
      phone: _boolToString(json['phone']),
    );

Map<String, dynamic> _$$UserShowModelImplToJson(_$UserShowModelImpl instance) =>
    <String, dynamic>{
      'name': instance.name,
      'email': instance.email,
      'phone': instance.phone,
    };
