// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'lang_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

LangModel _$LangModelFromJson(Map<String, dynamic> json) {
  return _LangModel.fromJson(json);
}

/// @nodoc
mixin _$LangModel {
  String get app_name => throw _privateConstructorUsedError;
  String get search => throw _privateConstructorUsedError;
  String get next => throw _privateConstructorUsedError;
  String get login => throw _privateConstructorUsedError;
  String get resend => throw _privateConstructorUsedError;
  String get resend_in => throw _privateConstructorUsedError;
  String get enter_your_phone_number => throw _privateConstructorUsedError;
  String get enter_number => throw _privateConstructorUsedError;
  String get welcome_to => throw _privateConstructorUsedError;
  String get dont_miss_the_opportunity => throw _privateConstructorUsedError;
  String get enter_otp_send => throw _privateConstructorUsedError;
  String get otp => throw _privateConstructorUsedError;
  String get my_storage => throw _privateConstructorUsedError;
  String get store => throw _privateConstructorUsedError;
  String get home => throw _privateConstructorUsedError;
  String get gate_access => throw _privateConstructorUsedError;
  String get settings => throw _privateConstructorUsedError;
  String get welcome_frnd => throw _privateConstructorUsedError;
  String get it_is_time_to_get_origanized => throw _privateConstructorUsedError;
  String get we_have_place => throw _privateConstructorUsedError;
  String get first_since => throw _privateConstructorUsedError;
  String get rent_now => throw _privateConstructorUsedError;
  String get trending_now => throw _privateConstructorUsedError;
  String get last_booked => throw _privateConstructorUsedError;
  String get add_to_cart => throw _privateConstructorUsedError;
  String get to_able_to_view => throw _privateConstructorUsedError;
  String get sign_in => throw _privateConstructorUsedError;
  String get all => throw _privateConstructorUsedError;
  String get self_storage => throw _privateConstructorUsedError;
  String get others => throw _privateConstructorUsedError;
  String get auto_renew => throw _privateConstructorUsedError;
  String get total_number => throw _privateConstructorUsedError;
  String get rented_items => throw _privateConstructorUsedError;
  String get no_results_found => throw _privateConstructorUsedError;
  String get try_to_use_other_filter => throw _privateConstructorUsedError;
  String get continue_text => throw _privateConstructorUsedError;
  String get cancel => throw _privateConstructorUsedError;
  String get are_you_sure_renewal => throw _privateConstructorUsedError;
  String get yes => throw _privateConstructorUsedError;
  String get rental_option => throw _privateConstructorUsedError;
  String get invoice_period => throw _privateConstructorUsedError;
  String get invoice_period_sub => throw _privateConstructorUsedError;
  String get quantity => throw _privateConstructorUsedError;
  String get quantity_sub => throw _privateConstructorUsedError;
  String get montly => throw _privateConstructorUsedError;
  String get semi_annual => throw _privateConstructorUsedError;
  String get annual => throw _privateConstructorUsedError;
  String get quarterly => throw _privateConstructorUsedError;
  String get add => throw _privateConstructorUsedError;
  String get total => throw _privateConstructorUsedError;
  String get storage_units => throw _privateConstructorUsedError;
  String get general_items => throw _privateConstructorUsedError;
  String get your_cart_is_empty => throw _privateConstructorUsedError;
  String get lets_add_something => throw _privateConstructorUsedError;
  String get my_cart => throw _privateConstructorUsedError;
  String get clear_all_items => throw _privateConstructorUsedError;
  String get add_ons => throw _privateConstructorUsedError;
  String get total_amount => throw _privateConstructorUsedError;
  String get vat => throw _privateConstructorUsedError;
  String get payable_amount => throw _privateConstructorUsedError;
  String get checkout => throw _privateConstructorUsedError;
  String get are_you_sure_cart => throw _privateConstructorUsedError;
  String get personal => throw _privateConstructorUsedError;
  String get business => throw _privateConstructorUsedError;
  String get open => throw _privateConstructorUsedError;
  String get close => throw _privateConstructorUsedError;
  String get access_code => throw _privateConstructorUsedError;
  String get pls_enter_code => throw _privateConstructorUsedError;
  String get profile => throw _privateConstructorUsedError;
  String get languages => throw _privateConstructorUsedError;
  String get appearance => throw _privateConstructorUsedError;
  String get saved_payment_methods => throw _privateConstructorUsedError;
  String get documents => throw _privateConstructorUsedError;
  String get invoices => throw _privateConstructorUsedError;
  String get paid => throw _privateConstructorUsedError;
  String get unpaid => throw _privateConstructorUsedError;
  String get rejected => throw _privateConstructorUsedError;
  String get are_you_sure_delete_doc => throw _privateConstructorUsedError;
  String get add_document => throw _privateConstructorUsedError;
  String get upload_from_phone => throw _privateConstructorUsedError;
  String get open_pdf_scanner => throw _privateConstructorUsedError;
  String get light_mode => throw _privateConstructorUsedError;
  String get light_mode_sub => throw _privateConstructorUsedError;
  String get dark_mode => throw _privateConstructorUsedError;
  String get dark_mode_sub => throw _privateConstructorUsedError;
  String get auto_mode => throw _privateConstructorUsedError;
  String get auto_mode_sub => throw _privateConstructorUsedError;
  String get are_you_sure_card => throw _privateConstructorUsedError;
  String get add_card => throw _privateConstructorUsedError;
  String get card_nickname => throw _privateConstructorUsedError;
  String get card_holder_name => throw _privateConstructorUsedError;
  String get card_number => throw _privateConstructorUsedError;
  String get cvv => throw _privateConstructorUsedError;
  String get expiry_date => throw _privateConstructorUsedError;
  String get invalid => throw _privateConstructorUsedError;
  String get full_name => throw _privateConstructorUsedError;
  String get id_number => throw _privateConstructorUsedError;
  String get date_of_birth => throw _privateConstructorUsedError;
  String get address => throw _privateConstructorUsedError;
  String get mobile_number => throw _privateConstructorUsedError;
  String get email => throw _privateConstructorUsedError;
  String get please_ensure_info => throw _privateConstructorUsedError;
  String get company_name => throw _privateConstructorUsedError;
  String get cr_number => throw _privateConstructorUsedError;
  String get vat_registration => throw _privateConstructorUsedError;
  String get company_phone => throw _privateConstructorUsedError;
  String get company_email => throw _privateConstructorUsedError;
  String get auth_person_name => throw _privateConstructorUsedError;
  String get auth_person_number => throw _privateConstructorUsedError;
  String get attached_documents => throw _privateConstructorUsedError;
  String get please_attach_required => throw _privateConstructorUsedError;
  String get lets_add => throw _privateConstructorUsedError;
  String get new_text => throw _privateConstructorUsedError;
  String get select_doc_you_want => throw _privateConstructorUsedError;
  String get done => throw _privateConstructorUsedError;
  String get view_document => throw _privateConstructorUsedError;
  String get version => throw _privateConstructorUsedError;
  String get retry => throw _privateConstructorUsedError;
  String get something_went_wrong => throw _privateConstructorUsedError;
  String get jeddah => throw _privateConstructorUsedError;
  String get dammam => throw _privateConstructorUsedError;
  String get riyadh => throw _privateConstructorUsedError;
  String get enter_full_name => throw _privateConstructorUsedError;
  String get enter_id_number => throw _privateConstructorUsedError;
  String get enter_dob => throw _privateConstructorUsedError;
  String get enter_email => throw _privateConstructorUsedError;
  String get enter_auth_name => throw _privateConstructorUsedError;
  String get enter_auth_number => throw _privateConstructorUsedError;
  String get enter_phone_number => throw _privateConstructorUsedError;
  String get enter_vat_register => throw _privateConstructorUsedError;
  String get enter_cr_number => throw _privateConstructorUsedError;
  String get enter_address => throw _privateConstructorUsedError;
  String get enter_otp_number => throw _privateConstructorUsedError;
  String get otp_number => throw _privateConstructorUsedError;
  String get invalid_email => throw _privateConstructorUsedError;
  String get invalid_dob => throw _privateConstructorUsedError;
  String get enter_company_name => throw _privateConstructorUsedError;
  String get enter_company_phone => throw _privateConstructorUsedError;
  String get enter_company_email => throw _privateConstructorUsedError;
  String get rental_date => throw _privateConstructorUsedError;
  String get rental_date_sub => throw _privateConstructorUsedError;
  String get logout => throw _privateConstructorUsedError;
  String get payment_method => throw _privateConstructorUsedError;
  String get sadad_payment => throw _privateConstructorUsedError;
  String get bank_tansfer => throw _privateConstructorUsedError;
  String get card_payment => throw _privateConstructorUsedError;
  String get select_payment_method => throw _privateConstructorUsedError;
  String get upload => throw _privateConstructorUsedError;
  String get termsOfServiceTitle => throw _privateConstructorUsedError;
  String get termsOfServiceDescription => throw _privateConstructorUsedError;
  String get agreeToTerms => throw _privateConstructorUsedError;
  String get termsAndConditionsSub => throw _privateConstructorUsedError;
  String get continue_checkbox => throw _privateConstructorUsedError;
  String get yourSignature => throw _privateConstructorUsedError;
  String get pleaseSignAbove => throw _privateConstructorUsedError;
  String get clear => throw _privateConstructorUsedError;
  String get to_continue_accept_terms_condintion =>
      throw _privateConstructorUsedError;
  String get to_continue_give_your_signature =>
      throw _privateConstructorUsedError;
  String get register => throw _privateConstructorUsedError;
  String get you_do_not_have_ac => throw _privateConstructorUsedError;
  String get create => throw _privateConstructorUsedError;
  String get otp_successfully_send => throw _privateConstructorUsedError;
  String get otp_failed_send => throw _privateConstructorUsedError;
  String get send_otp => throw _privateConstructorUsedError;
  String get do_not_have_ac => throw _privateConstructorUsedError;
  String get discount => throw _privateConstructorUsedError;
  String get your_info => throw _privateConstructorUsedError;
  String get new_units => throw _privateConstructorUsedError;
  String get booked => throw _privateConstructorUsedError;
  String get booked_sub => throw _privateConstructorUsedError;
  String get delete_ac => throw _privateConstructorUsedError;
  String get delete_ac_sub => throw _privateConstructorUsedError;
  String get optional => throw _privateConstructorUsedError;
  String get quote => throw _privateConstructorUsedError;
  String get request_quote => throw _privateConstructorUsedError;
  String get request_quote_sub => throw _privateConstructorUsedError;
  String get choose_branch => throw _privateConstructorUsedError;
  String get choose_area => throw _privateConstructorUsedError;
  String get receiving_method => throw _privateConstructorUsedError;
  String get via_email => throw _privateConstructorUsedError;
  String get download_pdf => throw _privateConstructorUsedError;
  String get send_via_email => throw _privateConstructorUsedError;
  String get message => throw _privateConstructorUsedError;
  String get your_personal_info => throw _privateConstructorUsedError;
  String get nature_of_goods_stored => throw _privateConstructorUsedError;
  String get take_a_tour_with_makhzny => throw _privateConstructorUsedError;

  /// Serializes this LangModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of LangModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $LangModelCopyWith<LangModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $LangModelCopyWith<$Res> {
  factory $LangModelCopyWith(LangModel value, $Res Function(LangModel) then) =
      _$LangModelCopyWithImpl<$Res, LangModel>;
  @useResult
  $Res call(
      {String app_name,
      String search,
      String next,
      String login,
      String resend,
      String resend_in,
      String enter_your_phone_number,
      String enter_number,
      String welcome_to,
      String dont_miss_the_opportunity,
      String enter_otp_send,
      String otp,
      String my_storage,
      String store,
      String home,
      String gate_access,
      String settings,
      String welcome_frnd,
      String it_is_time_to_get_origanized,
      String we_have_place,
      String first_since,
      String rent_now,
      String trending_now,
      String last_booked,
      String add_to_cart,
      String to_able_to_view,
      String sign_in,
      String all,
      String self_storage,
      String others,
      String auto_renew,
      String total_number,
      String rented_items,
      String no_results_found,
      String try_to_use_other_filter,
      String continue_text,
      String cancel,
      String are_you_sure_renewal,
      String yes,
      String rental_option,
      String invoice_period,
      String invoice_period_sub,
      String quantity,
      String quantity_sub,
      String montly,
      String semi_annual,
      String annual,
      String quarterly,
      String add,
      String total,
      String storage_units,
      String general_items,
      String your_cart_is_empty,
      String lets_add_something,
      String my_cart,
      String clear_all_items,
      String add_ons,
      String total_amount,
      String vat,
      String payable_amount,
      String checkout,
      String are_you_sure_cart,
      String personal,
      String business,
      String open,
      String close,
      String access_code,
      String pls_enter_code,
      String profile,
      String languages,
      String appearance,
      String saved_payment_methods,
      String documents,
      String invoices,
      String paid,
      String unpaid,
      String rejected,
      String are_you_sure_delete_doc,
      String add_document,
      String upload_from_phone,
      String open_pdf_scanner,
      String light_mode,
      String light_mode_sub,
      String dark_mode,
      String dark_mode_sub,
      String auto_mode,
      String auto_mode_sub,
      String are_you_sure_card,
      String add_card,
      String card_nickname,
      String card_holder_name,
      String card_number,
      String cvv,
      String expiry_date,
      String invalid,
      String full_name,
      String id_number,
      String date_of_birth,
      String address,
      String mobile_number,
      String email,
      String please_ensure_info,
      String company_name,
      String cr_number,
      String vat_registration,
      String company_phone,
      String company_email,
      String auth_person_name,
      String auth_person_number,
      String attached_documents,
      String please_attach_required,
      String lets_add,
      String new_text,
      String select_doc_you_want,
      String done,
      String view_document,
      String version,
      String retry,
      String something_went_wrong,
      String jeddah,
      String dammam,
      String riyadh,
      String enter_full_name,
      String enter_id_number,
      String enter_dob,
      String enter_email,
      String enter_auth_name,
      String enter_auth_number,
      String enter_phone_number,
      String enter_vat_register,
      String enter_cr_number,
      String enter_address,
      String enter_otp_number,
      String otp_number,
      String invalid_email,
      String invalid_dob,
      String enter_company_name,
      String enter_company_phone,
      String enter_company_email,
      String rental_date,
      String rental_date_sub,
      String logout,
      String payment_method,
      String sadad_payment,
      String bank_tansfer,
      String card_payment,
      String select_payment_method,
      String upload,
      String termsOfServiceTitle,
      String termsOfServiceDescription,
      String agreeToTerms,
      String termsAndConditionsSub,
      String continue_checkbox,
      String yourSignature,
      String pleaseSignAbove,
      String clear,
      String to_continue_accept_terms_condintion,
      String to_continue_give_your_signature,
      String register,
      String you_do_not_have_ac,
      String create,
      String otp_successfully_send,
      String otp_failed_send,
      String send_otp,
      String do_not_have_ac,
      String discount,
      String your_info,
      String new_units,
      String booked,
      String booked_sub,
      String delete_ac,
      String delete_ac_sub,
      String optional,
      String quote,
      String request_quote,
      String request_quote_sub,
      String choose_branch,
      String choose_area,
      String receiving_method,
      String via_email,
      String download_pdf,
      String send_via_email,
      String message,
      String your_personal_info,
      String nature_of_goods_stored,
      String take_a_tour_with_makhzny});
}

/// @nodoc
class _$LangModelCopyWithImpl<$Res, $Val extends LangModel>
    implements $LangModelCopyWith<$Res> {
  _$LangModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of LangModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? app_name = null,
    Object? search = null,
    Object? next = null,
    Object? login = null,
    Object? resend = null,
    Object? resend_in = null,
    Object? enter_your_phone_number = null,
    Object? enter_number = null,
    Object? welcome_to = null,
    Object? dont_miss_the_opportunity = null,
    Object? enter_otp_send = null,
    Object? otp = null,
    Object? my_storage = null,
    Object? store = null,
    Object? home = null,
    Object? gate_access = null,
    Object? settings = null,
    Object? welcome_frnd = null,
    Object? it_is_time_to_get_origanized = null,
    Object? we_have_place = null,
    Object? first_since = null,
    Object? rent_now = null,
    Object? trending_now = null,
    Object? last_booked = null,
    Object? add_to_cart = null,
    Object? to_able_to_view = null,
    Object? sign_in = null,
    Object? all = null,
    Object? self_storage = null,
    Object? others = null,
    Object? auto_renew = null,
    Object? total_number = null,
    Object? rented_items = null,
    Object? no_results_found = null,
    Object? try_to_use_other_filter = null,
    Object? continue_text = null,
    Object? cancel = null,
    Object? are_you_sure_renewal = null,
    Object? yes = null,
    Object? rental_option = null,
    Object? invoice_period = null,
    Object? invoice_period_sub = null,
    Object? quantity = null,
    Object? quantity_sub = null,
    Object? montly = null,
    Object? semi_annual = null,
    Object? annual = null,
    Object? quarterly = null,
    Object? add = null,
    Object? total = null,
    Object? storage_units = null,
    Object? general_items = null,
    Object? your_cart_is_empty = null,
    Object? lets_add_something = null,
    Object? my_cart = null,
    Object? clear_all_items = null,
    Object? add_ons = null,
    Object? total_amount = null,
    Object? vat = null,
    Object? payable_amount = null,
    Object? checkout = null,
    Object? are_you_sure_cart = null,
    Object? personal = null,
    Object? business = null,
    Object? open = null,
    Object? close = null,
    Object? access_code = null,
    Object? pls_enter_code = null,
    Object? profile = null,
    Object? languages = null,
    Object? appearance = null,
    Object? saved_payment_methods = null,
    Object? documents = null,
    Object? invoices = null,
    Object? paid = null,
    Object? unpaid = null,
    Object? rejected = null,
    Object? are_you_sure_delete_doc = null,
    Object? add_document = null,
    Object? upload_from_phone = null,
    Object? open_pdf_scanner = null,
    Object? light_mode = null,
    Object? light_mode_sub = null,
    Object? dark_mode = null,
    Object? dark_mode_sub = null,
    Object? auto_mode = null,
    Object? auto_mode_sub = null,
    Object? are_you_sure_card = null,
    Object? add_card = null,
    Object? card_nickname = null,
    Object? card_holder_name = null,
    Object? card_number = null,
    Object? cvv = null,
    Object? expiry_date = null,
    Object? invalid = null,
    Object? full_name = null,
    Object? id_number = null,
    Object? date_of_birth = null,
    Object? address = null,
    Object? mobile_number = null,
    Object? email = null,
    Object? please_ensure_info = null,
    Object? company_name = null,
    Object? cr_number = null,
    Object? vat_registration = null,
    Object? company_phone = null,
    Object? company_email = null,
    Object? auth_person_name = null,
    Object? auth_person_number = null,
    Object? attached_documents = null,
    Object? please_attach_required = null,
    Object? lets_add = null,
    Object? new_text = null,
    Object? select_doc_you_want = null,
    Object? done = null,
    Object? view_document = null,
    Object? version = null,
    Object? retry = null,
    Object? something_went_wrong = null,
    Object? jeddah = null,
    Object? dammam = null,
    Object? riyadh = null,
    Object? enter_full_name = null,
    Object? enter_id_number = null,
    Object? enter_dob = null,
    Object? enter_email = null,
    Object? enter_auth_name = null,
    Object? enter_auth_number = null,
    Object? enter_phone_number = null,
    Object? enter_vat_register = null,
    Object? enter_cr_number = null,
    Object? enter_address = null,
    Object? enter_otp_number = null,
    Object? otp_number = null,
    Object? invalid_email = null,
    Object? invalid_dob = null,
    Object? enter_company_name = null,
    Object? enter_company_phone = null,
    Object? enter_company_email = null,
    Object? rental_date = null,
    Object? rental_date_sub = null,
    Object? logout = null,
    Object? payment_method = null,
    Object? sadad_payment = null,
    Object? bank_tansfer = null,
    Object? card_payment = null,
    Object? select_payment_method = null,
    Object? upload = null,
    Object? termsOfServiceTitle = null,
    Object? termsOfServiceDescription = null,
    Object? agreeToTerms = null,
    Object? termsAndConditionsSub = null,
    Object? continue_checkbox = null,
    Object? yourSignature = null,
    Object? pleaseSignAbove = null,
    Object? clear = null,
    Object? to_continue_accept_terms_condintion = null,
    Object? to_continue_give_your_signature = null,
    Object? register = null,
    Object? you_do_not_have_ac = null,
    Object? create = null,
    Object? otp_successfully_send = null,
    Object? otp_failed_send = null,
    Object? send_otp = null,
    Object? do_not_have_ac = null,
    Object? discount = null,
    Object? your_info = null,
    Object? new_units = null,
    Object? booked = null,
    Object? booked_sub = null,
    Object? delete_ac = null,
    Object? delete_ac_sub = null,
    Object? optional = null,
    Object? quote = null,
    Object? request_quote = null,
    Object? request_quote_sub = null,
    Object? choose_branch = null,
    Object? choose_area = null,
    Object? receiving_method = null,
    Object? via_email = null,
    Object? download_pdf = null,
    Object? send_via_email = null,
    Object? message = null,
    Object? your_personal_info = null,
    Object? nature_of_goods_stored = null,
    Object? take_a_tour_with_makhzny = null,
  }) {
    return _then(_value.copyWith(
      app_name: null == app_name
          ? _value.app_name
          : app_name // ignore: cast_nullable_to_non_nullable
              as String,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      next: null == next
          ? _value.next
          : next // ignore: cast_nullable_to_non_nullable
              as String,
      login: null == login
          ? _value.login
          : login // ignore: cast_nullable_to_non_nullable
              as String,
      resend: null == resend
          ? _value.resend
          : resend // ignore: cast_nullable_to_non_nullable
              as String,
      resend_in: null == resend_in
          ? _value.resend_in
          : resend_in // ignore: cast_nullable_to_non_nullable
              as String,
      enter_your_phone_number: null == enter_your_phone_number
          ? _value.enter_your_phone_number
          : enter_your_phone_number // ignore: cast_nullable_to_non_nullable
              as String,
      enter_number: null == enter_number
          ? _value.enter_number
          : enter_number // ignore: cast_nullable_to_non_nullable
              as String,
      welcome_to: null == welcome_to
          ? _value.welcome_to
          : welcome_to // ignore: cast_nullable_to_non_nullable
              as String,
      dont_miss_the_opportunity: null == dont_miss_the_opportunity
          ? _value.dont_miss_the_opportunity
          : dont_miss_the_opportunity // ignore: cast_nullable_to_non_nullable
              as String,
      enter_otp_send: null == enter_otp_send
          ? _value.enter_otp_send
          : enter_otp_send // ignore: cast_nullable_to_non_nullable
              as String,
      otp: null == otp
          ? _value.otp
          : otp // ignore: cast_nullable_to_non_nullable
              as String,
      my_storage: null == my_storage
          ? _value.my_storage
          : my_storage // ignore: cast_nullable_to_non_nullable
              as String,
      store: null == store
          ? _value.store
          : store // ignore: cast_nullable_to_non_nullable
              as String,
      home: null == home
          ? _value.home
          : home // ignore: cast_nullable_to_non_nullable
              as String,
      gate_access: null == gate_access
          ? _value.gate_access
          : gate_access // ignore: cast_nullable_to_non_nullable
              as String,
      settings: null == settings
          ? _value.settings
          : settings // ignore: cast_nullable_to_non_nullable
              as String,
      welcome_frnd: null == welcome_frnd
          ? _value.welcome_frnd
          : welcome_frnd // ignore: cast_nullable_to_non_nullable
              as String,
      it_is_time_to_get_origanized: null == it_is_time_to_get_origanized
          ? _value.it_is_time_to_get_origanized
          : it_is_time_to_get_origanized // ignore: cast_nullable_to_non_nullable
              as String,
      we_have_place: null == we_have_place
          ? _value.we_have_place
          : we_have_place // ignore: cast_nullable_to_non_nullable
              as String,
      first_since: null == first_since
          ? _value.first_since
          : first_since // ignore: cast_nullable_to_non_nullable
              as String,
      rent_now: null == rent_now
          ? _value.rent_now
          : rent_now // ignore: cast_nullable_to_non_nullable
              as String,
      trending_now: null == trending_now
          ? _value.trending_now
          : trending_now // ignore: cast_nullable_to_non_nullable
              as String,
      last_booked: null == last_booked
          ? _value.last_booked
          : last_booked // ignore: cast_nullable_to_non_nullable
              as String,
      add_to_cart: null == add_to_cart
          ? _value.add_to_cart
          : add_to_cart // ignore: cast_nullable_to_non_nullable
              as String,
      to_able_to_view: null == to_able_to_view
          ? _value.to_able_to_view
          : to_able_to_view // ignore: cast_nullable_to_non_nullable
              as String,
      sign_in: null == sign_in
          ? _value.sign_in
          : sign_in // ignore: cast_nullable_to_non_nullable
              as String,
      all: null == all
          ? _value.all
          : all // ignore: cast_nullable_to_non_nullable
              as String,
      self_storage: null == self_storage
          ? _value.self_storage
          : self_storage // ignore: cast_nullable_to_non_nullable
              as String,
      others: null == others
          ? _value.others
          : others // ignore: cast_nullable_to_non_nullable
              as String,
      auto_renew: null == auto_renew
          ? _value.auto_renew
          : auto_renew // ignore: cast_nullable_to_non_nullable
              as String,
      total_number: null == total_number
          ? _value.total_number
          : total_number // ignore: cast_nullable_to_non_nullable
              as String,
      rented_items: null == rented_items
          ? _value.rented_items
          : rented_items // ignore: cast_nullable_to_non_nullable
              as String,
      no_results_found: null == no_results_found
          ? _value.no_results_found
          : no_results_found // ignore: cast_nullable_to_non_nullable
              as String,
      try_to_use_other_filter: null == try_to_use_other_filter
          ? _value.try_to_use_other_filter
          : try_to_use_other_filter // ignore: cast_nullable_to_non_nullable
              as String,
      continue_text: null == continue_text
          ? _value.continue_text
          : continue_text // ignore: cast_nullable_to_non_nullable
              as String,
      cancel: null == cancel
          ? _value.cancel
          : cancel // ignore: cast_nullable_to_non_nullable
              as String,
      are_you_sure_renewal: null == are_you_sure_renewal
          ? _value.are_you_sure_renewal
          : are_you_sure_renewal // ignore: cast_nullable_to_non_nullable
              as String,
      yes: null == yes
          ? _value.yes
          : yes // ignore: cast_nullable_to_non_nullable
              as String,
      rental_option: null == rental_option
          ? _value.rental_option
          : rental_option // ignore: cast_nullable_to_non_nullable
              as String,
      invoice_period: null == invoice_period
          ? _value.invoice_period
          : invoice_period // ignore: cast_nullable_to_non_nullable
              as String,
      invoice_period_sub: null == invoice_period_sub
          ? _value.invoice_period_sub
          : invoice_period_sub // ignore: cast_nullable_to_non_nullable
              as String,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as String,
      quantity_sub: null == quantity_sub
          ? _value.quantity_sub
          : quantity_sub // ignore: cast_nullable_to_non_nullable
              as String,
      montly: null == montly
          ? _value.montly
          : montly // ignore: cast_nullable_to_non_nullable
              as String,
      semi_annual: null == semi_annual
          ? _value.semi_annual
          : semi_annual // ignore: cast_nullable_to_non_nullable
              as String,
      annual: null == annual
          ? _value.annual
          : annual // ignore: cast_nullable_to_non_nullable
              as String,
      quarterly: null == quarterly
          ? _value.quarterly
          : quarterly // ignore: cast_nullable_to_non_nullable
              as String,
      add: null == add
          ? _value.add
          : add // ignore: cast_nullable_to_non_nullable
              as String,
      total: null == total
          ? _value.total
          : total // ignore: cast_nullable_to_non_nullable
              as String,
      storage_units: null == storage_units
          ? _value.storage_units
          : storage_units // ignore: cast_nullable_to_non_nullable
              as String,
      general_items: null == general_items
          ? _value.general_items
          : general_items // ignore: cast_nullable_to_non_nullable
              as String,
      your_cart_is_empty: null == your_cart_is_empty
          ? _value.your_cart_is_empty
          : your_cart_is_empty // ignore: cast_nullable_to_non_nullable
              as String,
      lets_add_something: null == lets_add_something
          ? _value.lets_add_something
          : lets_add_something // ignore: cast_nullable_to_non_nullable
              as String,
      my_cart: null == my_cart
          ? _value.my_cart
          : my_cart // ignore: cast_nullable_to_non_nullable
              as String,
      clear_all_items: null == clear_all_items
          ? _value.clear_all_items
          : clear_all_items // ignore: cast_nullable_to_non_nullable
              as String,
      add_ons: null == add_ons
          ? _value.add_ons
          : add_ons // ignore: cast_nullable_to_non_nullable
              as String,
      total_amount: null == total_amount
          ? _value.total_amount
          : total_amount // ignore: cast_nullable_to_non_nullable
              as String,
      vat: null == vat
          ? _value.vat
          : vat // ignore: cast_nullable_to_non_nullable
              as String,
      payable_amount: null == payable_amount
          ? _value.payable_amount
          : payable_amount // ignore: cast_nullable_to_non_nullable
              as String,
      checkout: null == checkout
          ? _value.checkout
          : checkout // ignore: cast_nullable_to_non_nullable
              as String,
      are_you_sure_cart: null == are_you_sure_cart
          ? _value.are_you_sure_cart
          : are_you_sure_cart // ignore: cast_nullable_to_non_nullable
              as String,
      personal: null == personal
          ? _value.personal
          : personal // ignore: cast_nullable_to_non_nullable
              as String,
      business: null == business
          ? _value.business
          : business // ignore: cast_nullable_to_non_nullable
              as String,
      open: null == open
          ? _value.open
          : open // ignore: cast_nullable_to_non_nullable
              as String,
      close: null == close
          ? _value.close
          : close // ignore: cast_nullable_to_non_nullable
              as String,
      access_code: null == access_code
          ? _value.access_code
          : access_code // ignore: cast_nullable_to_non_nullable
              as String,
      pls_enter_code: null == pls_enter_code
          ? _value.pls_enter_code
          : pls_enter_code // ignore: cast_nullable_to_non_nullable
              as String,
      profile: null == profile
          ? _value.profile
          : profile // ignore: cast_nullable_to_non_nullable
              as String,
      languages: null == languages
          ? _value.languages
          : languages // ignore: cast_nullable_to_non_nullable
              as String,
      appearance: null == appearance
          ? _value.appearance
          : appearance // ignore: cast_nullable_to_non_nullable
              as String,
      saved_payment_methods: null == saved_payment_methods
          ? _value.saved_payment_methods
          : saved_payment_methods // ignore: cast_nullable_to_non_nullable
              as String,
      documents: null == documents
          ? _value.documents
          : documents // ignore: cast_nullable_to_non_nullable
              as String,
      invoices: null == invoices
          ? _value.invoices
          : invoices // ignore: cast_nullable_to_non_nullable
              as String,
      paid: null == paid
          ? _value.paid
          : paid // ignore: cast_nullable_to_non_nullable
              as String,
      unpaid: null == unpaid
          ? _value.unpaid
          : unpaid // ignore: cast_nullable_to_non_nullable
              as String,
      rejected: null == rejected
          ? _value.rejected
          : rejected // ignore: cast_nullable_to_non_nullable
              as String,
      are_you_sure_delete_doc: null == are_you_sure_delete_doc
          ? _value.are_you_sure_delete_doc
          : are_you_sure_delete_doc // ignore: cast_nullable_to_non_nullable
              as String,
      add_document: null == add_document
          ? _value.add_document
          : add_document // ignore: cast_nullable_to_non_nullable
              as String,
      upload_from_phone: null == upload_from_phone
          ? _value.upload_from_phone
          : upload_from_phone // ignore: cast_nullable_to_non_nullable
              as String,
      open_pdf_scanner: null == open_pdf_scanner
          ? _value.open_pdf_scanner
          : open_pdf_scanner // ignore: cast_nullable_to_non_nullable
              as String,
      light_mode: null == light_mode
          ? _value.light_mode
          : light_mode // ignore: cast_nullable_to_non_nullable
              as String,
      light_mode_sub: null == light_mode_sub
          ? _value.light_mode_sub
          : light_mode_sub // ignore: cast_nullable_to_non_nullable
              as String,
      dark_mode: null == dark_mode
          ? _value.dark_mode
          : dark_mode // ignore: cast_nullable_to_non_nullable
              as String,
      dark_mode_sub: null == dark_mode_sub
          ? _value.dark_mode_sub
          : dark_mode_sub // ignore: cast_nullable_to_non_nullable
              as String,
      auto_mode: null == auto_mode
          ? _value.auto_mode
          : auto_mode // ignore: cast_nullable_to_non_nullable
              as String,
      auto_mode_sub: null == auto_mode_sub
          ? _value.auto_mode_sub
          : auto_mode_sub // ignore: cast_nullable_to_non_nullable
              as String,
      are_you_sure_card: null == are_you_sure_card
          ? _value.are_you_sure_card
          : are_you_sure_card // ignore: cast_nullable_to_non_nullable
              as String,
      add_card: null == add_card
          ? _value.add_card
          : add_card // ignore: cast_nullable_to_non_nullable
              as String,
      card_nickname: null == card_nickname
          ? _value.card_nickname
          : card_nickname // ignore: cast_nullable_to_non_nullable
              as String,
      card_holder_name: null == card_holder_name
          ? _value.card_holder_name
          : card_holder_name // ignore: cast_nullable_to_non_nullable
              as String,
      card_number: null == card_number
          ? _value.card_number
          : card_number // ignore: cast_nullable_to_non_nullable
              as String,
      cvv: null == cvv
          ? _value.cvv
          : cvv // ignore: cast_nullable_to_non_nullable
              as String,
      expiry_date: null == expiry_date
          ? _value.expiry_date
          : expiry_date // ignore: cast_nullable_to_non_nullable
              as String,
      invalid: null == invalid
          ? _value.invalid
          : invalid // ignore: cast_nullable_to_non_nullable
              as String,
      full_name: null == full_name
          ? _value.full_name
          : full_name // ignore: cast_nullable_to_non_nullable
              as String,
      id_number: null == id_number
          ? _value.id_number
          : id_number // ignore: cast_nullable_to_non_nullable
              as String,
      date_of_birth: null == date_of_birth
          ? _value.date_of_birth
          : date_of_birth // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      mobile_number: null == mobile_number
          ? _value.mobile_number
          : mobile_number // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      please_ensure_info: null == please_ensure_info
          ? _value.please_ensure_info
          : please_ensure_info // ignore: cast_nullable_to_non_nullable
              as String,
      company_name: null == company_name
          ? _value.company_name
          : company_name // ignore: cast_nullable_to_non_nullable
              as String,
      cr_number: null == cr_number
          ? _value.cr_number
          : cr_number // ignore: cast_nullable_to_non_nullable
              as String,
      vat_registration: null == vat_registration
          ? _value.vat_registration
          : vat_registration // ignore: cast_nullable_to_non_nullable
              as String,
      company_phone: null == company_phone
          ? _value.company_phone
          : company_phone // ignore: cast_nullable_to_non_nullable
              as String,
      company_email: null == company_email
          ? _value.company_email
          : company_email // ignore: cast_nullable_to_non_nullable
              as String,
      auth_person_name: null == auth_person_name
          ? _value.auth_person_name
          : auth_person_name // ignore: cast_nullable_to_non_nullable
              as String,
      auth_person_number: null == auth_person_number
          ? _value.auth_person_number
          : auth_person_number // ignore: cast_nullable_to_non_nullable
              as String,
      attached_documents: null == attached_documents
          ? _value.attached_documents
          : attached_documents // ignore: cast_nullable_to_non_nullable
              as String,
      please_attach_required: null == please_attach_required
          ? _value.please_attach_required
          : please_attach_required // ignore: cast_nullable_to_non_nullable
              as String,
      lets_add: null == lets_add
          ? _value.lets_add
          : lets_add // ignore: cast_nullable_to_non_nullable
              as String,
      new_text: null == new_text
          ? _value.new_text
          : new_text // ignore: cast_nullable_to_non_nullable
              as String,
      select_doc_you_want: null == select_doc_you_want
          ? _value.select_doc_you_want
          : select_doc_you_want // ignore: cast_nullable_to_non_nullable
              as String,
      done: null == done
          ? _value.done
          : done // ignore: cast_nullable_to_non_nullable
              as String,
      view_document: null == view_document
          ? _value.view_document
          : view_document // ignore: cast_nullable_to_non_nullable
              as String,
      version: null == version
          ? _value.version
          : version // ignore: cast_nullable_to_non_nullable
              as String,
      retry: null == retry
          ? _value.retry
          : retry // ignore: cast_nullable_to_non_nullable
              as String,
      something_went_wrong: null == something_went_wrong
          ? _value.something_went_wrong
          : something_went_wrong // ignore: cast_nullable_to_non_nullable
              as String,
      jeddah: null == jeddah
          ? _value.jeddah
          : jeddah // ignore: cast_nullable_to_non_nullable
              as String,
      dammam: null == dammam
          ? _value.dammam
          : dammam // ignore: cast_nullable_to_non_nullable
              as String,
      riyadh: null == riyadh
          ? _value.riyadh
          : riyadh // ignore: cast_nullable_to_non_nullable
              as String,
      enter_full_name: null == enter_full_name
          ? _value.enter_full_name
          : enter_full_name // ignore: cast_nullable_to_non_nullable
              as String,
      enter_id_number: null == enter_id_number
          ? _value.enter_id_number
          : enter_id_number // ignore: cast_nullable_to_non_nullable
              as String,
      enter_dob: null == enter_dob
          ? _value.enter_dob
          : enter_dob // ignore: cast_nullable_to_non_nullable
              as String,
      enter_email: null == enter_email
          ? _value.enter_email
          : enter_email // ignore: cast_nullable_to_non_nullable
              as String,
      enter_auth_name: null == enter_auth_name
          ? _value.enter_auth_name
          : enter_auth_name // ignore: cast_nullable_to_non_nullable
              as String,
      enter_auth_number: null == enter_auth_number
          ? _value.enter_auth_number
          : enter_auth_number // ignore: cast_nullable_to_non_nullable
              as String,
      enter_phone_number: null == enter_phone_number
          ? _value.enter_phone_number
          : enter_phone_number // ignore: cast_nullable_to_non_nullable
              as String,
      enter_vat_register: null == enter_vat_register
          ? _value.enter_vat_register
          : enter_vat_register // ignore: cast_nullable_to_non_nullable
              as String,
      enter_cr_number: null == enter_cr_number
          ? _value.enter_cr_number
          : enter_cr_number // ignore: cast_nullable_to_non_nullable
              as String,
      enter_address: null == enter_address
          ? _value.enter_address
          : enter_address // ignore: cast_nullable_to_non_nullable
              as String,
      enter_otp_number: null == enter_otp_number
          ? _value.enter_otp_number
          : enter_otp_number // ignore: cast_nullable_to_non_nullable
              as String,
      otp_number: null == otp_number
          ? _value.otp_number
          : otp_number // ignore: cast_nullable_to_non_nullable
              as String,
      invalid_email: null == invalid_email
          ? _value.invalid_email
          : invalid_email // ignore: cast_nullable_to_non_nullable
              as String,
      invalid_dob: null == invalid_dob
          ? _value.invalid_dob
          : invalid_dob // ignore: cast_nullable_to_non_nullable
              as String,
      enter_company_name: null == enter_company_name
          ? _value.enter_company_name
          : enter_company_name // ignore: cast_nullable_to_non_nullable
              as String,
      enter_company_phone: null == enter_company_phone
          ? _value.enter_company_phone
          : enter_company_phone // ignore: cast_nullable_to_non_nullable
              as String,
      enter_company_email: null == enter_company_email
          ? _value.enter_company_email
          : enter_company_email // ignore: cast_nullable_to_non_nullable
              as String,
      rental_date: null == rental_date
          ? _value.rental_date
          : rental_date // ignore: cast_nullable_to_non_nullable
              as String,
      rental_date_sub: null == rental_date_sub
          ? _value.rental_date_sub
          : rental_date_sub // ignore: cast_nullable_to_non_nullable
              as String,
      logout: null == logout
          ? _value.logout
          : logout // ignore: cast_nullable_to_non_nullable
              as String,
      payment_method: null == payment_method
          ? _value.payment_method
          : payment_method // ignore: cast_nullable_to_non_nullable
              as String,
      sadad_payment: null == sadad_payment
          ? _value.sadad_payment
          : sadad_payment // ignore: cast_nullable_to_non_nullable
              as String,
      bank_tansfer: null == bank_tansfer
          ? _value.bank_tansfer
          : bank_tansfer // ignore: cast_nullable_to_non_nullable
              as String,
      card_payment: null == card_payment
          ? _value.card_payment
          : card_payment // ignore: cast_nullable_to_non_nullable
              as String,
      select_payment_method: null == select_payment_method
          ? _value.select_payment_method
          : select_payment_method // ignore: cast_nullable_to_non_nullable
              as String,
      upload: null == upload
          ? _value.upload
          : upload // ignore: cast_nullable_to_non_nullable
              as String,
      termsOfServiceTitle: null == termsOfServiceTitle
          ? _value.termsOfServiceTitle
          : termsOfServiceTitle // ignore: cast_nullable_to_non_nullable
              as String,
      termsOfServiceDescription: null == termsOfServiceDescription
          ? _value.termsOfServiceDescription
          : termsOfServiceDescription // ignore: cast_nullable_to_non_nullable
              as String,
      agreeToTerms: null == agreeToTerms
          ? _value.agreeToTerms
          : agreeToTerms // ignore: cast_nullable_to_non_nullable
              as String,
      termsAndConditionsSub: null == termsAndConditionsSub
          ? _value.termsAndConditionsSub
          : termsAndConditionsSub // ignore: cast_nullable_to_non_nullable
              as String,
      continue_checkbox: null == continue_checkbox
          ? _value.continue_checkbox
          : continue_checkbox // ignore: cast_nullable_to_non_nullable
              as String,
      yourSignature: null == yourSignature
          ? _value.yourSignature
          : yourSignature // ignore: cast_nullable_to_non_nullable
              as String,
      pleaseSignAbove: null == pleaseSignAbove
          ? _value.pleaseSignAbove
          : pleaseSignAbove // ignore: cast_nullable_to_non_nullable
              as String,
      clear: null == clear
          ? _value.clear
          : clear // ignore: cast_nullable_to_non_nullable
              as String,
      to_continue_accept_terms_condintion: null ==
              to_continue_accept_terms_condintion
          ? _value.to_continue_accept_terms_condintion
          : to_continue_accept_terms_condintion // ignore: cast_nullable_to_non_nullable
              as String,
      to_continue_give_your_signature: null == to_continue_give_your_signature
          ? _value.to_continue_give_your_signature
          : to_continue_give_your_signature // ignore: cast_nullable_to_non_nullable
              as String,
      register: null == register
          ? _value.register
          : register // ignore: cast_nullable_to_non_nullable
              as String,
      you_do_not_have_ac: null == you_do_not_have_ac
          ? _value.you_do_not_have_ac
          : you_do_not_have_ac // ignore: cast_nullable_to_non_nullable
              as String,
      create: null == create
          ? _value.create
          : create // ignore: cast_nullable_to_non_nullable
              as String,
      otp_successfully_send: null == otp_successfully_send
          ? _value.otp_successfully_send
          : otp_successfully_send // ignore: cast_nullable_to_non_nullable
              as String,
      otp_failed_send: null == otp_failed_send
          ? _value.otp_failed_send
          : otp_failed_send // ignore: cast_nullable_to_non_nullable
              as String,
      send_otp: null == send_otp
          ? _value.send_otp
          : send_otp // ignore: cast_nullable_to_non_nullable
              as String,
      do_not_have_ac: null == do_not_have_ac
          ? _value.do_not_have_ac
          : do_not_have_ac // ignore: cast_nullable_to_non_nullable
              as String,
      discount: null == discount
          ? _value.discount
          : discount // ignore: cast_nullable_to_non_nullable
              as String,
      your_info: null == your_info
          ? _value.your_info
          : your_info // ignore: cast_nullable_to_non_nullable
              as String,
      new_units: null == new_units
          ? _value.new_units
          : new_units // ignore: cast_nullable_to_non_nullable
              as String,
      booked: null == booked
          ? _value.booked
          : booked // ignore: cast_nullable_to_non_nullable
              as String,
      booked_sub: null == booked_sub
          ? _value.booked_sub
          : booked_sub // ignore: cast_nullable_to_non_nullable
              as String,
      delete_ac: null == delete_ac
          ? _value.delete_ac
          : delete_ac // ignore: cast_nullable_to_non_nullable
              as String,
      delete_ac_sub: null == delete_ac_sub
          ? _value.delete_ac_sub
          : delete_ac_sub // ignore: cast_nullable_to_non_nullable
              as String,
      optional: null == optional
          ? _value.optional
          : optional // ignore: cast_nullable_to_non_nullable
              as String,
      quote: null == quote
          ? _value.quote
          : quote // ignore: cast_nullable_to_non_nullable
              as String,
      request_quote: null == request_quote
          ? _value.request_quote
          : request_quote // ignore: cast_nullable_to_non_nullable
              as String,
      request_quote_sub: null == request_quote_sub
          ? _value.request_quote_sub
          : request_quote_sub // ignore: cast_nullable_to_non_nullable
              as String,
      choose_branch: null == choose_branch
          ? _value.choose_branch
          : choose_branch // ignore: cast_nullable_to_non_nullable
              as String,
      choose_area: null == choose_area
          ? _value.choose_area
          : choose_area // ignore: cast_nullable_to_non_nullable
              as String,
      receiving_method: null == receiving_method
          ? _value.receiving_method
          : receiving_method // ignore: cast_nullable_to_non_nullable
              as String,
      via_email: null == via_email
          ? _value.via_email
          : via_email // ignore: cast_nullable_to_non_nullable
              as String,
      download_pdf: null == download_pdf
          ? _value.download_pdf
          : download_pdf // ignore: cast_nullable_to_non_nullable
              as String,
      send_via_email: null == send_via_email
          ? _value.send_via_email
          : send_via_email // ignore: cast_nullable_to_non_nullable
              as String,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      your_personal_info: null == your_personal_info
          ? _value.your_personal_info
          : your_personal_info // ignore: cast_nullable_to_non_nullable
              as String,
      nature_of_goods_stored: null == nature_of_goods_stored
          ? _value.nature_of_goods_stored
          : nature_of_goods_stored // ignore: cast_nullable_to_non_nullable
              as String,
      take_a_tour_with_makhzny: null == take_a_tour_with_makhzny
          ? _value.take_a_tour_with_makhzny
          : take_a_tour_with_makhzny // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$LangModelImplCopyWith<$Res>
    implements $LangModelCopyWith<$Res> {
  factory _$$LangModelImplCopyWith(
          _$LangModelImpl value, $Res Function(_$LangModelImpl) then) =
      __$$LangModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String app_name,
      String search,
      String next,
      String login,
      String resend,
      String resend_in,
      String enter_your_phone_number,
      String enter_number,
      String welcome_to,
      String dont_miss_the_opportunity,
      String enter_otp_send,
      String otp,
      String my_storage,
      String store,
      String home,
      String gate_access,
      String settings,
      String welcome_frnd,
      String it_is_time_to_get_origanized,
      String we_have_place,
      String first_since,
      String rent_now,
      String trending_now,
      String last_booked,
      String add_to_cart,
      String to_able_to_view,
      String sign_in,
      String all,
      String self_storage,
      String others,
      String auto_renew,
      String total_number,
      String rented_items,
      String no_results_found,
      String try_to_use_other_filter,
      String continue_text,
      String cancel,
      String are_you_sure_renewal,
      String yes,
      String rental_option,
      String invoice_period,
      String invoice_period_sub,
      String quantity,
      String quantity_sub,
      String montly,
      String semi_annual,
      String annual,
      String quarterly,
      String add,
      String total,
      String storage_units,
      String general_items,
      String your_cart_is_empty,
      String lets_add_something,
      String my_cart,
      String clear_all_items,
      String add_ons,
      String total_amount,
      String vat,
      String payable_amount,
      String checkout,
      String are_you_sure_cart,
      String personal,
      String business,
      String open,
      String close,
      String access_code,
      String pls_enter_code,
      String profile,
      String languages,
      String appearance,
      String saved_payment_methods,
      String documents,
      String invoices,
      String paid,
      String unpaid,
      String rejected,
      String are_you_sure_delete_doc,
      String add_document,
      String upload_from_phone,
      String open_pdf_scanner,
      String light_mode,
      String light_mode_sub,
      String dark_mode,
      String dark_mode_sub,
      String auto_mode,
      String auto_mode_sub,
      String are_you_sure_card,
      String add_card,
      String card_nickname,
      String card_holder_name,
      String card_number,
      String cvv,
      String expiry_date,
      String invalid,
      String full_name,
      String id_number,
      String date_of_birth,
      String address,
      String mobile_number,
      String email,
      String please_ensure_info,
      String company_name,
      String cr_number,
      String vat_registration,
      String company_phone,
      String company_email,
      String auth_person_name,
      String auth_person_number,
      String attached_documents,
      String please_attach_required,
      String lets_add,
      String new_text,
      String select_doc_you_want,
      String done,
      String view_document,
      String version,
      String retry,
      String something_went_wrong,
      String jeddah,
      String dammam,
      String riyadh,
      String enter_full_name,
      String enter_id_number,
      String enter_dob,
      String enter_email,
      String enter_auth_name,
      String enter_auth_number,
      String enter_phone_number,
      String enter_vat_register,
      String enter_cr_number,
      String enter_address,
      String enter_otp_number,
      String otp_number,
      String invalid_email,
      String invalid_dob,
      String enter_company_name,
      String enter_company_phone,
      String enter_company_email,
      String rental_date,
      String rental_date_sub,
      String logout,
      String payment_method,
      String sadad_payment,
      String bank_tansfer,
      String card_payment,
      String select_payment_method,
      String upload,
      String termsOfServiceTitle,
      String termsOfServiceDescription,
      String agreeToTerms,
      String termsAndConditionsSub,
      String continue_checkbox,
      String yourSignature,
      String pleaseSignAbove,
      String clear,
      String to_continue_accept_terms_condintion,
      String to_continue_give_your_signature,
      String register,
      String you_do_not_have_ac,
      String create,
      String otp_successfully_send,
      String otp_failed_send,
      String send_otp,
      String do_not_have_ac,
      String discount,
      String your_info,
      String new_units,
      String booked,
      String booked_sub,
      String delete_ac,
      String delete_ac_sub,
      String optional,
      String quote,
      String request_quote,
      String request_quote_sub,
      String choose_branch,
      String choose_area,
      String receiving_method,
      String via_email,
      String download_pdf,
      String send_via_email,
      String message,
      String your_personal_info,
      String nature_of_goods_stored,
      String take_a_tour_with_makhzny});
}

/// @nodoc
class __$$LangModelImplCopyWithImpl<$Res>
    extends _$LangModelCopyWithImpl<$Res, _$LangModelImpl>
    implements _$$LangModelImplCopyWith<$Res> {
  __$$LangModelImplCopyWithImpl(
      _$LangModelImpl _value, $Res Function(_$LangModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of LangModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? app_name = null,
    Object? search = null,
    Object? next = null,
    Object? login = null,
    Object? resend = null,
    Object? resend_in = null,
    Object? enter_your_phone_number = null,
    Object? enter_number = null,
    Object? welcome_to = null,
    Object? dont_miss_the_opportunity = null,
    Object? enter_otp_send = null,
    Object? otp = null,
    Object? my_storage = null,
    Object? store = null,
    Object? home = null,
    Object? gate_access = null,
    Object? settings = null,
    Object? welcome_frnd = null,
    Object? it_is_time_to_get_origanized = null,
    Object? we_have_place = null,
    Object? first_since = null,
    Object? rent_now = null,
    Object? trending_now = null,
    Object? last_booked = null,
    Object? add_to_cart = null,
    Object? to_able_to_view = null,
    Object? sign_in = null,
    Object? all = null,
    Object? self_storage = null,
    Object? others = null,
    Object? auto_renew = null,
    Object? total_number = null,
    Object? rented_items = null,
    Object? no_results_found = null,
    Object? try_to_use_other_filter = null,
    Object? continue_text = null,
    Object? cancel = null,
    Object? are_you_sure_renewal = null,
    Object? yes = null,
    Object? rental_option = null,
    Object? invoice_period = null,
    Object? invoice_period_sub = null,
    Object? quantity = null,
    Object? quantity_sub = null,
    Object? montly = null,
    Object? semi_annual = null,
    Object? annual = null,
    Object? quarterly = null,
    Object? add = null,
    Object? total = null,
    Object? storage_units = null,
    Object? general_items = null,
    Object? your_cart_is_empty = null,
    Object? lets_add_something = null,
    Object? my_cart = null,
    Object? clear_all_items = null,
    Object? add_ons = null,
    Object? total_amount = null,
    Object? vat = null,
    Object? payable_amount = null,
    Object? checkout = null,
    Object? are_you_sure_cart = null,
    Object? personal = null,
    Object? business = null,
    Object? open = null,
    Object? close = null,
    Object? access_code = null,
    Object? pls_enter_code = null,
    Object? profile = null,
    Object? languages = null,
    Object? appearance = null,
    Object? saved_payment_methods = null,
    Object? documents = null,
    Object? invoices = null,
    Object? paid = null,
    Object? unpaid = null,
    Object? rejected = null,
    Object? are_you_sure_delete_doc = null,
    Object? add_document = null,
    Object? upload_from_phone = null,
    Object? open_pdf_scanner = null,
    Object? light_mode = null,
    Object? light_mode_sub = null,
    Object? dark_mode = null,
    Object? dark_mode_sub = null,
    Object? auto_mode = null,
    Object? auto_mode_sub = null,
    Object? are_you_sure_card = null,
    Object? add_card = null,
    Object? card_nickname = null,
    Object? card_holder_name = null,
    Object? card_number = null,
    Object? cvv = null,
    Object? expiry_date = null,
    Object? invalid = null,
    Object? full_name = null,
    Object? id_number = null,
    Object? date_of_birth = null,
    Object? address = null,
    Object? mobile_number = null,
    Object? email = null,
    Object? please_ensure_info = null,
    Object? company_name = null,
    Object? cr_number = null,
    Object? vat_registration = null,
    Object? company_phone = null,
    Object? company_email = null,
    Object? auth_person_name = null,
    Object? auth_person_number = null,
    Object? attached_documents = null,
    Object? please_attach_required = null,
    Object? lets_add = null,
    Object? new_text = null,
    Object? select_doc_you_want = null,
    Object? done = null,
    Object? view_document = null,
    Object? version = null,
    Object? retry = null,
    Object? something_went_wrong = null,
    Object? jeddah = null,
    Object? dammam = null,
    Object? riyadh = null,
    Object? enter_full_name = null,
    Object? enter_id_number = null,
    Object? enter_dob = null,
    Object? enter_email = null,
    Object? enter_auth_name = null,
    Object? enter_auth_number = null,
    Object? enter_phone_number = null,
    Object? enter_vat_register = null,
    Object? enter_cr_number = null,
    Object? enter_address = null,
    Object? enter_otp_number = null,
    Object? otp_number = null,
    Object? invalid_email = null,
    Object? invalid_dob = null,
    Object? enter_company_name = null,
    Object? enter_company_phone = null,
    Object? enter_company_email = null,
    Object? rental_date = null,
    Object? rental_date_sub = null,
    Object? logout = null,
    Object? payment_method = null,
    Object? sadad_payment = null,
    Object? bank_tansfer = null,
    Object? card_payment = null,
    Object? select_payment_method = null,
    Object? upload = null,
    Object? termsOfServiceTitle = null,
    Object? termsOfServiceDescription = null,
    Object? agreeToTerms = null,
    Object? termsAndConditionsSub = null,
    Object? continue_checkbox = null,
    Object? yourSignature = null,
    Object? pleaseSignAbove = null,
    Object? clear = null,
    Object? to_continue_accept_terms_condintion = null,
    Object? to_continue_give_your_signature = null,
    Object? register = null,
    Object? you_do_not_have_ac = null,
    Object? create = null,
    Object? otp_successfully_send = null,
    Object? otp_failed_send = null,
    Object? send_otp = null,
    Object? do_not_have_ac = null,
    Object? discount = null,
    Object? your_info = null,
    Object? new_units = null,
    Object? booked = null,
    Object? booked_sub = null,
    Object? delete_ac = null,
    Object? delete_ac_sub = null,
    Object? optional = null,
    Object? quote = null,
    Object? request_quote = null,
    Object? request_quote_sub = null,
    Object? choose_branch = null,
    Object? choose_area = null,
    Object? receiving_method = null,
    Object? via_email = null,
    Object? download_pdf = null,
    Object? send_via_email = null,
    Object? message = null,
    Object? your_personal_info = null,
    Object? nature_of_goods_stored = null,
    Object? take_a_tour_with_makhzny = null,
  }) {
    return _then(_$LangModelImpl(
      app_name: null == app_name
          ? _value.app_name
          : app_name // ignore: cast_nullable_to_non_nullable
              as String,
      search: null == search
          ? _value.search
          : search // ignore: cast_nullable_to_non_nullable
              as String,
      next: null == next
          ? _value.next
          : next // ignore: cast_nullable_to_non_nullable
              as String,
      login: null == login
          ? _value.login
          : login // ignore: cast_nullable_to_non_nullable
              as String,
      resend: null == resend
          ? _value.resend
          : resend // ignore: cast_nullable_to_non_nullable
              as String,
      resend_in: null == resend_in
          ? _value.resend_in
          : resend_in // ignore: cast_nullable_to_non_nullable
              as String,
      enter_your_phone_number: null == enter_your_phone_number
          ? _value.enter_your_phone_number
          : enter_your_phone_number // ignore: cast_nullable_to_non_nullable
              as String,
      enter_number: null == enter_number
          ? _value.enter_number
          : enter_number // ignore: cast_nullable_to_non_nullable
              as String,
      welcome_to: null == welcome_to
          ? _value.welcome_to
          : welcome_to // ignore: cast_nullable_to_non_nullable
              as String,
      dont_miss_the_opportunity: null == dont_miss_the_opportunity
          ? _value.dont_miss_the_opportunity
          : dont_miss_the_opportunity // ignore: cast_nullable_to_non_nullable
              as String,
      enter_otp_send: null == enter_otp_send
          ? _value.enter_otp_send
          : enter_otp_send // ignore: cast_nullable_to_non_nullable
              as String,
      otp: null == otp
          ? _value.otp
          : otp // ignore: cast_nullable_to_non_nullable
              as String,
      my_storage: null == my_storage
          ? _value.my_storage
          : my_storage // ignore: cast_nullable_to_non_nullable
              as String,
      store: null == store
          ? _value.store
          : store // ignore: cast_nullable_to_non_nullable
              as String,
      home: null == home
          ? _value.home
          : home // ignore: cast_nullable_to_non_nullable
              as String,
      gate_access: null == gate_access
          ? _value.gate_access
          : gate_access // ignore: cast_nullable_to_non_nullable
              as String,
      settings: null == settings
          ? _value.settings
          : settings // ignore: cast_nullable_to_non_nullable
              as String,
      welcome_frnd: null == welcome_frnd
          ? _value.welcome_frnd
          : welcome_frnd // ignore: cast_nullable_to_non_nullable
              as String,
      it_is_time_to_get_origanized: null == it_is_time_to_get_origanized
          ? _value.it_is_time_to_get_origanized
          : it_is_time_to_get_origanized // ignore: cast_nullable_to_non_nullable
              as String,
      we_have_place: null == we_have_place
          ? _value.we_have_place
          : we_have_place // ignore: cast_nullable_to_non_nullable
              as String,
      first_since: null == first_since
          ? _value.first_since
          : first_since // ignore: cast_nullable_to_non_nullable
              as String,
      rent_now: null == rent_now
          ? _value.rent_now
          : rent_now // ignore: cast_nullable_to_non_nullable
              as String,
      trending_now: null == trending_now
          ? _value.trending_now
          : trending_now // ignore: cast_nullable_to_non_nullable
              as String,
      last_booked: null == last_booked
          ? _value.last_booked
          : last_booked // ignore: cast_nullable_to_non_nullable
              as String,
      add_to_cart: null == add_to_cart
          ? _value.add_to_cart
          : add_to_cart // ignore: cast_nullable_to_non_nullable
              as String,
      to_able_to_view: null == to_able_to_view
          ? _value.to_able_to_view
          : to_able_to_view // ignore: cast_nullable_to_non_nullable
              as String,
      sign_in: null == sign_in
          ? _value.sign_in
          : sign_in // ignore: cast_nullable_to_non_nullable
              as String,
      all: null == all
          ? _value.all
          : all // ignore: cast_nullable_to_non_nullable
              as String,
      self_storage: null == self_storage
          ? _value.self_storage
          : self_storage // ignore: cast_nullable_to_non_nullable
              as String,
      others: null == others
          ? _value.others
          : others // ignore: cast_nullable_to_non_nullable
              as String,
      auto_renew: null == auto_renew
          ? _value.auto_renew
          : auto_renew // ignore: cast_nullable_to_non_nullable
              as String,
      total_number: null == total_number
          ? _value.total_number
          : total_number // ignore: cast_nullable_to_non_nullable
              as String,
      rented_items: null == rented_items
          ? _value.rented_items
          : rented_items // ignore: cast_nullable_to_non_nullable
              as String,
      no_results_found: null == no_results_found
          ? _value.no_results_found
          : no_results_found // ignore: cast_nullable_to_non_nullable
              as String,
      try_to_use_other_filter: null == try_to_use_other_filter
          ? _value.try_to_use_other_filter
          : try_to_use_other_filter // ignore: cast_nullable_to_non_nullable
              as String,
      continue_text: null == continue_text
          ? _value.continue_text
          : continue_text // ignore: cast_nullable_to_non_nullable
              as String,
      cancel: null == cancel
          ? _value.cancel
          : cancel // ignore: cast_nullable_to_non_nullable
              as String,
      are_you_sure_renewal: null == are_you_sure_renewal
          ? _value.are_you_sure_renewal
          : are_you_sure_renewal // ignore: cast_nullable_to_non_nullable
              as String,
      yes: null == yes
          ? _value.yes
          : yes // ignore: cast_nullable_to_non_nullable
              as String,
      rental_option: null == rental_option
          ? _value.rental_option
          : rental_option // ignore: cast_nullable_to_non_nullable
              as String,
      invoice_period: null == invoice_period
          ? _value.invoice_period
          : invoice_period // ignore: cast_nullable_to_non_nullable
              as String,
      invoice_period_sub: null == invoice_period_sub
          ? _value.invoice_period_sub
          : invoice_period_sub // ignore: cast_nullable_to_non_nullable
              as String,
      quantity: null == quantity
          ? _value.quantity
          : quantity // ignore: cast_nullable_to_non_nullable
              as String,
      quantity_sub: null == quantity_sub
          ? _value.quantity_sub
          : quantity_sub // ignore: cast_nullable_to_non_nullable
              as String,
      montly: null == montly
          ? _value.montly
          : montly // ignore: cast_nullable_to_non_nullable
              as String,
      semi_annual: null == semi_annual
          ? _value.semi_annual
          : semi_annual // ignore: cast_nullable_to_non_nullable
              as String,
      annual: null == annual
          ? _value.annual
          : annual // ignore: cast_nullable_to_non_nullable
              as String,
      quarterly: null == quarterly
          ? _value.quarterly
          : quarterly // ignore: cast_nullable_to_non_nullable
              as String,
      add: null == add
          ? _value.add
          : add // ignore: cast_nullable_to_non_nullable
              as String,
      total: null == total
          ? _value.total
          : total // ignore: cast_nullable_to_non_nullable
              as String,
      storage_units: null == storage_units
          ? _value.storage_units
          : storage_units // ignore: cast_nullable_to_non_nullable
              as String,
      general_items: null == general_items
          ? _value.general_items
          : general_items // ignore: cast_nullable_to_non_nullable
              as String,
      your_cart_is_empty: null == your_cart_is_empty
          ? _value.your_cart_is_empty
          : your_cart_is_empty // ignore: cast_nullable_to_non_nullable
              as String,
      lets_add_something: null == lets_add_something
          ? _value.lets_add_something
          : lets_add_something // ignore: cast_nullable_to_non_nullable
              as String,
      my_cart: null == my_cart
          ? _value.my_cart
          : my_cart // ignore: cast_nullable_to_non_nullable
              as String,
      clear_all_items: null == clear_all_items
          ? _value.clear_all_items
          : clear_all_items // ignore: cast_nullable_to_non_nullable
              as String,
      add_ons: null == add_ons
          ? _value.add_ons
          : add_ons // ignore: cast_nullable_to_non_nullable
              as String,
      total_amount: null == total_amount
          ? _value.total_amount
          : total_amount // ignore: cast_nullable_to_non_nullable
              as String,
      vat: null == vat
          ? _value.vat
          : vat // ignore: cast_nullable_to_non_nullable
              as String,
      payable_amount: null == payable_amount
          ? _value.payable_amount
          : payable_amount // ignore: cast_nullable_to_non_nullable
              as String,
      checkout: null == checkout
          ? _value.checkout
          : checkout // ignore: cast_nullable_to_non_nullable
              as String,
      are_you_sure_cart: null == are_you_sure_cart
          ? _value.are_you_sure_cart
          : are_you_sure_cart // ignore: cast_nullable_to_non_nullable
              as String,
      personal: null == personal
          ? _value.personal
          : personal // ignore: cast_nullable_to_non_nullable
              as String,
      business: null == business
          ? _value.business
          : business // ignore: cast_nullable_to_non_nullable
              as String,
      open: null == open
          ? _value.open
          : open // ignore: cast_nullable_to_non_nullable
              as String,
      close: null == close
          ? _value.close
          : close // ignore: cast_nullable_to_non_nullable
              as String,
      access_code: null == access_code
          ? _value.access_code
          : access_code // ignore: cast_nullable_to_non_nullable
              as String,
      pls_enter_code: null == pls_enter_code
          ? _value.pls_enter_code
          : pls_enter_code // ignore: cast_nullable_to_non_nullable
              as String,
      profile: null == profile
          ? _value.profile
          : profile // ignore: cast_nullable_to_non_nullable
              as String,
      languages: null == languages
          ? _value.languages
          : languages // ignore: cast_nullable_to_non_nullable
              as String,
      appearance: null == appearance
          ? _value.appearance
          : appearance // ignore: cast_nullable_to_non_nullable
              as String,
      saved_payment_methods: null == saved_payment_methods
          ? _value.saved_payment_methods
          : saved_payment_methods // ignore: cast_nullable_to_non_nullable
              as String,
      documents: null == documents
          ? _value.documents
          : documents // ignore: cast_nullable_to_non_nullable
              as String,
      invoices: null == invoices
          ? _value.invoices
          : invoices // ignore: cast_nullable_to_non_nullable
              as String,
      paid: null == paid
          ? _value.paid
          : paid // ignore: cast_nullable_to_non_nullable
              as String,
      unpaid: null == unpaid
          ? _value.unpaid
          : unpaid // ignore: cast_nullable_to_non_nullable
              as String,
      rejected: null == rejected
          ? _value.rejected
          : rejected // ignore: cast_nullable_to_non_nullable
              as String,
      are_you_sure_delete_doc: null == are_you_sure_delete_doc
          ? _value.are_you_sure_delete_doc
          : are_you_sure_delete_doc // ignore: cast_nullable_to_non_nullable
              as String,
      add_document: null == add_document
          ? _value.add_document
          : add_document // ignore: cast_nullable_to_non_nullable
              as String,
      upload_from_phone: null == upload_from_phone
          ? _value.upload_from_phone
          : upload_from_phone // ignore: cast_nullable_to_non_nullable
              as String,
      open_pdf_scanner: null == open_pdf_scanner
          ? _value.open_pdf_scanner
          : open_pdf_scanner // ignore: cast_nullable_to_non_nullable
              as String,
      light_mode: null == light_mode
          ? _value.light_mode
          : light_mode // ignore: cast_nullable_to_non_nullable
              as String,
      light_mode_sub: null == light_mode_sub
          ? _value.light_mode_sub
          : light_mode_sub // ignore: cast_nullable_to_non_nullable
              as String,
      dark_mode: null == dark_mode
          ? _value.dark_mode
          : dark_mode // ignore: cast_nullable_to_non_nullable
              as String,
      dark_mode_sub: null == dark_mode_sub
          ? _value.dark_mode_sub
          : dark_mode_sub // ignore: cast_nullable_to_non_nullable
              as String,
      auto_mode: null == auto_mode
          ? _value.auto_mode
          : auto_mode // ignore: cast_nullable_to_non_nullable
              as String,
      auto_mode_sub: null == auto_mode_sub
          ? _value.auto_mode_sub
          : auto_mode_sub // ignore: cast_nullable_to_non_nullable
              as String,
      are_you_sure_card: null == are_you_sure_card
          ? _value.are_you_sure_card
          : are_you_sure_card // ignore: cast_nullable_to_non_nullable
              as String,
      add_card: null == add_card
          ? _value.add_card
          : add_card // ignore: cast_nullable_to_non_nullable
              as String,
      card_nickname: null == card_nickname
          ? _value.card_nickname
          : card_nickname // ignore: cast_nullable_to_non_nullable
              as String,
      card_holder_name: null == card_holder_name
          ? _value.card_holder_name
          : card_holder_name // ignore: cast_nullable_to_non_nullable
              as String,
      card_number: null == card_number
          ? _value.card_number
          : card_number // ignore: cast_nullable_to_non_nullable
              as String,
      cvv: null == cvv
          ? _value.cvv
          : cvv // ignore: cast_nullable_to_non_nullable
              as String,
      expiry_date: null == expiry_date
          ? _value.expiry_date
          : expiry_date // ignore: cast_nullable_to_non_nullable
              as String,
      invalid: null == invalid
          ? _value.invalid
          : invalid // ignore: cast_nullable_to_non_nullable
              as String,
      full_name: null == full_name
          ? _value.full_name
          : full_name // ignore: cast_nullable_to_non_nullable
              as String,
      id_number: null == id_number
          ? _value.id_number
          : id_number // ignore: cast_nullable_to_non_nullable
              as String,
      date_of_birth: null == date_of_birth
          ? _value.date_of_birth
          : date_of_birth // ignore: cast_nullable_to_non_nullable
              as String,
      address: null == address
          ? _value.address
          : address // ignore: cast_nullable_to_non_nullable
              as String,
      mobile_number: null == mobile_number
          ? _value.mobile_number
          : mobile_number // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      please_ensure_info: null == please_ensure_info
          ? _value.please_ensure_info
          : please_ensure_info // ignore: cast_nullable_to_non_nullable
              as String,
      company_name: null == company_name
          ? _value.company_name
          : company_name // ignore: cast_nullable_to_non_nullable
              as String,
      cr_number: null == cr_number
          ? _value.cr_number
          : cr_number // ignore: cast_nullable_to_non_nullable
              as String,
      vat_registration: null == vat_registration
          ? _value.vat_registration
          : vat_registration // ignore: cast_nullable_to_non_nullable
              as String,
      company_phone: null == company_phone
          ? _value.company_phone
          : company_phone // ignore: cast_nullable_to_non_nullable
              as String,
      company_email: null == company_email
          ? _value.company_email
          : company_email // ignore: cast_nullable_to_non_nullable
              as String,
      auth_person_name: null == auth_person_name
          ? _value.auth_person_name
          : auth_person_name // ignore: cast_nullable_to_non_nullable
              as String,
      auth_person_number: null == auth_person_number
          ? _value.auth_person_number
          : auth_person_number // ignore: cast_nullable_to_non_nullable
              as String,
      attached_documents: null == attached_documents
          ? _value.attached_documents
          : attached_documents // ignore: cast_nullable_to_non_nullable
              as String,
      please_attach_required: null == please_attach_required
          ? _value.please_attach_required
          : please_attach_required // ignore: cast_nullable_to_non_nullable
              as String,
      lets_add: null == lets_add
          ? _value.lets_add
          : lets_add // ignore: cast_nullable_to_non_nullable
              as String,
      new_text: null == new_text
          ? _value.new_text
          : new_text // ignore: cast_nullable_to_non_nullable
              as String,
      select_doc_you_want: null == select_doc_you_want
          ? _value.select_doc_you_want
          : select_doc_you_want // ignore: cast_nullable_to_non_nullable
              as String,
      done: null == done
          ? _value.done
          : done // ignore: cast_nullable_to_non_nullable
              as String,
      view_document: null == view_document
          ? _value.view_document
          : view_document // ignore: cast_nullable_to_non_nullable
              as String,
      version: null == version
          ? _value.version
          : version // ignore: cast_nullable_to_non_nullable
              as String,
      retry: null == retry
          ? _value.retry
          : retry // ignore: cast_nullable_to_non_nullable
              as String,
      something_went_wrong: null == something_went_wrong
          ? _value.something_went_wrong
          : something_went_wrong // ignore: cast_nullable_to_non_nullable
              as String,
      jeddah: null == jeddah
          ? _value.jeddah
          : jeddah // ignore: cast_nullable_to_non_nullable
              as String,
      dammam: null == dammam
          ? _value.dammam
          : dammam // ignore: cast_nullable_to_non_nullable
              as String,
      riyadh: null == riyadh
          ? _value.riyadh
          : riyadh // ignore: cast_nullable_to_non_nullable
              as String,
      enter_full_name: null == enter_full_name
          ? _value.enter_full_name
          : enter_full_name // ignore: cast_nullable_to_non_nullable
              as String,
      enter_id_number: null == enter_id_number
          ? _value.enter_id_number
          : enter_id_number // ignore: cast_nullable_to_non_nullable
              as String,
      enter_dob: null == enter_dob
          ? _value.enter_dob
          : enter_dob // ignore: cast_nullable_to_non_nullable
              as String,
      enter_email: null == enter_email
          ? _value.enter_email
          : enter_email // ignore: cast_nullable_to_non_nullable
              as String,
      enter_auth_name: null == enter_auth_name
          ? _value.enter_auth_name
          : enter_auth_name // ignore: cast_nullable_to_non_nullable
              as String,
      enter_auth_number: null == enter_auth_number
          ? _value.enter_auth_number
          : enter_auth_number // ignore: cast_nullable_to_non_nullable
              as String,
      enter_phone_number: null == enter_phone_number
          ? _value.enter_phone_number
          : enter_phone_number // ignore: cast_nullable_to_non_nullable
              as String,
      enter_vat_register: null == enter_vat_register
          ? _value.enter_vat_register
          : enter_vat_register // ignore: cast_nullable_to_non_nullable
              as String,
      enter_cr_number: null == enter_cr_number
          ? _value.enter_cr_number
          : enter_cr_number // ignore: cast_nullable_to_non_nullable
              as String,
      enter_address: null == enter_address
          ? _value.enter_address
          : enter_address // ignore: cast_nullable_to_non_nullable
              as String,
      enter_otp_number: null == enter_otp_number
          ? _value.enter_otp_number
          : enter_otp_number // ignore: cast_nullable_to_non_nullable
              as String,
      otp_number: null == otp_number
          ? _value.otp_number
          : otp_number // ignore: cast_nullable_to_non_nullable
              as String,
      invalid_email: null == invalid_email
          ? _value.invalid_email
          : invalid_email // ignore: cast_nullable_to_non_nullable
              as String,
      invalid_dob: null == invalid_dob
          ? _value.invalid_dob
          : invalid_dob // ignore: cast_nullable_to_non_nullable
              as String,
      enter_company_name: null == enter_company_name
          ? _value.enter_company_name
          : enter_company_name // ignore: cast_nullable_to_non_nullable
              as String,
      enter_company_phone: null == enter_company_phone
          ? _value.enter_company_phone
          : enter_company_phone // ignore: cast_nullable_to_non_nullable
              as String,
      enter_company_email: null == enter_company_email
          ? _value.enter_company_email
          : enter_company_email // ignore: cast_nullable_to_non_nullable
              as String,
      rental_date: null == rental_date
          ? _value.rental_date
          : rental_date // ignore: cast_nullable_to_non_nullable
              as String,
      rental_date_sub: null == rental_date_sub
          ? _value.rental_date_sub
          : rental_date_sub // ignore: cast_nullable_to_non_nullable
              as String,
      logout: null == logout
          ? _value.logout
          : logout // ignore: cast_nullable_to_non_nullable
              as String,
      payment_method: null == payment_method
          ? _value.payment_method
          : payment_method // ignore: cast_nullable_to_non_nullable
              as String,
      sadad_payment: null == sadad_payment
          ? _value.sadad_payment
          : sadad_payment // ignore: cast_nullable_to_non_nullable
              as String,
      bank_tansfer: null == bank_tansfer
          ? _value.bank_tansfer
          : bank_tansfer // ignore: cast_nullable_to_non_nullable
              as String,
      card_payment: null == card_payment
          ? _value.card_payment
          : card_payment // ignore: cast_nullable_to_non_nullable
              as String,
      select_payment_method: null == select_payment_method
          ? _value.select_payment_method
          : select_payment_method // ignore: cast_nullable_to_non_nullable
              as String,
      upload: null == upload
          ? _value.upload
          : upload // ignore: cast_nullable_to_non_nullable
              as String,
      termsOfServiceTitle: null == termsOfServiceTitle
          ? _value.termsOfServiceTitle
          : termsOfServiceTitle // ignore: cast_nullable_to_non_nullable
              as String,
      termsOfServiceDescription: null == termsOfServiceDescription
          ? _value.termsOfServiceDescription
          : termsOfServiceDescription // ignore: cast_nullable_to_non_nullable
              as String,
      agreeToTerms: null == agreeToTerms
          ? _value.agreeToTerms
          : agreeToTerms // ignore: cast_nullable_to_non_nullable
              as String,
      termsAndConditionsSub: null == termsAndConditionsSub
          ? _value.termsAndConditionsSub
          : termsAndConditionsSub // ignore: cast_nullable_to_non_nullable
              as String,
      continue_checkbox: null == continue_checkbox
          ? _value.continue_checkbox
          : continue_checkbox // ignore: cast_nullable_to_non_nullable
              as String,
      yourSignature: null == yourSignature
          ? _value.yourSignature
          : yourSignature // ignore: cast_nullable_to_non_nullable
              as String,
      pleaseSignAbove: null == pleaseSignAbove
          ? _value.pleaseSignAbove
          : pleaseSignAbove // ignore: cast_nullable_to_non_nullable
              as String,
      clear: null == clear
          ? _value.clear
          : clear // ignore: cast_nullable_to_non_nullable
              as String,
      to_continue_accept_terms_condintion: null ==
              to_continue_accept_terms_condintion
          ? _value.to_continue_accept_terms_condintion
          : to_continue_accept_terms_condintion // ignore: cast_nullable_to_non_nullable
              as String,
      to_continue_give_your_signature: null == to_continue_give_your_signature
          ? _value.to_continue_give_your_signature
          : to_continue_give_your_signature // ignore: cast_nullable_to_non_nullable
              as String,
      register: null == register
          ? _value.register
          : register // ignore: cast_nullable_to_non_nullable
              as String,
      you_do_not_have_ac: null == you_do_not_have_ac
          ? _value.you_do_not_have_ac
          : you_do_not_have_ac // ignore: cast_nullable_to_non_nullable
              as String,
      create: null == create
          ? _value.create
          : create // ignore: cast_nullable_to_non_nullable
              as String,
      otp_successfully_send: null == otp_successfully_send
          ? _value.otp_successfully_send
          : otp_successfully_send // ignore: cast_nullable_to_non_nullable
              as String,
      otp_failed_send: null == otp_failed_send
          ? _value.otp_failed_send
          : otp_failed_send // ignore: cast_nullable_to_non_nullable
              as String,
      send_otp: null == send_otp
          ? _value.send_otp
          : send_otp // ignore: cast_nullable_to_non_nullable
              as String,
      do_not_have_ac: null == do_not_have_ac
          ? _value.do_not_have_ac
          : do_not_have_ac // ignore: cast_nullable_to_non_nullable
              as String,
      discount: null == discount
          ? _value.discount
          : discount // ignore: cast_nullable_to_non_nullable
              as String,
      your_info: null == your_info
          ? _value.your_info
          : your_info // ignore: cast_nullable_to_non_nullable
              as String,
      new_units: null == new_units
          ? _value.new_units
          : new_units // ignore: cast_nullable_to_non_nullable
              as String,
      booked: null == booked
          ? _value.booked
          : booked // ignore: cast_nullable_to_non_nullable
              as String,
      booked_sub: null == booked_sub
          ? _value.booked_sub
          : booked_sub // ignore: cast_nullable_to_non_nullable
              as String,
      delete_ac: null == delete_ac
          ? _value.delete_ac
          : delete_ac // ignore: cast_nullable_to_non_nullable
              as String,
      delete_ac_sub: null == delete_ac_sub
          ? _value.delete_ac_sub
          : delete_ac_sub // ignore: cast_nullable_to_non_nullable
              as String,
      optional: null == optional
          ? _value.optional
          : optional // ignore: cast_nullable_to_non_nullable
              as String,
      quote: null == quote
          ? _value.quote
          : quote // ignore: cast_nullable_to_non_nullable
              as String,
      request_quote: null == request_quote
          ? _value.request_quote
          : request_quote // ignore: cast_nullable_to_non_nullable
              as String,
      request_quote_sub: null == request_quote_sub
          ? _value.request_quote_sub
          : request_quote_sub // ignore: cast_nullable_to_non_nullable
              as String,
      choose_branch: null == choose_branch
          ? _value.choose_branch
          : choose_branch // ignore: cast_nullable_to_non_nullable
              as String,
      choose_area: null == choose_area
          ? _value.choose_area
          : choose_area // ignore: cast_nullable_to_non_nullable
              as String,
      receiving_method: null == receiving_method
          ? _value.receiving_method
          : receiving_method // ignore: cast_nullable_to_non_nullable
              as String,
      via_email: null == via_email
          ? _value.via_email
          : via_email // ignore: cast_nullable_to_non_nullable
              as String,
      download_pdf: null == download_pdf
          ? _value.download_pdf
          : download_pdf // ignore: cast_nullable_to_non_nullable
              as String,
      send_via_email: null == send_via_email
          ? _value.send_via_email
          : send_via_email // ignore: cast_nullable_to_non_nullable
              as String,
      message: null == message
          ? _value.message
          : message // ignore: cast_nullable_to_non_nullable
              as String,
      your_personal_info: null == your_personal_info
          ? _value.your_personal_info
          : your_personal_info // ignore: cast_nullable_to_non_nullable
              as String,
      nature_of_goods_stored: null == nature_of_goods_stored
          ? _value.nature_of_goods_stored
          : nature_of_goods_stored // ignore: cast_nullable_to_non_nullable
              as String,
      take_a_tour_with_makhzny: null == take_a_tour_with_makhzny
          ? _value.take_a_tour_with_makhzny
          : take_a_tour_with_makhzny // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$LangModelImpl implements _LangModel {
  const _$LangModelImpl(
      {required this.app_name,
      required this.search,
      required this.next,
      required this.login,
      required this.resend,
      required this.resend_in,
      required this.enter_your_phone_number,
      required this.enter_number,
      required this.welcome_to,
      required this.dont_miss_the_opportunity,
      required this.enter_otp_send,
      required this.otp,
      required this.my_storage,
      required this.store,
      required this.home,
      required this.gate_access,
      required this.settings,
      required this.welcome_frnd,
      required this.it_is_time_to_get_origanized,
      required this.we_have_place,
      required this.first_since,
      required this.rent_now,
      required this.trending_now,
      required this.last_booked,
      required this.add_to_cart,
      required this.to_able_to_view,
      required this.sign_in,
      required this.all,
      required this.self_storage,
      required this.others,
      required this.auto_renew,
      required this.total_number,
      required this.rented_items,
      required this.no_results_found,
      required this.try_to_use_other_filter,
      required this.continue_text,
      required this.cancel,
      required this.are_you_sure_renewal,
      required this.yes,
      required this.rental_option,
      required this.invoice_period,
      required this.invoice_period_sub,
      required this.quantity,
      required this.quantity_sub,
      required this.montly,
      required this.semi_annual,
      required this.annual,
      required this.quarterly,
      required this.add,
      required this.total,
      required this.storage_units,
      required this.general_items,
      required this.your_cart_is_empty,
      required this.lets_add_something,
      required this.my_cart,
      required this.clear_all_items,
      required this.add_ons,
      required this.total_amount,
      required this.vat,
      required this.payable_amount,
      required this.checkout,
      required this.are_you_sure_cart,
      required this.personal,
      required this.business,
      required this.open,
      required this.close,
      required this.access_code,
      required this.pls_enter_code,
      required this.profile,
      required this.languages,
      required this.appearance,
      required this.saved_payment_methods,
      required this.documents,
      required this.invoices,
      required this.paid,
      required this.unpaid,
      required this.rejected,
      required this.are_you_sure_delete_doc,
      required this.add_document,
      required this.upload_from_phone,
      required this.open_pdf_scanner,
      required this.light_mode,
      required this.light_mode_sub,
      required this.dark_mode,
      required this.dark_mode_sub,
      required this.auto_mode,
      required this.auto_mode_sub,
      required this.are_you_sure_card,
      required this.add_card,
      required this.card_nickname,
      required this.card_holder_name,
      required this.card_number,
      required this.cvv,
      required this.expiry_date,
      required this.invalid,
      required this.full_name,
      required this.id_number,
      required this.date_of_birth,
      required this.address,
      required this.mobile_number,
      required this.email,
      required this.please_ensure_info,
      required this.company_name,
      required this.cr_number,
      required this.vat_registration,
      required this.company_phone,
      required this.company_email,
      required this.auth_person_name,
      required this.auth_person_number,
      required this.attached_documents,
      required this.please_attach_required,
      required this.lets_add,
      required this.new_text,
      required this.select_doc_you_want,
      required this.done,
      required this.view_document,
      required this.version,
      required this.retry,
      required this.something_went_wrong,
      required this.jeddah,
      required this.dammam,
      required this.riyadh,
      required this.enter_full_name,
      required this.enter_id_number,
      required this.enter_dob,
      required this.enter_email,
      required this.enter_auth_name,
      required this.enter_auth_number,
      required this.enter_phone_number,
      required this.enter_vat_register,
      required this.enter_cr_number,
      required this.enter_address,
      required this.enter_otp_number,
      required this.otp_number,
      required this.invalid_email,
      required this.invalid_dob,
      required this.enter_company_name,
      required this.enter_company_phone,
      required this.enter_company_email,
      required this.rental_date,
      required this.rental_date_sub,
      required this.logout,
      required this.payment_method,
      required this.sadad_payment,
      required this.bank_tansfer,
      required this.card_payment,
      required this.select_payment_method,
      required this.upload,
      required this.termsOfServiceTitle,
      required this.termsOfServiceDescription,
      required this.agreeToTerms,
      required this.termsAndConditionsSub,
      required this.continue_checkbox,
      required this.yourSignature,
      required this.pleaseSignAbove,
      required this.clear,
      required this.to_continue_accept_terms_condintion,
      required this.to_continue_give_your_signature,
      required this.register,
      required this.you_do_not_have_ac,
      required this.create,
      required this.otp_successfully_send,
      required this.otp_failed_send,
      required this.send_otp,
      required this.do_not_have_ac,
      required this.discount,
      required this.your_info,
      required this.new_units,
      required this.booked,
      required this.booked_sub,
      required this.delete_ac,
      required this.delete_ac_sub,
      required this.optional,
      required this.quote,
      required this.request_quote,
      required this.request_quote_sub,
      required this.choose_branch,
      required this.choose_area,
      required this.receiving_method,
      required this.via_email,
      required this.download_pdf,
      required this.send_via_email,
      required this.message,
      required this.your_personal_info,
      required this.nature_of_goods_stored,
      required this.take_a_tour_with_makhzny});

  factory _$LangModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$LangModelImplFromJson(json);

  @override
  final String app_name;
  @override
  final String search;
  @override
  final String next;
  @override
  final String login;
  @override
  final String resend;
  @override
  final String resend_in;
  @override
  final String enter_your_phone_number;
  @override
  final String enter_number;
  @override
  final String welcome_to;
  @override
  final String dont_miss_the_opportunity;
  @override
  final String enter_otp_send;
  @override
  final String otp;
  @override
  final String my_storage;
  @override
  final String store;
  @override
  final String home;
  @override
  final String gate_access;
  @override
  final String settings;
  @override
  final String welcome_frnd;
  @override
  final String it_is_time_to_get_origanized;
  @override
  final String we_have_place;
  @override
  final String first_since;
  @override
  final String rent_now;
  @override
  final String trending_now;
  @override
  final String last_booked;
  @override
  final String add_to_cart;
  @override
  final String to_able_to_view;
  @override
  final String sign_in;
  @override
  final String all;
  @override
  final String self_storage;
  @override
  final String others;
  @override
  final String auto_renew;
  @override
  final String total_number;
  @override
  final String rented_items;
  @override
  final String no_results_found;
  @override
  final String try_to_use_other_filter;
  @override
  final String continue_text;
  @override
  final String cancel;
  @override
  final String are_you_sure_renewal;
  @override
  final String yes;
  @override
  final String rental_option;
  @override
  final String invoice_period;
  @override
  final String invoice_period_sub;
  @override
  final String quantity;
  @override
  final String quantity_sub;
  @override
  final String montly;
  @override
  final String semi_annual;
  @override
  final String annual;
  @override
  final String quarterly;
  @override
  final String add;
  @override
  final String total;
  @override
  final String storage_units;
  @override
  final String general_items;
  @override
  final String your_cart_is_empty;
  @override
  final String lets_add_something;
  @override
  final String my_cart;
  @override
  final String clear_all_items;
  @override
  final String add_ons;
  @override
  final String total_amount;
  @override
  final String vat;
  @override
  final String payable_amount;
  @override
  final String checkout;
  @override
  final String are_you_sure_cart;
  @override
  final String personal;
  @override
  final String business;
  @override
  final String open;
  @override
  final String close;
  @override
  final String access_code;
  @override
  final String pls_enter_code;
  @override
  final String profile;
  @override
  final String languages;
  @override
  final String appearance;
  @override
  final String saved_payment_methods;
  @override
  final String documents;
  @override
  final String invoices;
  @override
  final String paid;
  @override
  final String unpaid;
  @override
  final String rejected;
  @override
  final String are_you_sure_delete_doc;
  @override
  final String add_document;
  @override
  final String upload_from_phone;
  @override
  final String open_pdf_scanner;
  @override
  final String light_mode;
  @override
  final String light_mode_sub;
  @override
  final String dark_mode;
  @override
  final String dark_mode_sub;
  @override
  final String auto_mode;
  @override
  final String auto_mode_sub;
  @override
  final String are_you_sure_card;
  @override
  final String add_card;
  @override
  final String card_nickname;
  @override
  final String card_holder_name;
  @override
  final String card_number;
  @override
  final String cvv;
  @override
  final String expiry_date;
  @override
  final String invalid;
  @override
  final String full_name;
  @override
  final String id_number;
  @override
  final String date_of_birth;
  @override
  final String address;
  @override
  final String mobile_number;
  @override
  final String email;
  @override
  final String please_ensure_info;
  @override
  final String company_name;
  @override
  final String cr_number;
  @override
  final String vat_registration;
  @override
  final String company_phone;
  @override
  final String company_email;
  @override
  final String auth_person_name;
  @override
  final String auth_person_number;
  @override
  final String attached_documents;
  @override
  final String please_attach_required;
  @override
  final String lets_add;
  @override
  final String new_text;
  @override
  final String select_doc_you_want;
  @override
  final String done;
  @override
  final String view_document;
  @override
  final String version;
  @override
  final String retry;
  @override
  final String something_went_wrong;
  @override
  final String jeddah;
  @override
  final String dammam;
  @override
  final String riyadh;
  @override
  final String enter_full_name;
  @override
  final String enter_id_number;
  @override
  final String enter_dob;
  @override
  final String enter_email;
  @override
  final String enter_auth_name;
  @override
  final String enter_auth_number;
  @override
  final String enter_phone_number;
  @override
  final String enter_vat_register;
  @override
  final String enter_cr_number;
  @override
  final String enter_address;
  @override
  final String enter_otp_number;
  @override
  final String otp_number;
  @override
  final String invalid_email;
  @override
  final String invalid_dob;
  @override
  final String enter_company_name;
  @override
  final String enter_company_phone;
  @override
  final String enter_company_email;
  @override
  final String rental_date;
  @override
  final String rental_date_sub;
  @override
  final String logout;
  @override
  final String payment_method;
  @override
  final String sadad_payment;
  @override
  final String bank_tansfer;
  @override
  final String card_payment;
  @override
  final String select_payment_method;
  @override
  final String upload;
  @override
  final String termsOfServiceTitle;
  @override
  final String termsOfServiceDescription;
  @override
  final String agreeToTerms;
  @override
  final String termsAndConditionsSub;
  @override
  final String continue_checkbox;
  @override
  final String yourSignature;
  @override
  final String pleaseSignAbove;
  @override
  final String clear;
  @override
  final String to_continue_accept_terms_condintion;
  @override
  final String to_continue_give_your_signature;
  @override
  final String register;
  @override
  final String you_do_not_have_ac;
  @override
  final String create;
  @override
  final String otp_successfully_send;
  @override
  final String otp_failed_send;
  @override
  final String send_otp;
  @override
  final String do_not_have_ac;
  @override
  final String discount;
  @override
  final String your_info;
  @override
  final String new_units;
  @override
  final String booked;
  @override
  final String booked_sub;
  @override
  final String delete_ac;
  @override
  final String delete_ac_sub;
  @override
  final String optional;
  @override
  final String quote;
  @override
  final String request_quote;
  @override
  final String request_quote_sub;
  @override
  final String choose_branch;
  @override
  final String choose_area;
  @override
  final String receiving_method;
  @override
  final String via_email;
  @override
  final String download_pdf;
  @override
  final String send_via_email;
  @override
  final String message;
  @override
  final String your_personal_info;
  @override
  final String nature_of_goods_stored;
  @override
  final String take_a_tour_with_makhzny;

  @override
  String toString() {
    return 'LangModel(app_name: $app_name, search: $search, next: $next, login: $login, resend: $resend, resend_in: $resend_in, enter_your_phone_number: $enter_your_phone_number, enter_number: $enter_number, welcome_to: $welcome_to, dont_miss_the_opportunity: $dont_miss_the_opportunity, enter_otp_send: $enter_otp_send, otp: $otp, my_storage: $my_storage, store: $store, home: $home, gate_access: $gate_access, settings: $settings, welcome_frnd: $welcome_frnd, it_is_time_to_get_origanized: $it_is_time_to_get_origanized, we_have_place: $we_have_place, first_since: $first_since, rent_now: $rent_now, trending_now: $trending_now, last_booked: $last_booked, add_to_cart: $add_to_cart, to_able_to_view: $to_able_to_view, sign_in: $sign_in, all: $all, self_storage: $self_storage, others: $others, auto_renew: $auto_renew, total_number: $total_number, rented_items: $rented_items, no_results_found: $no_results_found, try_to_use_other_filter: $try_to_use_other_filter, continue_text: $continue_text, cancel: $cancel, are_you_sure_renewal: $are_you_sure_renewal, yes: $yes, rental_option: $rental_option, invoice_period: $invoice_period, invoice_period_sub: $invoice_period_sub, quantity: $quantity, quantity_sub: $quantity_sub, montly: $montly, semi_annual: $semi_annual, annual: $annual, quarterly: $quarterly, add: $add, total: $total, storage_units: $storage_units, general_items: $general_items, your_cart_is_empty: $your_cart_is_empty, lets_add_something: $lets_add_something, my_cart: $my_cart, clear_all_items: $clear_all_items, add_ons: $add_ons, total_amount: $total_amount, vat: $vat, payable_amount: $payable_amount, checkout: $checkout, are_you_sure_cart: $are_you_sure_cart, personal: $personal, business: $business, open: $open, close: $close, access_code: $access_code, pls_enter_code: $pls_enter_code, profile: $profile, languages: $languages, appearance: $appearance, saved_payment_methods: $saved_payment_methods, documents: $documents, invoices: $invoices, paid: $paid, unpaid: $unpaid, rejected: $rejected, are_you_sure_delete_doc: $are_you_sure_delete_doc, add_document: $add_document, upload_from_phone: $upload_from_phone, open_pdf_scanner: $open_pdf_scanner, light_mode: $light_mode, light_mode_sub: $light_mode_sub, dark_mode: $dark_mode, dark_mode_sub: $dark_mode_sub, auto_mode: $auto_mode, auto_mode_sub: $auto_mode_sub, are_you_sure_card: $are_you_sure_card, add_card: $add_card, card_nickname: $card_nickname, card_holder_name: $card_holder_name, card_number: $card_number, cvv: $cvv, expiry_date: $expiry_date, invalid: $invalid, full_name: $full_name, id_number: $id_number, date_of_birth: $date_of_birth, address: $address, mobile_number: $mobile_number, email: $email, please_ensure_info: $please_ensure_info, company_name: $company_name, cr_number: $cr_number, vat_registration: $vat_registration, company_phone: $company_phone, company_email: $company_email, auth_person_name: $auth_person_name, auth_person_number: $auth_person_number, attached_documents: $attached_documents, please_attach_required: $please_attach_required, lets_add: $lets_add, new_text: $new_text, select_doc_you_want: $select_doc_you_want, done: $done, view_document: $view_document, version: $version, retry: $retry, something_went_wrong: $something_went_wrong, jeddah: $jeddah, dammam: $dammam, riyadh: $riyadh, enter_full_name: $enter_full_name, enter_id_number: $enter_id_number, enter_dob: $enter_dob, enter_email: $enter_email, enter_auth_name: $enter_auth_name, enter_auth_number: $enter_auth_number, enter_phone_number: $enter_phone_number, enter_vat_register: $enter_vat_register, enter_cr_number: $enter_cr_number, enter_address: $enter_address, enter_otp_number: $enter_otp_number, otp_number: $otp_number, invalid_email: $invalid_email, invalid_dob: $invalid_dob, enter_company_name: $enter_company_name, enter_company_phone: $enter_company_phone, enter_company_email: $enter_company_email, rental_date: $rental_date, rental_date_sub: $rental_date_sub, logout: $logout, payment_method: $payment_method, sadad_payment: $sadad_payment, bank_tansfer: $bank_tansfer, card_payment: $card_payment, select_payment_method: $select_payment_method, upload: $upload, termsOfServiceTitle: $termsOfServiceTitle, termsOfServiceDescription: $termsOfServiceDescription, agreeToTerms: $agreeToTerms, termsAndConditionsSub: $termsAndConditionsSub, continue_checkbox: $continue_checkbox, yourSignature: $yourSignature, pleaseSignAbove: $pleaseSignAbove, clear: $clear, to_continue_accept_terms_condintion: $to_continue_accept_terms_condintion, to_continue_give_your_signature: $to_continue_give_your_signature, register: $register, you_do_not_have_ac: $you_do_not_have_ac, create: $create, otp_successfully_send: $otp_successfully_send, otp_failed_send: $otp_failed_send, send_otp: $send_otp, do_not_have_ac: $do_not_have_ac, discount: $discount, your_info: $your_info, new_units: $new_units, booked: $booked, booked_sub: $booked_sub, delete_ac: $delete_ac, delete_ac_sub: $delete_ac_sub, optional: $optional, quote: $quote, request_quote: $request_quote, request_quote_sub: $request_quote_sub, choose_branch: $choose_branch, choose_area: $choose_area, receiving_method: $receiving_method, via_email: $via_email, download_pdf: $download_pdf, send_via_email: $send_via_email, message: $message, your_personal_info: $your_personal_info, nature_of_goods_stored: $nature_of_goods_stored, take_a_tour_with_makhzny: $take_a_tour_with_makhzny)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$LangModelImpl &&
            (identical(other.app_name, app_name) ||
                other.app_name == app_name) &&
            (identical(other.search, search) || other.search == search) &&
            (identical(other.next, next) || other.next == next) &&
            (identical(other.login, login) || other.login == login) &&
            (identical(other.resend, resend) || other.resend == resend) &&
            (identical(other.resend_in, resend_in) ||
                other.resend_in == resend_in) &&
            (identical(other.enter_your_phone_number, enter_your_phone_number) ||
                other.enter_your_phone_number == enter_your_phone_number) &&
            (identical(other.enter_number, enter_number) ||
                other.enter_number == enter_number) &&
            (identical(other.welcome_to, welcome_to) ||
                other.welcome_to == welcome_to) &&
            (identical(other.dont_miss_the_opportunity, dont_miss_the_opportunity) ||
                other.dont_miss_the_opportunity == dont_miss_the_opportunity) &&
            (identical(other.enter_otp_send, enter_otp_send) ||
                other.enter_otp_send == enter_otp_send) &&
            (identical(other.otp, otp) || other.otp == otp) &&
            (identical(other.my_storage, my_storage) ||
                other.my_storage == my_storage) &&
            (identical(other.store, store) || other.store == store) &&
            (identical(other.home, home) || other.home == home) &&
            (identical(other.gate_access, gate_access) ||
                other.gate_access == gate_access) &&
            (identical(other.settings, settings) ||
                other.settings == settings) &&
            (identical(other.welcome_frnd, welcome_frnd) ||
                other.welcome_frnd == welcome_frnd) &&
            (identical(other.it_is_time_to_get_origanized, it_is_time_to_get_origanized) ||
                other.it_is_time_to_get_origanized ==
                    it_is_time_to_get_origanized) &&
            (identical(other.we_have_place, we_have_place) ||
                other.we_have_place == we_have_place) &&
            (identical(other.first_since, first_since) ||
                other.first_since == first_since) &&
            (identical(other.rent_now, rent_now) ||
                other.rent_now == rent_now) &&
            (identical(other.trending_now, trending_now) ||
                other.trending_now == trending_now) &&
            (identical(other.last_booked, last_booked) ||
                other.last_booked == last_booked) &&
            (identical(other.add_to_cart, add_to_cart) ||
                other.add_to_cart == add_to_cart) &&
            (identical(other.to_able_to_view, to_able_to_view) ||
                other.to_able_to_view == to_able_to_view) &&
            (identical(other.sign_in, sign_in) || other.sign_in == sign_in) &&
            (identical(other.all, all) || other.all == all) &&
            (identical(other.self_storage, self_storage) ||
                other.self_storage == self_storage) &&
            (identical(other.others, others) || other.others == others) &&
            (identical(other.auto_renew, auto_renew) ||
                other.auto_renew == auto_renew) &&
            (identical(other.total_number, total_number) ||
                other.total_number == total_number) &&
            (identical(other.rented_items, rented_items) ||
                other.rented_items == rented_items) &&
            (identical(other.no_results_found, no_results_found) ||
                other.no_results_found == no_results_found) &&
            (identical(other.try_to_use_other_filter, try_to_use_other_filter) ||
                other.try_to_use_other_filter == try_to_use_other_filter) &&
            (identical(other.continue_text, continue_text) || other.continue_text == continue_text) &&
            (identical(other.cancel, cancel) || other.cancel == cancel) &&
            (identical(other.are_you_sure_renewal, are_you_sure_renewal) || other.are_you_sure_renewal == are_you_sure_renewal) &&
            (identical(other.yes, yes) || other.yes == yes) &&
            (identical(other.rental_option, rental_option) || other.rental_option == rental_option) &&
            (identical(other.invoice_period, invoice_period) || other.invoice_period == invoice_period) &&
            (identical(other.invoice_period_sub, invoice_period_sub) || other.invoice_period_sub == invoice_period_sub) &&
            (identical(other.quantity, quantity) || other.quantity == quantity) &&
            (identical(other.quantity_sub, quantity_sub) || other.quantity_sub == quantity_sub) &&
            (identical(other.montly, montly) || other.montly == montly) &&
            (identical(other.semi_annual, semi_annual) || other.semi_annual == semi_annual) &&
            (identical(other.annual, annual) || other.annual == annual) &&
            (identical(other.quarterly, quarterly) || other.quarterly == quarterly) &&
            (identical(other.add, add) || other.add == add) &&
            (identical(other.total, total) || other.total == total) &&
            (identical(other.storage_units, storage_units) || other.storage_units == storage_units) &&
            (identical(other.general_items, general_items) || other.general_items == general_items) &&
            (identical(other.your_cart_is_empty, your_cart_is_empty) || other.your_cart_is_empty == your_cart_is_empty) &&
            (identical(other.lets_add_something, lets_add_something) || other.lets_add_something == lets_add_something) &&
            (identical(other.my_cart, my_cart) || other.my_cart == my_cart) &&
            (identical(other.clear_all_items, clear_all_items) || other.clear_all_items == clear_all_items) &&
            (identical(other.add_ons, add_ons) || other.add_ons == add_ons) &&
            (identical(other.total_amount, total_amount) || other.total_amount == total_amount) &&
            (identical(other.vat, vat) || other.vat == vat) &&
            (identical(other.payable_amount, payable_amount) || other.payable_amount == payable_amount) &&
            (identical(other.checkout, checkout) || other.checkout == checkout) &&
            (identical(other.are_you_sure_cart, are_you_sure_cart) || other.are_you_sure_cart == are_you_sure_cart) &&
            (identical(other.personal, personal) || other.personal == personal) &&
            (identical(other.business, business) || other.business == business) &&
            (identical(other.open, open) || other.open == open) &&
            (identical(other.close, close) || other.close == close) &&
            (identical(other.access_code, access_code) || other.access_code == access_code) &&
            (identical(other.pls_enter_code, pls_enter_code) || other.pls_enter_code == pls_enter_code) &&
            (identical(other.profile, profile) || other.profile == profile) &&
            (identical(other.languages, languages) || other.languages == languages) &&
            (identical(other.appearance, appearance) || other.appearance == appearance) &&
            (identical(other.saved_payment_methods, saved_payment_methods) || other.saved_payment_methods == saved_payment_methods) &&
            (identical(other.documents, documents) || other.documents == documents) &&
            (identical(other.invoices, invoices) || other.invoices == invoices) &&
            (identical(other.paid, paid) || other.paid == paid) &&
            (identical(other.unpaid, unpaid) || other.unpaid == unpaid) &&
            (identical(other.rejected, rejected) || other.rejected == rejected) &&
            (identical(other.are_you_sure_delete_doc, are_you_sure_delete_doc) || other.are_you_sure_delete_doc == are_you_sure_delete_doc) &&
            (identical(other.add_document, add_document) || other.add_document == add_document) &&
            (identical(other.upload_from_phone, upload_from_phone) || other.upload_from_phone == upload_from_phone) &&
            (identical(other.open_pdf_scanner, open_pdf_scanner) || other.open_pdf_scanner == open_pdf_scanner) &&
            (identical(other.light_mode, light_mode) || other.light_mode == light_mode) &&
            (identical(other.light_mode_sub, light_mode_sub) || other.light_mode_sub == light_mode_sub) &&
            (identical(other.dark_mode, dark_mode) || other.dark_mode == dark_mode) &&
            (identical(other.dark_mode_sub, dark_mode_sub) || other.dark_mode_sub == dark_mode_sub) &&
            (identical(other.auto_mode, auto_mode) || other.auto_mode == auto_mode) &&
            (identical(other.auto_mode_sub, auto_mode_sub) || other.auto_mode_sub == auto_mode_sub) &&
            (identical(other.are_you_sure_card, are_you_sure_card) || other.are_you_sure_card == are_you_sure_card) &&
            (identical(other.add_card, add_card) || other.add_card == add_card) &&
            (identical(other.card_nickname, card_nickname) || other.card_nickname == card_nickname) &&
            (identical(other.card_holder_name, card_holder_name) || other.card_holder_name == card_holder_name) &&
            (identical(other.card_number, card_number) || other.card_number == card_number) &&
            (identical(other.cvv, cvv) || other.cvv == cvv) &&
            (identical(other.expiry_date, expiry_date) || other.expiry_date == expiry_date) &&
            (identical(other.invalid, invalid) || other.invalid == invalid) &&
            (identical(other.full_name, full_name) || other.full_name == full_name) &&
            (identical(other.id_number, id_number) || other.id_number == id_number) &&
            (identical(other.date_of_birth, date_of_birth) || other.date_of_birth == date_of_birth) &&
            (identical(other.address, address) || other.address == address) &&
            (identical(other.mobile_number, mobile_number) || other.mobile_number == mobile_number) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.please_ensure_info, please_ensure_info) || other.please_ensure_info == please_ensure_info) &&
            (identical(other.company_name, company_name) || other.company_name == company_name) &&
            (identical(other.cr_number, cr_number) || other.cr_number == cr_number) &&
            (identical(other.vat_registration, vat_registration) || other.vat_registration == vat_registration) &&
            (identical(other.company_phone, company_phone) || other.company_phone == company_phone) &&
            (identical(other.company_email, company_email) || other.company_email == company_email) &&
            (identical(other.auth_person_name, auth_person_name) || other.auth_person_name == auth_person_name) &&
            (identical(other.auth_person_number, auth_person_number) || other.auth_person_number == auth_person_number) &&
            (identical(other.attached_documents, attached_documents) || other.attached_documents == attached_documents) &&
            (identical(other.please_attach_required, please_attach_required) || other.please_attach_required == please_attach_required) &&
            (identical(other.lets_add, lets_add) || other.lets_add == lets_add) &&
            (identical(other.new_text, new_text) || other.new_text == new_text) &&
            (identical(other.select_doc_you_want, select_doc_you_want) || other.select_doc_you_want == select_doc_you_want) &&
            (identical(other.done, done) || other.done == done) &&
            (identical(other.view_document, view_document) || other.view_document == view_document) &&
            (identical(other.version, version) || other.version == version) &&
            (identical(other.retry, retry) || other.retry == retry) &&
            (identical(other.something_went_wrong, something_went_wrong) || other.something_went_wrong == something_went_wrong) &&
            (identical(other.jeddah, jeddah) || other.jeddah == jeddah) &&
            (identical(other.dammam, dammam) || other.dammam == dammam) &&
            (identical(other.riyadh, riyadh) || other.riyadh == riyadh) &&
            (identical(other.enter_full_name, enter_full_name) || other.enter_full_name == enter_full_name) &&
            (identical(other.enter_id_number, enter_id_number) || other.enter_id_number == enter_id_number) &&
            (identical(other.enter_dob, enter_dob) || other.enter_dob == enter_dob) &&
            (identical(other.enter_email, enter_email) || other.enter_email == enter_email) &&
            (identical(other.enter_auth_name, enter_auth_name) || other.enter_auth_name == enter_auth_name) &&
            (identical(other.enter_auth_number, enter_auth_number) || other.enter_auth_number == enter_auth_number) &&
            (identical(other.enter_phone_number, enter_phone_number) || other.enter_phone_number == enter_phone_number) &&
            (identical(other.enter_vat_register, enter_vat_register) || other.enter_vat_register == enter_vat_register) &&
            (identical(other.enter_cr_number, enter_cr_number) || other.enter_cr_number == enter_cr_number) &&
            (identical(other.enter_address, enter_address) || other.enter_address == enter_address) &&
            (identical(other.enter_otp_number, enter_otp_number) || other.enter_otp_number == enter_otp_number) &&
            (identical(other.otp_number, otp_number) || other.otp_number == otp_number) &&
            (identical(other.invalid_email, invalid_email) || other.invalid_email == invalid_email) &&
            (identical(other.invalid_dob, invalid_dob) || other.invalid_dob == invalid_dob) &&
            (identical(other.enter_company_name, enter_company_name) || other.enter_company_name == enter_company_name) &&
            (identical(other.enter_company_phone, enter_company_phone) || other.enter_company_phone == enter_company_phone) &&
            (identical(other.enter_company_email, enter_company_email) || other.enter_company_email == enter_company_email) &&
            (identical(other.rental_date, rental_date) || other.rental_date == rental_date) &&
            (identical(other.rental_date_sub, rental_date_sub) || other.rental_date_sub == rental_date_sub) &&
            (identical(other.logout, logout) || other.logout == logout) &&
            (identical(other.payment_method, payment_method) || other.payment_method == payment_method) &&
            (identical(other.sadad_payment, sadad_payment) || other.sadad_payment == sadad_payment) &&
            (identical(other.bank_tansfer, bank_tansfer) || other.bank_tansfer == bank_tansfer) &&
            (identical(other.card_payment, card_payment) || other.card_payment == card_payment) &&
            (identical(other.select_payment_method, select_payment_method) || other.select_payment_method == select_payment_method) &&
            (identical(other.upload, upload) || other.upload == upload) &&
            (identical(other.termsOfServiceTitle, termsOfServiceTitle) || other.termsOfServiceTitle == termsOfServiceTitle) &&
            (identical(other.termsOfServiceDescription, termsOfServiceDescription) || other.termsOfServiceDescription == termsOfServiceDescription) &&
            (identical(other.agreeToTerms, agreeToTerms) || other.agreeToTerms == agreeToTerms) &&
            (identical(other.termsAndConditionsSub, termsAndConditionsSub) || other.termsAndConditionsSub == termsAndConditionsSub) &&
            (identical(other.continue_checkbox, continue_checkbox) || other.continue_checkbox == continue_checkbox) &&
            (identical(other.yourSignature, yourSignature) || other.yourSignature == yourSignature) &&
            (identical(other.pleaseSignAbove, pleaseSignAbove) || other.pleaseSignAbove == pleaseSignAbove) &&
            (identical(other.clear, clear) || other.clear == clear) &&
            (identical(other.to_continue_accept_terms_condintion, to_continue_accept_terms_condintion) || other.to_continue_accept_terms_condintion == to_continue_accept_terms_condintion) &&
            (identical(other.to_continue_give_your_signature, to_continue_give_your_signature) || other.to_continue_give_your_signature == to_continue_give_your_signature) &&
            (identical(other.register, register) || other.register == register) &&
            (identical(other.you_do_not_have_ac, you_do_not_have_ac) || other.you_do_not_have_ac == you_do_not_have_ac) &&
            (identical(other.create, create) || other.create == create) &&
            (identical(other.otp_successfully_send, otp_successfully_send) || other.otp_successfully_send == otp_successfully_send) &&
            (identical(other.otp_failed_send, otp_failed_send) || other.otp_failed_send == otp_failed_send) &&
            (identical(other.send_otp, send_otp) || other.send_otp == send_otp) &&
            (identical(other.do_not_have_ac, do_not_have_ac) || other.do_not_have_ac == do_not_have_ac) &&
            (identical(other.discount, discount) || other.discount == discount) &&
            (identical(other.your_info, your_info) || other.your_info == your_info) &&
            (identical(other.new_units, new_units) || other.new_units == new_units) &&
            (identical(other.booked, booked) || other.booked == booked) &&
            (identical(other.booked_sub, booked_sub) || other.booked_sub == booked_sub) &&
            (identical(other.delete_ac, delete_ac) || other.delete_ac == delete_ac) &&
            (identical(other.delete_ac_sub, delete_ac_sub) || other.delete_ac_sub == delete_ac_sub) &&
            (identical(other.optional, optional) || other.optional == optional) &&
            (identical(other.quote, quote) || other.quote == quote) &&
            (identical(other.request_quote, request_quote) || other.request_quote == request_quote) &&
            (identical(other.request_quote_sub, request_quote_sub) || other.request_quote_sub == request_quote_sub) &&
            (identical(other.choose_branch, choose_branch) || other.choose_branch == choose_branch) &&
            (identical(other.choose_area, choose_area) || other.choose_area == choose_area) &&
            (identical(other.receiving_method, receiving_method) || other.receiving_method == receiving_method) &&
            (identical(other.via_email, via_email) || other.via_email == via_email) &&
            (identical(other.download_pdf, download_pdf) || other.download_pdf == download_pdf) &&
            (identical(other.send_via_email, send_via_email) || other.send_via_email == send_via_email) &&
            (identical(other.message, message) || other.message == message) &&
            (identical(other.your_personal_info, your_personal_info) || other.your_personal_info == your_personal_info) &&
            (identical(other.nature_of_goods_stored, nature_of_goods_stored) || other.nature_of_goods_stored == nature_of_goods_stored) &&
            (identical(other.take_a_tour_with_makhzny, take_a_tour_with_makhzny) || other.take_a_tour_with_makhzny == take_a_tour_with_makhzny));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        app_name,
        search,
        next,
        login,
        resend,
        resend_in,
        enter_your_phone_number,
        enter_number,
        welcome_to,
        dont_miss_the_opportunity,
        enter_otp_send,
        otp,
        my_storage,
        store,
        home,
        gate_access,
        settings,
        welcome_frnd,
        it_is_time_to_get_origanized,
        we_have_place,
        first_since,
        rent_now,
        trending_now,
        last_booked,
        add_to_cart,
        to_able_to_view,
        sign_in,
        all,
        self_storage,
        others,
        auto_renew,
        total_number,
        rented_items,
        no_results_found,
        try_to_use_other_filter,
        continue_text,
        cancel,
        are_you_sure_renewal,
        yes,
        rental_option,
        invoice_period,
        invoice_period_sub,
        quantity,
        quantity_sub,
        montly,
        semi_annual,
        annual,
        quarterly,
        add,
        total,
        storage_units,
        general_items,
        your_cart_is_empty,
        lets_add_something,
        my_cart,
        clear_all_items,
        add_ons,
        total_amount,
        vat,
        payable_amount,
        checkout,
        are_you_sure_cart,
        personal,
        business,
        open,
        close,
        access_code,
        pls_enter_code,
        profile,
        languages,
        appearance,
        saved_payment_methods,
        documents,
        invoices,
        paid,
        unpaid,
        rejected,
        are_you_sure_delete_doc,
        add_document,
        upload_from_phone,
        open_pdf_scanner,
        light_mode,
        light_mode_sub,
        dark_mode,
        dark_mode_sub,
        auto_mode,
        auto_mode_sub,
        are_you_sure_card,
        add_card,
        card_nickname,
        card_holder_name,
        card_number,
        cvv,
        expiry_date,
        invalid,
        full_name,
        id_number,
        date_of_birth,
        address,
        mobile_number,
        email,
        please_ensure_info,
        company_name,
        cr_number,
        vat_registration,
        company_phone,
        company_email,
        auth_person_name,
        auth_person_number,
        attached_documents,
        please_attach_required,
        lets_add,
        new_text,
        select_doc_you_want,
        done,
        view_document,
        version,
        retry,
        something_went_wrong,
        jeddah,
        dammam,
        riyadh,
        enter_full_name,
        enter_id_number,
        enter_dob,
        enter_email,
        enter_auth_name,
        enter_auth_number,
        enter_phone_number,
        enter_vat_register,
        enter_cr_number,
        enter_address,
        enter_otp_number,
        otp_number,
        invalid_email,
        invalid_dob,
        enter_company_name,
        enter_company_phone,
        enter_company_email,
        rental_date,
        rental_date_sub,
        logout,
        payment_method,
        sadad_payment,
        bank_tansfer,
        card_payment,
        select_payment_method,
        upload,
        termsOfServiceTitle,
        termsOfServiceDescription,
        agreeToTerms,
        termsAndConditionsSub,
        continue_checkbox,
        yourSignature,
        pleaseSignAbove,
        clear,
        to_continue_accept_terms_condintion,
        to_continue_give_your_signature,
        register,
        you_do_not_have_ac,
        create,
        otp_successfully_send,
        otp_failed_send,
        send_otp,
        do_not_have_ac,
        discount,
        your_info,
        new_units,
        booked,
        booked_sub,
        delete_ac,
        delete_ac_sub,
        optional,
        quote,
        request_quote,
        request_quote_sub,
        choose_branch,
        choose_area,
        receiving_method,
        via_email,
        download_pdf,
        send_via_email,
        message,
        your_personal_info,
        nature_of_goods_stored,
        take_a_tour_with_makhzny
      ]);

  /// Create a copy of LangModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$LangModelImplCopyWith<_$LangModelImpl> get copyWith =>
      __$$LangModelImplCopyWithImpl<_$LangModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$LangModelImplToJson(
      this,
    );
  }
}

abstract class _LangModel implements LangModel {
  const factory _LangModel(
      {required final String app_name,
      required final String search,
      required final String next,
      required final String login,
      required final String resend,
      required final String resend_in,
      required final String enter_your_phone_number,
      required final String enter_number,
      required final String welcome_to,
      required final String dont_miss_the_opportunity,
      required final String enter_otp_send,
      required final String otp,
      required final String my_storage,
      required final String store,
      required final String home,
      required final String gate_access,
      required final String settings,
      required final String welcome_frnd,
      required final String it_is_time_to_get_origanized,
      required final String we_have_place,
      required final String first_since,
      required final String rent_now,
      required final String trending_now,
      required final String last_booked,
      required final String add_to_cart,
      required final String to_able_to_view,
      required final String sign_in,
      required final String all,
      required final String self_storage,
      required final String others,
      required final String auto_renew,
      required final String total_number,
      required final String rented_items,
      required final String no_results_found,
      required final String try_to_use_other_filter,
      required final String continue_text,
      required final String cancel,
      required final String are_you_sure_renewal,
      required final String yes,
      required final String rental_option,
      required final String invoice_period,
      required final String invoice_period_sub,
      required final String quantity,
      required final String quantity_sub,
      required final String montly,
      required final String semi_annual,
      required final String annual,
      required final String quarterly,
      required final String add,
      required final String total,
      required final String storage_units,
      required final String general_items,
      required final String your_cart_is_empty,
      required final String lets_add_something,
      required final String my_cart,
      required final String clear_all_items,
      required final String add_ons,
      required final String total_amount,
      required final String vat,
      required final String payable_amount,
      required final String checkout,
      required final String are_you_sure_cart,
      required final String personal,
      required final String business,
      required final String open,
      required final String close,
      required final String access_code,
      required final String pls_enter_code,
      required final String profile,
      required final String languages,
      required final String appearance,
      required final String saved_payment_methods,
      required final String documents,
      required final String invoices,
      required final String paid,
      required final String unpaid,
      required final String rejected,
      required final String are_you_sure_delete_doc,
      required final String add_document,
      required final String upload_from_phone,
      required final String open_pdf_scanner,
      required final String light_mode,
      required final String light_mode_sub,
      required final String dark_mode,
      required final String dark_mode_sub,
      required final String auto_mode,
      required final String auto_mode_sub,
      required final String are_you_sure_card,
      required final String add_card,
      required final String card_nickname,
      required final String card_holder_name,
      required final String card_number,
      required final String cvv,
      required final String expiry_date,
      required final String invalid,
      required final String full_name,
      required final String id_number,
      required final String date_of_birth,
      required final String address,
      required final String mobile_number,
      required final String email,
      required final String please_ensure_info,
      required final String company_name,
      required final String cr_number,
      required final String vat_registration,
      required final String company_phone,
      required final String company_email,
      required final String auth_person_name,
      required final String auth_person_number,
      required final String attached_documents,
      required final String please_attach_required,
      required final String lets_add,
      required final String new_text,
      required final String select_doc_you_want,
      required final String done,
      required final String view_document,
      required final String version,
      required final String retry,
      required final String something_went_wrong,
      required final String jeddah,
      required final String dammam,
      required final String riyadh,
      required final String enter_full_name,
      required final String enter_id_number,
      required final String enter_dob,
      required final String enter_email,
      required final String enter_auth_name,
      required final String enter_auth_number,
      required final String enter_phone_number,
      required final String enter_vat_register,
      required final String enter_cr_number,
      required final String enter_address,
      required final String enter_otp_number,
      required final String otp_number,
      required final String invalid_email,
      required final String invalid_dob,
      required final String enter_company_name,
      required final String enter_company_phone,
      required final String enter_company_email,
      required final String rental_date,
      required final String rental_date_sub,
      required final String logout,
      required final String payment_method,
      required final String sadad_payment,
      required final String bank_tansfer,
      required final String card_payment,
      required final String select_payment_method,
      required final String upload,
      required final String termsOfServiceTitle,
      required final String termsOfServiceDescription,
      required final String agreeToTerms,
      required final String termsAndConditionsSub,
      required final String continue_checkbox,
      required final String yourSignature,
      required final String pleaseSignAbove,
      required final String clear,
      required final String to_continue_accept_terms_condintion,
      required final String to_continue_give_your_signature,
      required final String register,
      required final String you_do_not_have_ac,
      required final String create,
      required final String otp_successfully_send,
      required final String otp_failed_send,
      required final String send_otp,
      required final String do_not_have_ac,
      required final String discount,
      required final String your_info,
      required final String new_units,
      required final String booked,
      required final String booked_sub,
      required final String delete_ac,
      required final String delete_ac_sub,
      required final String optional,
      required final String quote,
      required final String request_quote,
      required final String request_quote_sub,
      required final String choose_branch,
      required final String choose_area,
      required final String receiving_method,
      required final String via_email,
      required final String download_pdf,
      required final String send_via_email,
      required final String message,
      required final String your_personal_info,
      required final String nature_of_goods_stored,
      required final String take_a_tour_with_makhzny}) = _$LangModelImpl;

  factory _LangModel.fromJson(Map<String, dynamic> json) =
      _$LangModelImpl.fromJson;

  @override
  String get app_name;
  @override
  String get search;
  @override
  String get next;
  @override
  String get login;
  @override
  String get resend;
  @override
  String get resend_in;
  @override
  String get enter_your_phone_number;
  @override
  String get enter_number;
  @override
  String get welcome_to;
  @override
  String get dont_miss_the_opportunity;
  @override
  String get enter_otp_send;
  @override
  String get otp;
  @override
  String get my_storage;
  @override
  String get store;
  @override
  String get home;
  @override
  String get gate_access;
  @override
  String get settings;
  @override
  String get welcome_frnd;
  @override
  String get it_is_time_to_get_origanized;
  @override
  String get we_have_place;
  @override
  String get first_since;
  @override
  String get rent_now;
  @override
  String get trending_now;
  @override
  String get last_booked;
  @override
  String get add_to_cart;
  @override
  String get to_able_to_view;
  @override
  String get sign_in;
  @override
  String get all;
  @override
  String get self_storage;
  @override
  String get others;
  @override
  String get auto_renew;
  @override
  String get total_number;
  @override
  String get rented_items;
  @override
  String get no_results_found;
  @override
  String get try_to_use_other_filter;
  @override
  String get continue_text;
  @override
  String get cancel;
  @override
  String get are_you_sure_renewal;
  @override
  String get yes;
  @override
  String get rental_option;
  @override
  String get invoice_period;
  @override
  String get invoice_period_sub;
  @override
  String get quantity;
  @override
  String get quantity_sub;
  @override
  String get montly;
  @override
  String get semi_annual;
  @override
  String get annual;
  @override
  String get quarterly;
  @override
  String get add;
  @override
  String get total;
  @override
  String get storage_units;
  @override
  String get general_items;
  @override
  String get your_cart_is_empty;
  @override
  String get lets_add_something;
  @override
  String get my_cart;
  @override
  String get clear_all_items;
  @override
  String get add_ons;
  @override
  String get total_amount;
  @override
  String get vat;
  @override
  String get payable_amount;
  @override
  String get checkout;
  @override
  String get are_you_sure_cart;
  @override
  String get personal;
  @override
  String get business;
  @override
  String get open;
  @override
  String get close;
  @override
  String get access_code;
  @override
  String get pls_enter_code;
  @override
  String get profile;
  @override
  String get languages;
  @override
  String get appearance;
  @override
  String get saved_payment_methods;
  @override
  String get documents;
  @override
  String get invoices;
  @override
  String get paid;
  @override
  String get unpaid;
  @override
  String get rejected;
  @override
  String get are_you_sure_delete_doc;
  @override
  String get add_document;
  @override
  String get upload_from_phone;
  @override
  String get open_pdf_scanner;
  @override
  String get light_mode;
  @override
  String get light_mode_sub;
  @override
  String get dark_mode;
  @override
  String get dark_mode_sub;
  @override
  String get auto_mode;
  @override
  String get auto_mode_sub;
  @override
  String get are_you_sure_card;
  @override
  String get add_card;
  @override
  String get card_nickname;
  @override
  String get card_holder_name;
  @override
  String get card_number;
  @override
  String get cvv;
  @override
  String get expiry_date;
  @override
  String get invalid;
  @override
  String get full_name;
  @override
  String get id_number;
  @override
  String get date_of_birth;
  @override
  String get address;
  @override
  String get mobile_number;
  @override
  String get email;
  @override
  String get please_ensure_info;
  @override
  String get company_name;
  @override
  String get cr_number;
  @override
  String get vat_registration;
  @override
  String get company_phone;
  @override
  String get company_email;
  @override
  String get auth_person_name;
  @override
  String get auth_person_number;
  @override
  String get attached_documents;
  @override
  String get please_attach_required;
  @override
  String get lets_add;
  @override
  String get new_text;
  @override
  String get select_doc_you_want;
  @override
  String get done;
  @override
  String get view_document;
  @override
  String get version;
  @override
  String get retry;
  @override
  String get something_went_wrong;
  @override
  String get jeddah;
  @override
  String get dammam;
  @override
  String get riyadh;
  @override
  String get enter_full_name;
  @override
  String get enter_id_number;
  @override
  String get enter_dob;
  @override
  String get enter_email;
  @override
  String get enter_auth_name;
  @override
  String get enter_auth_number;
  @override
  String get enter_phone_number;
  @override
  String get enter_vat_register;
  @override
  String get enter_cr_number;
  @override
  String get enter_address;
  @override
  String get enter_otp_number;
  @override
  String get otp_number;
  @override
  String get invalid_email;
  @override
  String get invalid_dob;
  @override
  String get enter_company_name;
  @override
  String get enter_company_phone;
  @override
  String get enter_company_email;
  @override
  String get rental_date;
  @override
  String get rental_date_sub;
  @override
  String get logout;
  @override
  String get payment_method;
  @override
  String get sadad_payment;
  @override
  String get bank_tansfer;
  @override
  String get card_payment;
  @override
  String get select_payment_method;
  @override
  String get upload;
  @override
  String get termsOfServiceTitle;
  @override
  String get termsOfServiceDescription;
  @override
  String get agreeToTerms;
  @override
  String get termsAndConditionsSub;
  @override
  String get continue_checkbox;
  @override
  String get yourSignature;
  @override
  String get pleaseSignAbove;
  @override
  String get clear;
  @override
  String get to_continue_accept_terms_condintion;
  @override
  String get to_continue_give_your_signature;
  @override
  String get register;
  @override
  String get you_do_not_have_ac;
  @override
  String get create;
  @override
  String get otp_successfully_send;
  @override
  String get otp_failed_send;
  @override
  String get send_otp;
  @override
  String get do_not_have_ac;
  @override
  String get discount;
  @override
  String get your_info;
  @override
  String get new_units;
  @override
  String get booked;
  @override
  String get booked_sub;
  @override
  String get delete_ac;
  @override
  String get delete_ac_sub;
  @override
  String get optional;
  @override
  String get quote;
  @override
  String get request_quote;
  @override
  String get request_quote_sub;
  @override
  String get choose_branch;
  @override
  String get choose_area;
  @override
  String get receiving_method;
  @override
  String get via_email;
  @override
  String get download_pdf;
  @override
  String get send_via_email;
  @override
  String get message;
  @override
  String get your_personal_info;
  @override
  String get nature_of_goods_stored;
  @override
  String get take_a_tour_with_makhzny;

  /// Create a copy of LangModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$LangModelImplCopyWith<_$LangModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
