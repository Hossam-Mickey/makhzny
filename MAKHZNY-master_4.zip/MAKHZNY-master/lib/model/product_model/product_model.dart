import 'package:freezed_annotation/freezed_annotation.dart';
part 'product_model.freezed.dart';
part 'product_model.g.dart';

@freezed
class ProductModel with _$ProductModel {
  const factory ProductModel({
    required int id,
    required String title,
    required String image,
    required double price,
    required double area,
    required double vat,
    // ignore: non_constant_identifier_names
    @Default(2) int company_id,
  }) = _ProductModel;

  factory ProductModel.fromJson(Map<String, dynamic> json) =>
      _$ProductModelFromJson(json);

  factory ProductModel.fromJsonMe(Map<String, dynamic> json, int id) {
    return ProductModel.fromJson(json).copyWith(company_id: id);
  }
}
