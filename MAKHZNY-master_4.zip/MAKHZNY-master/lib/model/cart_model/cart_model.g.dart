// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cart_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class CartModelAdapter extends TypeAdapter<CartModel> {
  @override
  final int typeId = 1;

  @override
  CartModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return CartModel(
      partner_id: fields[0] as int,
      branch_id: fields[1] as int,
      unit_id: fields[2] as int,
      installment_duration: fields[3] as int,
      sign: fields[5] as String,
    );
  }

  @override
  void write(BinaryWriter writer, CartModel obj) {
    writer
      ..writeByte(5)
      ..writeByte(0)
      ..write(obj.partner_id)
      ..writeByte(1)
      ..write(obj.branch_id)
      ..writeByte(2)
      ..write(obj.unit_id)
      ..writeByte(3)
      ..write(obj.installment_duration)
      ..writeByte(5)
      ..write(obj.sign);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CartModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$CartModelImpl _$$CartModelImplFromJson(Map<String, dynamic> json) =>
    _$CartModelImpl(
      partner_id: (json['partner_id'] as num).toInt(),
      branch_id: (json['branch_id'] as num).toInt(),
      unit_id: (json['unit_id'] as num).toInt(),
      installment_duration: (json['installment_duration'] as num).toInt(),
      sign: json['sign'] as String,
    );

Map<String, dynamic> _$$CartModelImplToJson(_$CartModelImpl instance) =>
    <String, dynamic>{
      'partner_id': instance.partner_id,
      'branch_id': instance.branch_id,
      'unit_id': instance.unit_id,
      'installment_duration': instance.installment_duration,
      'sign': instance.sign,
    };
