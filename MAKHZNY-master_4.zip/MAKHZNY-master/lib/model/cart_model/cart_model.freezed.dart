// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'cart_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

CartModel _$CartModelFromJson(Map<String, dynamic> json) {
  return _CartModel.fromJson(json);
}

/// @nodoc
mixin _$CartModel {
  @HiveField(0)
  int get partner_id => throw _privateConstructorUsedError;
  @HiveField(1)
  int get branch_id => throw _privateConstructorUsedError;
  @HiveField(2)
  int get unit_id => throw _privateConstructorUsedError;
  @HiveField(3)
  int get installment_duration =>
      throw _privateConstructorUsedError; // @HiveField(4) @MoveInDateConvertor() required DateTime move_in_date,
  @HiveField(5)
  String get sign => throw _privateConstructorUsedError;

  /// Serializes this CartModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of CartModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $CartModelCopyWith<CartModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CartModelCopyWith<$Res> {
  factory $CartModelCopyWith(CartModel value, $Res Function(CartModel) then) =
      _$CartModelCopyWithImpl<$Res, CartModel>;
  @useResult
  $Res call(
      {@HiveField(0) int partner_id,
      @HiveField(1) int branch_id,
      @HiveField(2) int unit_id,
      @HiveField(3) int installment_duration,
      @HiveField(5) String sign});
}

/// @nodoc
class _$CartModelCopyWithImpl<$Res, $Val extends CartModel>
    implements $CartModelCopyWith<$Res> {
  _$CartModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of CartModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? partner_id = null,
    Object? branch_id = null,
    Object? unit_id = null,
    Object? installment_duration = null,
    Object? sign = null,
  }) {
    return _then(_value.copyWith(
      partner_id: null == partner_id
          ? _value.partner_id
          : partner_id // ignore: cast_nullable_to_non_nullable
              as int,
      branch_id: null == branch_id
          ? _value.branch_id
          : branch_id // ignore: cast_nullable_to_non_nullable
              as int,
      unit_id: null == unit_id
          ? _value.unit_id
          : unit_id // ignore: cast_nullable_to_non_nullable
              as int,
      installment_duration: null == installment_duration
          ? _value.installment_duration
          : installment_duration // ignore: cast_nullable_to_non_nullable
              as int,
      sign: null == sign
          ? _value.sign
          : sign // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CartModelImplCopyWith<$Res>
    implements $CartModelCopyWith<$Res> {
  factory _$$CartModelImplCopyWith(
          _$CartModelImpl value, $Res Function(_$CartModelImpl) then) =
      __$$CartModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@HiveField(0) int partner_id,
      @HiveField(1) int branch_id,
      @HiveField(2) int unit_id,
      @HiveField(3) int installment_duration,
      @HiveField(5) String sign});
}

/// @nodoc
class __$$CartModelImplCopyWithImpl<$Res>
    extends _$CartModelCopyWithImpl<$Res, _$CartModelImpl>
    implements _$$CartModelImplCopyWith<$Res> {
  __$$CartModelImplCopyWithImpl(
      _$CartModelImpl _value, $Res Function(_$CartModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of CartModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? partner_id = null,
    Object? branch_id = null,
    Object? unit_id = null,
    Object? installment_duration = null,
    Object? sign = null,
  }) {
    return _then(_$CartModelImpl(
      partner_id: null == partner_id
          ? _value.partner_id
          : partner_id // ignore: cast_nullable_to_non_nullable
              as int,
      branch_id: null == branch_id
          ? _value.branch_id
          : branch_id // ignore: cast_nullable_to_non_nullable
              as int,
      unit_id: null == unit_id
          ? _value.unit_id
          : unit_id // ignore: cast_nullable_to_non_nullable
              as int,
      installment_duration: null == installment_duration
          ? _value.installment_duration
          : installment_duration // ignore: cast_nullable_to_non_nullable
              as int,
      sign: null == sign
          ? _value.sign
          : sign // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$CartModelImpl implements _CartModel {
  const _$CartModelImpl(
      {@HiveField(0) required this.partner_id,
      @HiveField(1) required this.branch_id,
      @HiveField(2) required this.unit_id,
      @HiveField(3) required this.installment_duration,
      @HiveField(5) required this.sign});

  factory _$CartModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$CartModelImplFromJson(json);

  @override
  @HiveField(0)
  final int partner_id;
  @override
  @HiveField(1)
  final int branch_id;
  @override
  @HiveField(2)
  final int unit_id;
  @override
  @HiveField(3)
  final int installment_duration;
// @HiveField(4) @MoveInDateConvertor() required DateTime move_in_date,
  @override
  @HiveField(5)
  final String sign;

  @override
  String toString() {
    return 'CartModel(partner_id: $partner_id, branch_id: $branch_id, unit_id: $unit_id, installment_duration: $installment_duration, sign: $sign)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CartModelImpl &&
            (identical(other.partner_id, partner_id) ||
                other.partner_id == partner_id) &&
            (identical(other.branch_id, branch_id) ||
                other.branch_id == branch_id) &&
            (identical(other.unit_id, unit_id) || other.unit_id == unit_id) &&
            (identical(other.installment_duration, installment_duration) ||
                other.installment_duration == installment_duration) &&
            (identical(other.sign, sign) || other.sign == sign));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType, partner_id, branch_id, unit_id, installment_duration, sign);

  /// Create a copy of CartModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$CartModelImplCopyWith<_$CartModelImpl> get copyWith =>
      __$$CartModelImplCopyWithImpl<_$CartModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$CartModelImplToJson(
      this,
    );
  }
}

abstract class _CartModel implements CartModel {
  const factory _CartModel(
      {@HiveField(0) required final int partner_id,
      @HiveField(1) required final int branch_id,
      @HiveField(2) required final int unit_id,
      @HiveField(3) required final int installment_duration,
      @HiveField(5) required final String sign}) = _$CartModelImpl;

  factory _CartModel.fromJson(Map<String, dynamic> json) =
      _$CartModelImpl.fromJson;

  @override
  @HiveField(0)
  int get partner_id;
  @override
  @HiveField(1)
  int get branch_id;
  @override
  @HiveField(2)
  int get unit_id;
  @override
  @HiveField(3)
  int get installment_duration; // @HiveField(4) @MoveInDateConvertor() required DateTime move_in_date,
  @override
  @HiveField(5)
  String get sign;

  /// Create a copy of CartModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$CartModelImplCopyWith<_$CartModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
