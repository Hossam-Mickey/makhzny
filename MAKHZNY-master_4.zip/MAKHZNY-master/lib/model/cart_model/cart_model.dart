import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:hive_flutter/adapters.dart';
part 'cart_model.freezed.dart';
part 'cart_model.g.dart';

@HiveType(typeId: 1)
@freezed
class CartModel with _$CartModel {
  const factory CartModel({
    @HiveField(0) required int partner_id,
    @HiveField(1) required int branch_id,
    @HiveField(2) required int unit_id,
    @HiveField(3) required int installment_duration,
    // @HiveField(4) @MoveInDateConvertor() required DateTime move_in_date,
    @HiveField(5) required String sign,
  }) = _CartModel;

  factory CartModel.fromJson(Map<String, dynamic> json) =>
      _$CartModelFromJson(json);
}

// class MoveInDateConvertor implements JsonConverter<DateTime, String> {
//   const MoveInDateConvertor();

//   @override
//   DateTime fromJson(String json) => DateTime.parse(json);

//   @override
//   String toJson(DateTime obj) {
//     var year = obj.year;
//     var day = obj.day.toString().padLeft(2, "0");
//     var month = obj.month.toString().padLeft(2, "0");
//     return "$day-$month-$year";
//   }
// }
