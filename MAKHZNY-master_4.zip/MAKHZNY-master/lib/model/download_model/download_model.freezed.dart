// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'download_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

DownloadModel _$DownloadModelFromJson(Map<String, dynamic> json) {
  return _DownloadModel.fromJson(json);
}

/// @nodoc
mixin _$DownloadModel {
  @HiveField(3)
  String get id => throw _privateConstructorUsedError;
  @HiveField(0)
  String get url => throw _privateConstructorUsedError;
  @HiveField(1)
  String get path => throw _privateConstructorUsedError;
  @HiveField(2)
  int get size => throw _privateConstructorUsedError;
  @HiveField(4)
  @NotifierDoubleConverter()
  ValueNotifier<double> get progress => throw _privateConstructorUsedError;
  @HiveField(5)
  @NotifierIntConverter()
  ValueNotifier<int> get downloaded_size => throw _privateConstructorUsedError;
  @HiveField(6)
  @TokenConverter()
  CancelToken? get token => throw _privateConstructorUsedError;
  @HiveField(7)
  Map<dynamic, dynamic> get meta => throw _privateConstructorUsedError;
  @HiveField(8)
  @NotifierStatusConverter()
  ValueNotifier<DownloadStatus> get status =>
      throw _privateConstructorUsedError;

  /// Serializes this DownloadModel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of DownloadModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $DownloadModelCopyWith<DownloadModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $DownloadModelCopyWith<$Res> {
  factory $DownloadModelCopyWith(
          DownloadModel value, $Res Function(DownloadModel) then) =
      _$DownloadModelCopyWithImpl<$Res, DownloadModel>;
  @useResult
  $Res call(
      {@HiveField(3) String id,
      @HiveField(0) String url,
      @HiveField(1) String path,
      @HiveField(2) int size,
      @HiveField(4) @NotifierDoubleConverter() ValueNotifier<double> progress,
      @HiveField(5) @NotifierIntConverter() ValueNotifier<int> downloaded_size,
      @HiveField(6) @TokenConverter() CancelToken? token,
      @HiveField(7) Map<dynamic, dynamic> meta,
      @HiveField(8)
      @NotifierStatusConverter()
      ValueNotifier<DownloadStatus> status});
}

/// @nodoc
class _$DownloadModelCopyWithImpl<$Res, $Val extends DownloadModel>
    implements $DownloadModelCopyWith<$Res> {
  _$DownloadModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of DownloadModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? url = null,
    Object? path = null,
    Object? size = null,
    Object? progress = null,
    Object? downloaded_size = null,
    Object? token = freezed,
    Object? meta = null,
    Object? status = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      url: null == url
          ? _value.url
          : url // ignore: cast_nullable_to_non_nullable
              as String,
      path: null == path
          ? _value.path
          : path // ignore: cast_nullable_to_non_nullable
              as String,
      size: null == size
          ? _value.size
          : size // ignore: cast_nullable_to_non_nullable
              as int,
      progress: null == progress
          ? _value.progress
          : progress // ignore: cast_nullable_to_non_nullable
              as ValueNotifier<double>,
      downloaded_size: null == downloaded_size
          ? _value.downloaded_size
          : downloaded_size // ignore: cast_nullable_to_non_nullable
              as ValueNotifier<int>,
      token: freezed == token
          ? _value.token
          : token // ignore: cast_nullable_to_non_nullable
              as CancelToken?,
      meta: null == meta
          ? _value.meta
          : meta // ignore: cast_nullable_to_non_nullable
              as Map<dynamic, dynamic>,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as ValueNotifier<DownloadStatus>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$DownloadModelImplCopyWith<$Res>
    implements $DownloadModelCopyWith<$Res> {
  factory _$$DownloadModelImplCopyWith(
          _$DownloadModelImpl value, $Res Function(_$DownloadModelImpl) then) =
      __$$DownloadModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@HiveField(3) String id,
      @HiveField(0) String url,
      @HiveField(1) String path,
      @HiveField(2) int size,
      @HiveField(4) @NotifierDoubleConverter() ValueNotifier<double> progress,
      @HiveField(5) @NotifierIntConverter() ValueNotifier<int> downloaded_size,
      @HiveField(6) @TokenConverter() CancelToken? token,
      @HiveField(7) Map<dynamic, dynamic> meta,
      @HiveField(8)
      @NotifierStatusConverter()
      ValueNotifier<DownloadStatus> status});
}

/// @nodoc
class __$$DownloadModelImplCopyWithImpl<$Res>
    extends _$DownloadModelCopyWithImpl<$Res, _$DownloadModelImpl>
    implements _$$DownloadModelImplCopyWith<$Res> {
  __$$DownloadModelImplCopyWithImpl(
      _$DownloadModelImpl _value, $Res Function(_$DownloadModelImpl) _then)
      : super(_value, _then);

  /// Create a copy of DownloadModel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? url = null,
    Object? path = null,
    Object? size = null,
    Object? progress = null,
    Object? downloaded_size = null,
    Object? token = freezed,
    Object? meta = null,
    Object? status = null,
  }) {
    return _then(_$DownloadModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      url: null == url
          ? _value.url
          : url // ignore: cast_nullable_to_non_nullable
              as String,
      path: null == path
          ? _value.path
          : path // ignore: cast_nullable_to_non_nullable
              as String,
      size: null == size
          ? _value.size
          : size // ignore: cast_nullable_to_non_nullable
              as int,
      progress: null == progress
          ? _value.progress
          : progress // ignore: cast_nullable_to_non_nullable
              as ValueNotifier<double>,
      downloaded_size: null == downloaded_size
          ? _value.downloaded_size
          : downloaded_size // ignore: cast_nullable_to_non_nullable
              as ValueNotifier<int>,
      token: freezed == token
          ? _value.token
          : token // ignore: cast_nullable_to_non_nullable
              as CancelToken?,
      meta: null == meta
          ? _value._meta
          : meta // ignore: cast_nullable_to_non_nullable
              as Map<dynamic, dynamic>,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as ValueNotifier<DownloadStatus>,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$DownloadModelImpl extends _DownloadModel {
  const _$DownloadModelImpl(
      {@HiveField(3) required this.id,
      @HiveField(0) required this.url,
      @HiveField(1) required this.path,
      @HiveField(2) required this.size,
      @HiveField(4) @NotifierDoubleConverter() required this.progress,
      @HiveField(5) @NotifierIntConverter() required this.downloaded_size,
      @HiveField(6) @TokenConverter() this.token,
      @HiveField(7) required final Map<dynamic, dynamic> meta,
      @HiveField(8) @NotifierStatusConverter() required this.status})
      : _meta = meta,
        super._();

  factory _$DownloadModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$DownloadModelImplFromJson(json);

  @override
  @HiveField(3)
  final String id;
  @override
  @HiveField(0)
  final String url;
  @override
  @HiveField(1)
  final String path;
  @override
  @HiveField(2)
  final int size;
  @override
  @HiveField(4)
  @NotifierDoubleConverter()
  final ValueNotifier<double> progress;
  @override
  @HiveField(5)
  @NotifierIntConverter()
  final ValueNotifier<int> downloaded_size;
  @override
  @HiveField(6)
  @TokenConverter()
  final CancelToken? token;
  final Map<dynamic, dynamic> _meta;
  @override
  @HiveField(7)
  Map<dynamic, dynamic> get meta {
    if (_meta is EqualUnmodifiableMapView) return _meta;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(_meta);
  }

  @override
  @HiveField(8)
  @NotifierStatusConverter()
  final ValueNotifier<DownloadStatus> status;

  @override
  String toString() {
    return 'DownloadModel(id: $id, url: $url, path: $path, size: $size, progress: $progress, downloaded_size: $downloaded_size, token: $token, meta: $meta, status: $status)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$DownloadModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.url, url) || other.url == url) &&
            (identical(other.path, path) || other.path == path) &&
            (identical(other.size, size) || other.size == size) &&
            (identical(other.progress, progress) ||
                other.progress == progress) &&
            (identical(other.downloaded_size, downloaded_size) ||
                other.downloaded_size == downloaded_size) &&
            (identical(other.token, token) || other.token == token) &&
            const DeepCollectionEquality().equals(other._meta, _meta) &&
            (identical(other.status, status) || other.status == status));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      url,
      path,
      size,
      progress,
      downloaded_size,
      token,
      const DeepCollectionEquality().hash(_meta),
      status);

  /// Create a copy of DownloadModel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$DownloadModelImplCopyWith<_$DownloadModelImpl> get copyWith =>
      __$$DownloadModelImplCopyWithImpl<_$DownloadModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$DownloadModelImplToJson(
      this,
    );
  }
}

abstract class _DownloadModel extends DownloadModel {
  const factory _DownloadModel(
          {@HiveField(3) required final String id,
          @HiveField(0) required final String url,
          @HiveField(1) required final String path,
          @HiveField(2) required final int size,
          @HiveField(4)
          @NotifierDoubleConverter()
          required final ValueNotifier<double> progress,
          @HiveField(5)
          @NotifierIntConverter()
          required final ValueNotifier<int> downloaded_size,
          @HiveField(6) @TokenConverter() final CancelToken? token,
          @HiveField(7) required final Map<dynamic, dynamic> meta,
          @HiveField(8)
          @NotifierStatusConverter()
          required final ValueNotifier<DownloadStatus> status}) =
      _$DownloadModelImpl;
  const _DownloadModel._() : super._();

  factory _DownloadModel.fromJson(Map<String, dynamic> json) =
      _$DownloadModelImpl.fromJson;

  @override
  @HiveField(3)
  String get id;
  @override
  @HiveField(0)
  String get url;
  @override
  @HiveField(1)
  String get path;
  @override
  @HiveField(2)
  int get size;
  @override
  @HiveField(4)
  @NotifierDoubleConverter()
  ValueNotifier<double> get progress;
  @override
  @HiveField(5)
  @NotifierIntConverter()
  ValueNotifier<int> get downloaded_size;
  @override
  @HiveField(6)
  @TokenConverter()
  CancelToken? get token;
  @override
  @HiveField(7)
  Map<dynamic, dynamic> get meta;
  @override
  @HiveField(8)
  @NotifierStatusConverter()
  ValueNotifier<DownloadStatus> get status;

  /// Create a copy of DownloadModel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$DownloadModelImplCopyWith<_$DownloadModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
