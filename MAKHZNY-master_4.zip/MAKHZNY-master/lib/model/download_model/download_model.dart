// ignore_for_file: non_constant_identifier_names

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:universal_platform/universal_platform.dart';
part 'download_model.freezed.dart';
part 'download_model.g.dart';

@HiveType(typeId: 5)
enum DownloadStatus {
  @HiveField(0)
  completed,
  @HiveField(1)
  failed,
  @HiveField(2)
  pause,
  @HiveField(3)
  running,
  @HiveField(4)
  processing,
  @HiveField(5)
  unzipping,
}

@HiveType(typeId: 4)
@freezed
class DownloadModel with _$DownloadModel {
  const DownloadModel._();
  const factory DownloadModel({
    @HiveField(3) required String id,
    @HiveField(0) required String url,
    @HiveField(1) required String path,
    @HiveField(2) required int size,
    @HiveField(4)
    @NotifierDoubleConverter()
    required ValueNotifier<double> progress,
    @HiveField(5)
    @NotifierIntConverter()
    required ValueNotifier<int> downloaded_size,
    @HiveField(6) @TokenConverter() CancelToken? token,
    @HiveField(7) required Map meta,
    @HiveField(8)
    @NotifierStatusConverter()
    required ValueNotifier<DownloadStatus> status,
  }) = _DownloadModel;

  factory DownloadModel.fromJson(Map<String, dynamic> json) =>
      _$DownloadModelFromJson(json);

  String get fileName {
    var slash = UniversalPlatform.isAndroid ? "/" : "\\";
    var split = path.split(slash);
    return split.last;
  }
}

class TokenConverter implements JsonConverter<CancelToken?, String> {
  const TokenConverter();

  @override
  CancelToken? fromJson(String json) => null;

  @override
  String toJson(CancelToken? object) => "";
}

class NotifierDoubleConverter
    implements JsonConverter<ValueNotifier<double>, double> {
  const NotifierDoubleConverter();

  @override
  ValueNotifier<double> fromJson(double json) => ValueNotifier(json);

  @override
  double toJson(ValueNotifier<double> object) => object.value;
}

class NotifierIntConverter implements JsonConverter<ValueNotifier<int>, int> {
  const NotifierIntConverter();

  @override
  ValueNotifier<int> fromJson(int json) => ValueNotifier(json);

  @override
  int toJson(ValueNotifier<int> object) => object.value;
}

class NotifierStatusConverter
    implements JsonConverter<ValueNotifier<DownloadStatus>, int> {
  const NotifierStatusConverter();

  @override
  ValueNotifier<DownloadStatus> fromJson(int json) {
    var status = DownloadStatus.values[json];
    if (status == DownloadStatus.running ||
        status == DownloadStatus.processing) {
      status = DownloadStatus.pause;
    }
    return ValueNotifier(status);
  }

  @override
  int toJson(ValueNotifier<DownloadStatus> object) => object.value.index;
}
