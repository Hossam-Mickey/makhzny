// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'download_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class DownloadModelAdapter extends TypeAdapter<DownloadModel> {
  @override
  final int typeId = 4;

  @override
  DownloadModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DownloadModel(
      id: fields[3] as String,
      url: fields[0] as String,
      path: fields[1] as String,
      size: fields[2] as int,
      progress: fields[4] as ValueNotifier<double>,
      downloaded_size: fields[5] as ValueNotifier<int>,
      token: fields[6] as CancelToken?,
      meta: (fields[7] as Map).cast<dynamic, dynamic>(),
      status: fields[8] as ValueNotifier<DownloadStatus>,
    );
  }

  @override
  void write(BinaryWriter writer, DownloadModel obj) {
    writer
      ..writeByte(9)
      ..writeByte(3)
      ..write(obj.id)
      ..writeByte(0)
      ..write(obj.url)
      ..writeByte(1)
      ..write(obj.path)
      ..writeByte(2)
      ..write(obj.size)
      ..writeByte(4)
      ..write(obj.progress)
      ..writeByte(5)
      ..write(obj.downloaded_size)
      ..writeByte(6)
      ..write(obj.token)
      ..writeByte(7)
      ..write(obj.meta)
      ..writeByte(8)
      ..write(obj.status);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DownloadModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

class DownloadStatusAdapter extends TypeAdapter<DownloadStatus> {
  @override
  final int typeId = 5;

  @override
  DownloadStatus read(BinaryReader reader) {
    switch (reader.readByte()) {
      case 0:
        return DownloadStatus.completed;
      case 1:
        return DownloadStatus.failed;
      case 2:
        return DownloadStatus.pause;
      case 3:
        return DownloadStatus.running;
      case 4:
        return DownloadStatus.processing;
      case 5:
        return DownloadStatus.unzipping;
      default:
        return DownloadStatus.completed;
    }
  }

  @override
  void write(BinaryWriter writer, DownloadStatus obj) {
    switch (obj) {
      case DownloadStatus.completed:
        writer.writeByte(0);
        break;
      case DownloadStatus.failed:
        writer.writeByte(1);
        break;
      case DownloadStatus.pause:
        writer.writeByte(2);
        break;
      case DownloadStatus.running:
        writer.writeByte(3);
        break;
      case DownloadStatus.processing:
        writer.writeByte(4);
        break;
      case DownloadStatus.unzipping:
        writer.writeByte(5);
        break;
    }
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DownloadStatusAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$DownloadModelImpl _$$DownloadModelImplFromJson(Map<String, dynamic> json) =>
    _$DownloadModelImpl(
      id: json['id'] as String,
      url: json['url'] as String,
      path: json['path'] as String,
      size: (json['size'] as num).toInt(),
      progress: const NotifierDoubleConverter()
          .fromJson((json['progress'] as num).toDouble()),
      downloaded_size: const NotifierIntConverter()
          .fromJson((json['downloaded_size'] as num).toInt()),
      token: _$JsonConverterFromJson<String, CancelToken?>(
          json['token'], const TokenConverter().fromJson),
      meta: json['meta'] as Map<String, dynamic>,
      status: const NotifierStatusConverter()
          .fromJson((json['status'] as num).toInt()),
    );

Map<String, dynamic> _$$DownloadModelImplToJson(_$DownloadModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'url': instance.url,
      'path': instance.path,
      'size': instance.size,
      'progress': const NotifierDoubleConverter().toJson(instance.progress),
      'downloaded_size':
          const NotifierIntConverter().toJson(instance.downloaded_size),
      'token': const TokenConverter().toJson(instance.token),
      'meta': instance.meta,
      'status': const NotifierStatusConverter().toJson(instance.status),
    };

Value? _$JsonConverterFromJson<Json, Value>(
  Object? json,
  Value? Function(Json json) fromJson,
) =>
    json == null ? null : fromJson(json as Json);
