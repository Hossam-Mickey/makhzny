import 'package:client_1/constants/api.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
part 'carousel_model.freezed.dart';
part 'carousel_model.g.dart';

@freezed
class CarouselModel with _$CarouselModel {
  const CarouselModel._();
  const factory CarouselModel({
    required String name,
    required String download_url,
  }) = _CarouselModel;

  factory CarouselModel.fromJson(Map<String, dynamic> json) =>
      _$CarouselModelFromJson(json);

  String get urlWithBase {
    var link = download_url.replaceRange(0, 1, "");
    return API.baseUrl + link;
  }
}
