// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'carousel_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$CarouselModelImpl _$$CarouselModelImplFromJson(Map<String, dynamic> json) =>
    _$CarouselModelImpl(
      name: json['name'] as String,
      download_url: json['download_url'] as String,
    );

Map<String, dynamic> _$$CarouselModelImplToJson(_$CarouselModelImpl instance) =>
    <String, dynamic>{
      'name': instance.name,
      'download_url': instance.download_url,
    };
