// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$UserModelImpl _$$UserModelImplFromJson(Map<String, dynamic> json) =>
    _$UserModelImpl(
      partner_id: (json['partner_id'] as num?)?.toInt(),
      name: json['name'] as String,
      phone: json['phone'] as String,
      email: json['email'] as String,
      id_number: json['id_number'] as String,
      dob: _$JsonConverterFromJson<String, DateTime>(
          json['dob'], const DOBConvertor().fromJson),
      auth_name: json['auth_name'] as String,
      auth_phone: json['auth_phone'] as String,
      vat: json['vat'] as String,
      cr_number: json['cr'] as String,
      address: json['street'] as String,
      otp_number: json['otp'] as String,
    );

Map<String, dynamic> _$$UserModelImplToJson(_$UserModelImpl instance) =>
    <String, dynamic>{
      'partner_id': instance.partner_id,
      'name': instance.name,
      'phone': instance.phone,
      'email': instance.email,
      'id_number': instance.id_number,
      'dob': _$JsonConverterToJson<String, DateTime>(
          instance.dob, const DOBConvertor().toJson),
      'auth_name': instance.auth_name,
      'auth_phone': instance.auth_phone,
      'vat': instance.vat,
      'cr': instance.cr_number,
      'street': instance.address,
      'otp': instance.otp_number,
    };

Value? _$JsonConverterFromJson<Json, Value>(
  Object? json,
  Value? Function(Json json) fromJson,
) =>
    json == null ? null : fromJson(json as Json);

Json? _$JsonConverterToJson<Json, Value>(
  Value? value,
  Json? Function(Value value) toJson,
) =>
    value == null ? null : toJson(value);
