// ignore_for_file: non_constant_identifier_names, invalid_annotation_target

import 'package:freezed_annotation/freezed_annotation.dart';

part 'user_model.freezed.dart';
part 'user_model.g.dart';

@freezed
class UserModel with _$UserModel {
  const factory UserModel({
    int? partner_id,
    required String name,
    required String phone,
    required String email,
    required String id_number,
    @DOBConvertor() DateTime? dob,
    required String auth_name,
    required String auth_phone,
    required String vat,
    @JsonKey(name: "cr") required String cr_number,
    @JsonKey(name: "street") required String address,
    @JsonKey(name: "otp") required String otp_number,

    // required String company_phone,
  }) = _UserModel;

  factory UserModel.fromJson(Map<String, dynamic> json) =>
      _$UserModelFromJson(json);
}

class DOBConvertor implements JsonConverter<DateTime, String> {
  const DOBConvertor();

  @override
  DateTime fromJson(String json) => DateTime.parse(json);

  @override
  String toJson(DateTime obj) {
    var year = obj.year;
    var day = obj.day.toString().padLeft(2, "0");
    var month = obj.month.toString().padLeft(2, "0");
    return "$year-$day-$month";
  }
}
