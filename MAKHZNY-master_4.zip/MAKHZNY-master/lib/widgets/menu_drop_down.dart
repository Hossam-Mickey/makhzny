import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'app_text.dart';

class MenuDropDown extends StatelessWidget {
  final Color color;
  final List<(int i, String name)> buttons;
  final Function(int i) onTap;
  const MenuDropDown({
    super.key,
    this.color = Colors.white,
    required this.buttons,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      alignment: Alignment.center,
      child: PopupMenuButton<int>(
        onSelected: (i) => onTap(i),
        tooltip: "",
        icon: Icon(
          Icons.more_vert_rounded,
          color: color,
          size: 28,
        ),
        surfaceTintColor: Colors.grey,
        shadowColor: Colors.transparent,
        // color: MyColor.lightDarkBlue.withOpacity(0.2),
        itemBuilder: (context) => [
          ...buttons.map((e) => dropItems(e.$1, e.$2)),
        ],
      ),
    );
  }

  PopupMenuItem<int> dropItems(int value, String text) {
    return PopupMenuItem<int>(
      value: value,
      child: Row(
        children: [
          AppText(
            text,
            fontWeight: FontWeight.w600,
          )
        ],
      ).animate().fade(duration: 500.ms),
    );
  }
}
