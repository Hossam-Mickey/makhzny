import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/mouse_cursor.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../main.dart';

class CusTab extends StatefulWidget {
  final List<(String, int)> data;
  final int selected;
  final Function(int) onTap;
  const CusTab({
    super.key,
    required this.data,
    required this.selected,
    required this.onTap,
  });

  @override
  State<CusTab> createState() => _CusTabState();
}

class _CusTabState extends State<CusTab> with SingleTickerProviderStateMixin {
  late TabController controller;
  @override
  void initState() {
    controller = TabController(length: widget.data.length, vsync: this);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 0),
      child: TabBar(
        splashBorderRadius: BorderRadius.circular(90),
        indicator: const BoxDecoration(),
        dividerColor: Colors.transparent,
        isScrollable: true,
        tabAlignment: TabAlignment.center,
        controller: controller,
        onTap: (i) => widget.onTap(i),
        tabs: List.generate(
          widget.data.length,
          (i) => CusMouseCursor(
            child: tabChild(
              widget.data[i].$1,
              widget.data[i].$2,
            ),
          ),
        ).toList(),
      ),
    );
  }

  Widget tabChild(String text, int count) {
    var context = messangerKey.currentContext!;
    var media = MediaQuery.of(context).size;
    var bool = widget.selected == count;
    var color = bool ? Colors.white : context.read<ThemePro>().grey;
    return GestureDetector(
      onTap: () {
        widget.onTap(count);
        controller.animateTo(count, duration: 300.ms);
      },
      child: AnimatedContainer(
        duration: 300.ms,
        padding: EdgeInsets.symmetric(
          horizontal: bool ? (media.height / 20).spMin : 10,
          vertical: 10,
        ),
        decoration: BoxDecoration(
          color: bool ? Theme.of(context).primaryColor : Colors.transparent,
          borderRadius: BorderRadius.circular(90),
        ),
        child: AppText(
          text,
          color: color,
          fontWeight: FontWeight.w600,
          fontSize: 14.spMin,
        ),
      ),
    );
  }
}
