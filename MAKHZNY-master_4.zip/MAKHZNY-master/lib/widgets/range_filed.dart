import 'package:client_1/constants/colors.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/constants/string.dart';
import 'package:client_1/functions/blur_bottom_sheet.dart';
import 'package:client_1/route.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:client_1/widgets/cus_elevation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:syncfusion_flutter_sliders/sliders.dart';
// ignore: depend_on_referenced_packages
import 'package:syncfusion_flutter_core/theme.dart';

class RangeFiled extends StatefulWidget {
  final bool haveFilter;
  final RangeValues price;
  final RangeValues size;
  final double maxPrice;
  final double maxSize;
  final Function(RangeValues range) priceChange;
  final Function(RangeValues range) sizeChange;
  final Function clear;
  final bool sheet;

  const RangeFiled({
    super.key,
    required this.haveFilter,
    required this.price,
    required this.size,
    required this.priceChange,
    required this.sizeChange,
    required this.clear,
    required this.maxPrice,
    required this.maxSize,
    this.sheet = false,
  });

  @override
  State<RangeFiled> createState() => _RangeFiledState();
}

class _RangeFiledState extends State<RangeFiled> {
  late RangeValues price;
  late RangeValues size;

  @override
  void initState() {
    price = widget.price;
    size = widget.size;
    setState(() {});
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.sizeOf(context).width;

    if (widget.sheet) {
      return Stack(
        children: [
          const BlurDialogBg(),
          Align(
            alignment: Alignment.bottomCenter,
            child: SingleChildScrollView(
              child: Container(
                // height: 400.h,
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 30),
                decoration: BoxDecoration(
                  color: Theme.of(context).scaffoldBackgroundColor,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20),
                  ),
                ),
                child: SafeArea(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      sizedBoxH20,
                      Row(
                        children: [
                          Expanded(
                            child: card(
                              max: widget.maxPrice,
                              title: "Price Range",
                              range: price,
                              change: (v) {
                                price = v;
                                setState(() {});
                              },
                            ),
                          ),
                        ],
                      ),
                      sizedBoxH20,
                      Row(
                        children: [
                          Expanded(
                            child: card(
                              max: widget.maxSize,
                              title: "Size Range",
                              range: size,
                              change: (v) {
                                size = v;
                                setState(() {});
                              },
                            ),
                          ),
                        ],
                      ),
                      sizedBoxH20,
                      AppButton(
                        text: widget.haveFilter ? "Clear" : "Apply",
                        fontWeight: FontWeight.bold,
                        fontSize: 14.spMin,
                        borderRadius: BorderRadius.circular(10.r),
                        onPressed: () {
                          buttonPress(context);
                        },
                      ),
                      sizedBoxH20,
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      );
    } else {
      if (width <= MyString.rangeWidth) return const SizedBox();
      return Container(
        margin: const EdgeInsets.only(top: 15, left: 20, right: 20, bottom: 10),
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.r),
        ),
        child: Flex(
          // crossAxisAlignment: CrossAxisAlignment.end,
          direction: Axis.horizontal,
          children: [
            Flexible(
              fit: FlexFit.tight,
              child: card(
                max: widget.maxPrice,
                title: "Price range",
                range: price,
                change: (v) {
                  price = v;
                  setState(() {});
                },
              ),
            ),
            sizedBoxW40,
            Flexible(
              fit: FlexFit.tight,
              child: card(
                max: widget.maxSize,
                title: "Size Range",
                range: size,
                change: (v) {
                  size = v;
                  setState(() {});
                },
              ),
            ),
            sizedBoxW40,
            AppButton(
              width: 100,
              text: widget.haveFilter ? "Clear" : "Apply",
              fontWeight: FontWeight.bold,
              fontSize: 14.spMin,
              // margin: const EdgeInsets.only(right:20),
              borderRadius: BorderRadius.circular(10.r),
              onPressed: () {
                buttonPress(context);
              },
            ).animate().shimmer(duration: 600.ms).fade(duration: 600.ms)
          ],
        ),
      );
    }
  }

  void buttonPress(BuildContext context) {
    if (widget.haveFilter) {
      widget.clear();
      price = RangeValues(0, widget.maxPrice);
      size = RangeValues(0, widget.maxSize);
      setState(() {});
    } else {
      widget.priceChange(price);
      if (widget.sheet) context.pop();
      widget.sizeChange(size);
    }
  }

  Widget card({
    required String title,
    required RangeValues range,
    required Function(RangeValues range) change,
    required double max,
  }) {
    return CustomElevation(
      shape: BoxShape.rectangle,
      color: Theme.of(context).brightness == Brightness.dark
          ? Colors.grey.shade500
          : Colors.grey.shade800,
      spread: -20,
      offset: const Offset(10, 10),
      blur: 20,
      child: Container(
        width: 150.w,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.r),
          color: Theme.of(context).scaffoldBackgroundColor,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            sizedBoxH10,
            AppText(
              title,
              fontWeight: FontWeight.bold,
              fontSize: 15.spMin,
              padding: const EdgeInsets.symmetric(horizontal: 15),
            ),
            sizedBoxH5,
            SizedBox(
              width: double.infinity,
              child: SfRangeSliderTheme(
                data: SfRangeSliderThemeData(
                  tooltipTextStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 10.spMin,
                    color: Colors.white,
                  ),
                  tooltipBackgroundColor: Colors.grey.shade800,
                ),
                child: SfRangeSlider(
                  max: max,
                  values: SfRangeValues(range.start, range.end),
                  onChanged: (SfRangeValues v) {
                    if (widget.haveFilter) widget.clear();
                    change(RangeValues(
                      v.start.toInt().toDouble(),
                      v.end.toInt().toDouble(),
                    ));
                  },
                  showTicks: true,
                  enableTooltip: true,
                  thumbShape: const _ThumbShape(true),
                ),
              ),
            ),
            SizedBox(
              height: 70,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  sizedBoxW10,
                  sizedBoxW5,
                  value(range.start.toInt().toString(),
                      "Min ${title.split(" ").first}"),
                  sizedBoxW10,
                  Container(
                    margin: const EdgeInsets.only(top: 20),
                    color: Colors.grey.shade500,
                    width: 15,
                    height: 1,
                  ),
                  sizedBoxW10,
                  value(range.end.toInt().toString(),
                      "Max ${title.split(" ").first}"),
                  sizedBoxW10,
                  sizedBoxW5,
                ],
              ),
            ),
            sizedBoxH10,
          ],
        ),
      ),
    ).animate().shimmer(duration: 600.ms).fade(duration: 600.ms);
  }
}

Widget value(
  String value,
  String title,
) {
  return Expanded(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AppText(
          title,
          fontSize: 12.spMin,
          fontWeight: FontWeight.bold,
        ),
        sizedBoxH5,
        Container(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.r),
            border: Border.all(
              color: Colors.grey.shade500,
            ),
          ),
          child: Row(
            children: [
              Expanded(
                child: AppText(
                  value,
                  fontSize: 12.spMin,
                  fontWeight: FontWeight.bold,
                ),
              ),
              sizedBoxW5,
              Container(
                color: Colors.grey.shade500,
                width: 1,
                height: 20,
              ),
              sizedBoxW10,
              AppText(
                title.toLowerCase().contains("size") ? "M²" : "SAR",
                fontSize: 12.spMin,
                fontWeight: FontWeight.bold,
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

class _ThumbShape extends SfThumbShape {
  const _ThumbShape(this.isDoubleStroke);
  final bool isDoubleStroke;
  @override
  void paint(
    PaintingContext context,
    Offset center, {
    required RenderBox parentBox,
    required RenderBox? child,
    required SfSliderThemeData themeData,
    SfRangeValues? currentValues,
    dynamic currentValue,
    required Paint? paint,
    required Animation<double> enableAnimation,
    required TextDirection textDirection,
    required SfThumb? thumb,
  }) {
    super.paint(
      context,
      center,
      parentBox: parentBox,
      child: child,
      themeData: themeData,
      currentValues: currentValues,
      paint: paint,
      enableAnimation: enableAnimation,
      textDirection: textDirection,
      thumb: thumb,
    );

    context.canvas.drawCircle(
      center,
      getPreferredSize(themeData).width / 2,
      Paint()
        ..isAntiAlias = true
        ..strokeWidth = 2
        ..style = PaintingStyle.stroke
        ..color = themeData.activeTrackColor!,
    );
    var cxt = navigatorKey.currentContext!;
    if (isDoubleStroke) {
      context.canvas.drawCircle(
        center,
        getPreferredSize(themeData).width / 3,
        Paint()
          ..isAntiAlias = true
          ..strokeWidth = 3
          ..style = PaintingStyle.stroke
          ..color = Theme.of(cxt).scaffoldBackgroundColor,
      );
    }
  }
}

class SearchRangeButton extends StatelessWidget {
  final bool haveFilter;
  final Widget child;
  const SearchRangeButton({
    super.key,
    required this.haveFilter,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.sizeOf(context).width;
    if (width >= MyString.rangeWidth) return const SizedBox();
    return GestureDetector(
      onTap: () {
        showModalBottomSheet(
          context: navigatorKey.currentContext!,
          useSafeArea: false,
          isScrollControlled: true,
          enableDrag: false,
          backgroundColor: Colors.transparent,
          builder: (_) => child,
        );
      },
      child: Container(
        height: 40,
        width: 40,
        margin: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.light
              ? MyColor.lightGrey
              : Colors.grey.shade900,
          borderRadius: BorderRadius.circular(10.r),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            const Center(child: Icon(Icons.filter_alt_outlined)),
            if (haveFilter)
              const Padding(
                padding: EdgeInsets.only(left: 15, bottom: 15),
                child: CircleAvatar(
                  radius: 3,
                  backgroundColor: Colors.redAccent,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
