import 'dart:math';

import 'package:client_1/constants/colors.dart';
import 'package:client_1/constants/sized_box.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/widgets/app_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';

class CusTextField extends StatelessWidget {
  final TextEditingController control;
  final Function(String v)? onChange;
  final String? text;
  final String hintText;
  final bool email;
  final double topTextSize;
  final TextInputType? type;
  final int maxLine;
  final Function(String? v) validator;
  final double? width;
  final FocusNode? node;
  final FocusNode? nextNode;
  final bool hidePassword;
  final Function? unHide;
  final bool hideValue;
  final List<TextInputFormatter>? formatter;
  final String? hint2;
  final Widget? prefixIcon;
  final String? fillHint;

  const CusTextField({
    super.key,
    this.maxLine = 1,
    this.formatter,
    required this.validator,
    this.topTextSize = 14,
    required this.control,
    this.onChange,
    this.email = false,
    this.text,
    required this.hintText,
    this.type,
    this.width,
    this.node,
    this.nextNode,
    this.hidePassword = false,
    this.unHide,
    this.hideValue = false,
    this.hint2,
    this.prefixIcon,
    this.fillHint,
  });

  @override
  Widget build(BuildContext context) {
    var outlineInputBorder = const UnderlineInputBorder(
      borderSide: BorderSide(
        color: Colors.grey,
      ),
    );
    var textStyle = TextStyle(
      fontSize: 14,
      // height: 1,
      // color: Colors.white,
      fontWeight: FontWeight.w500,
      fontFamily: context.read<ThemePro>().font,
    );

    return Directionality(
      textDirection: TextDirection.ltr,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          if (text != null && text!.isNotEmpty)
            AppText(
              text!,
              fontWeight: FontWeight.bold,
              fontSize: topTextSize,
              maxLines: 2,
              color: Colors.black,
            ),
          if (text != null && text!.isNotEmpty) sizedBoxH10,
          SizedBox(
            width: width,
            child: TextFormField(
              enableSuggestions: true,
              autofillHints: fillHint == null ? null : [fillHint!],
              focusNode: node,
              onFieldSubmitted: (v) {
                node?.unfocus();
                nextNode?.requestFocus();
              },
              obscureText: hideValue,
              validator: (v) => validator(v),
              maxLines: maxLine,
              controller: control,
              keyboardType: email ? TextInputType.emailAddress : type,
              inputFormatters: type == TextInputType.number
                  ? <TextInputFormatter>[
                      FilteringTextInputFormatter.digitsOnly,
                      ...?formatter
                    ]
                  : [...?formatter],
              onChanged: (v) => onChange == null ? {} : onChange!(v),
              style: textStyle,
              decoration: InputDecoration(
                // fillColor: Colors.grey.withOpacity(0.3),
                // filled: true,
                prefixIcon: prefixIcon,
                labelText: hintText,
                hintText: hint2,
                hintStyle: textStyle.copyWith(
                  color: Colors.grey.withOpacity(0.8),
                ),
                labelStyle: textStyle.copyWith(
                  color: MyColor.grey,
                ),
                errorStyle: textStyle,
                // isCollapsed: true,
                // contentPadding: const EdgeInsets.symmetric(
                //   vertical: 15,
                //   horizontal: 10,
                // ).copyWith(top: 15),
                border: outlineInputBorder,
                enabledBorder: outlineInputBorder,
                focusedBorder: outlineInputBorder.copyWith(
                  borderSide: BorderSide(color: Theme.of(context).primaryColor),
                ),
              ),
            ),
          )
        ],
      ).animate(delay: 200.ms).flip().fade(),
    );
  }
}

class CustomTextInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    final RegExp regExp = RegExp(r'^[0-9+]*$');
    if (regExp.hasMatch(newValue.text)) {
      return newValue;
    }
    return oldValue;
  }
}

class CardFormatter extends TextInputFormatter {
  CardFormatter();

  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    if (newValue.selection.baseOffset == 0) {
      return newValue;
    }
    String enteredData = newValue.text; // get data enter by used in textField
    StringBuffer buffer = StringBuffer();
    for (int i = 0; i < enteredData.length; i++) {
      // add each character into String buffer
      buffer.write(enteredData[i]);
      int index = i + 1;
      if (index % 4 == 0 && enteredData.length != index) {
        // add space after 4th digit
        buffer.write(' ');
      }
    }

    return TextEditingValue(
        text: buffer.toString(), // final generated credit card number
        selection: TextSelection.collapsed(
            offset: buffer.toString().length) // keep the cursor at end
        );
  }
}

class ExpiryDateInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    var text = newValue.text;
    if (text.length <= 2) return newValue;
    var newText = text.substring(0, 2);
    var text2 = "$newText/${text.substring(2)}";
    return newValue.copyWith(
      text: text2,
      selection: TextSelection.collapsed(offset: text2.length),
    );
  }
}

class BirthdayTextFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    final newText = newValue.text;

    // Don't format if the new text is empty or shorter than 3 characters
    if (newText.isEmpty || newText.length < 3) {
      return newValue;
    }

    // Ensure the length of the new text doesn't exceed 10 characters (dd/mm/yyyy)
    if (newText.length > 10) {
      return oldValue;
    }

    // Insert slashes for date format (dd/mm/yyyy)
    final StringBuffer newTextBuffer = StringBuffer();
    newTextBuffer.write(newText.substring(0, 2));
    if (newText.length > 2) {
      newTextBuffer.write('/');
      newTextBuffer.write(newText.substring(2, 4));
    }
    if (newText.length > 4) {
      newTextBuffer.write('/');
      newTextBuffer.write(newText.substring(4, min(8, newText.length)));
    }

    return TextEditingValue(
      text: newTextBuffer.toString(),
      selection: TextSelection.collapsed(offset: newTextBuffer.length),
    );
  }
}
