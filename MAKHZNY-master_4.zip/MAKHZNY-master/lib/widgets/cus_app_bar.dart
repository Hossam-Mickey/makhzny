import 'package:client_1/constants/sized_box.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:universal_platform/universal_platform.dart';

import 'app_text.dart';

class CusAppbar extends StatelessWidget {
  final bool canPop;
  final String title;
  final Widget? sideChild;
  final Color? color;
  const CusAppbar({
    super.key,
    this.canPop = true,
    required this.title,
    this.sideChild,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        if (UniversalPlatform.isWeb) sizedBoxW10,
        IconButton(
          padding: EdgeInsets.zero,
          onPressed: () {
            if (canPop) context.pop();
          },
          icon: Icon(
            Icons.arrow_back_ios,
            size: 20.spMin,
            color: color,
          ),
        ),
        AppText(
          title,
          fontSize: 20.spMin,
          fontWeight: FontWeight.w500,
          color: color,
        ),
        const Spacer(),
        if (sideChild != null) sideChild!
      ],
    );
  }
}
