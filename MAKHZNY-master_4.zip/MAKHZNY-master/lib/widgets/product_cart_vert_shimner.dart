import 'package:client_1/constants/sized_box.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../provider/theme_pro/theme_pro.dart';
import 'container_shimner.dart';

class ProductCardVertShimner extends StatelessWidget {
  const ProductCardVertShimner({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 105,
      margin: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: context.read<ThemePro>().cardColor,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade900.withOpacity(0.1),
            spreadRadius: -1,
            offset: const Offset(0, 4),
            blurRadius: 20,
          )
        ],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          ContainerShimner(
            width: 90,
            height: double.infinity,
            margin: const EdgeInsets.all(10),
            borderRadius: BorderRadius.circular(8),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: ContainerShimner(
                          margin: EdgeInsets.only(right: 50.w),
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  ContainerShimner(width: 100.w),
                  const Spacer(flex: 5),
                  ContainerShimner(width: 100.w),
                ],
              ),
            ),
          ),
          sizedBoxW10,
        ],
      ),
    );
  }
}
