import 'package:client_1/constants/colors.dart';
import 'package:client_1/main.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';
import '../../provider/lang_pro/lang_pro.dart';

class SearchText extends StatelessWidget {
  const SearchText({
    super.key,
    this.controller,
    this.node,
    this.onChanged,
    this.hint,
    this.type,
  });
  final String? hint;
  final TextEditingController? controller;
  final FocusNode? node;
  final Function(String)? onChanged;
  final TextInputType? type;

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;
    var textStyle = TextStyle(
      fontSize: 14.spMin,
      fontWeight: FontWeight.w500,
      fontFamily: context.read<ThemePro>().font,
    );

    var outlineInputBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: const BorderSide(
        color: Color(0xff707070),
      ),
    );
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15),
        child: TextField(
          style: textStyle,
          textInputAction: TextInputAction.done,
          controller: controller,
          focusNode: node,
          onChanged: onChanged,
          keyboardType: type,
          inputFormatters: type == TextInputType.number
              ? <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly]
              : [],
          decoration: InputDecoration(
            filled: true,
            prefixIcon: hint != null
                ? null
                : const Icon(
                    Icons.search,
                    color: MyColor.grey,
                  ),
            fillColor: Theme.of(context).brightness == Brightness.light
                ? MyColor.lightGrey
                : Colors.grey.shade900,
            isCollapsed: hint == null,
            contentPadding: const EdgeInsets.all(12),
            hintText: hint ?? "${lang.search}...".firstLetterCap(),
            hintStyle: textStyle.copyWith(color: Colors.grey.shade700),
            border: outlineInputBorder,
            focusedBorder: outlineInputBorder,
            enabledBorder: outlineInputBorder.copyWith(
              borderSide: const BorderSide(
                color: Colors.transparent,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
