import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class RTLLayout extends StatelessWidget {
  final Widget child;
  const RTLLayout({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Consumer<LangPro>(
      child: child,
      builder: (_, v, w) {
        return Directionality(
          textDirection: v.direction,
          child: w!,
        );
      },
    );
  }
}
