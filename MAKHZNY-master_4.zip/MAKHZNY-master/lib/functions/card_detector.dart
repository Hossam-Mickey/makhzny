// ignore_for_file: constant_identifier_names

enum CardType {
  Visa,
  Mastercard,
  AmericanExpress,
  Discover,
  Unknown,
}

class CreditCardDetector {
  static CardType detect(String cardNumber) {
    if (cardNumber.startsWith('4')) {
      return CardType.Visa;
    } else if (RegExp(r'^5[1-5]').hasMatch(cardNumber)) {
      return CardType.Mastercard;
    } else if (RegExp(r'^3[47]').hasMatch(cardNumber)) {
      return CardType.AmericanExpress;
    } else if (RegExp(r'^6(?:011|5)').hasMatch(cardNumber)) {
      return CardType.Discover;
    } else {
      return CardType.Unknown;
    }
  }
}

//   String cardNumber = '1234567890123456'; // Example card number
//   CardType cardType = CreditCardDetector.detectCardType(cardNumber);

//   switch (cardType) {
//     case CardType.Visa:
//       print('Visa card detected');
//       break;
//     case CardType.Mastercard:
//       print('Mastercard detected');
//       break;
//     case CardType.AmericanExpress:
//       print('American Express card detected');
//       break;
//     case CardType.Discover:
//       print('Discover card detected');
//       break;
//     case CardType.Unknown:
//       print('Unknown card type');
//       break;
//   }
