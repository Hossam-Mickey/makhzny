import 'package:client_1/provider/carousel_pro/carousel_pro.dart';
import 'package:client_1/provider/current_route_pro/current_route_pro.dart';
import 'package:client_1/provider/dammam_units_pro/dammam_units_pro.dart';
import 'package:client_1/provider/document_pro/document_pro.dart';
import 'package:client_1/provider/download_pro.dart';
import 'package:client_1/provider/invoice_pro/invoice_pro.dart';
import 'package:client_1/provider/jeddah_units_pro/jeddah_units_pro.dart';
import 'package:client_1/provider/my_units_pro/my_units_pro.dart';
import 'package:client_1/provider/riyadh_units_pro/riyadh_units_pro.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:client_1/provider/user_pro/user_pro.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SplashInit {
  static Future<void> init(BuildContext context) async {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      context.read<ThemePro>().init();
      context.read<CurrentRoutePro>().listern();
      context.read<DownloadPro>().loadFromLocal();
      context.read<JeddahUnitsPro>().getProduct();
      context.read<RiyadhUnitsPro>().getProduct();
      context.read<DammamUnitsPro>().getProduct();

      // context.read<NewUnitsPro>().getProduct();
      context.read<CarouselPro>().getCarousel();
      await context.read<UserPro>().loadUserLocal();
      if (!context.mounted) return;
      context.read<UserPro>().loadUser();
      context.read<MyUnitsPro>().getUnits();
      context.read<InvoicePro>().getInvoices();
      context.read<DocumentPro>().getUploaded();

      // context.read<CartPro>().loadFromLocal();
    });
  }
}
