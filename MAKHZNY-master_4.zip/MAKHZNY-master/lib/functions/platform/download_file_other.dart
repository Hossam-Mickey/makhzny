class DownloadFile {
  static download(String url, String name) async {}
}
