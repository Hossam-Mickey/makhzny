import 'package:client_1/provider/download_pro.dart';
import 'package:client_1/route.dart';
import 'package:dio/dio.dart';
import 'package:provider/provider.dart';
// ignore: avoid_web_libraries_in_flutter
import 'dart:html';

class DownloadFile {
  static download(String url, String name) async {
    var context = navigatorKey.currentContext!;

    var dpro = context.read<DownloadPro>();
    var ext = await dpro.getExt(Dio(), url);
    AnchorElement(href: url)
      ..setAttribute("download", "$name.$ext")
      ..click();
  }
}
