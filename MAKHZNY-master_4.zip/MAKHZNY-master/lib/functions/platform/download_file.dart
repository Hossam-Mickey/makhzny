// document_child.dart
export 'download_file_other.dart'
    if (dart.library.html) 'download_file_web.dart';
