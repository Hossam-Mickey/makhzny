// ignore_for_file: use_build_context_synchronously

import 'package:client_1/route.dart';
import 'package:client_1/widgets/app_button.dart';
import 'package:client_1/widgets/app_image.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../constants/colors.dart';
import '../constants/sized_box.dart';
import '../widgets/app_text.dart';

class ConnectivityCheck {
  final Connectivity _connectivity = Connectivity();

  Stream getConnectivityStream() {
    return _connectivity.onConnectivityChanged.asBroadcastStream();
  }

  Future<bool> getCurrentState([bool dialogOff = false]) async {
    var res = await _connectivity.checkConnectivity();
    if (res.contains(ConnectivityResult.bluetooth) ||
        res.contains(ConnectivityResult.none)) {
      dialogOff ? null : _dialog();
      return false;
    }

    return true;
  }

  _dialog() {
    showDialog(
      context: navigatorKey.currentContext!,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        child: const _NetworkDialog()
            .animate()
            .shimmer(duration: 500.ms)
            .fade(duration: 800.ms),
      ),
    );
  }
}

class _NetworkDialog extends StatelessWidget {
  const _NetworkDialog();

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 500, maxHeight: 1500),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          sizedBoxH20,
          const AppImage(
            image: "assets/image/globe.png",
            height: 80,
            width: 80,
            color: MyColor.grey,
          ),
          sizedBoxH10,
          AppText(
            "Ooops!",
            fontSize: 20.spMax,
            fontWeight: FontWeight.w900,
          ),
          AppText(
            "It seems that something wrong with your internet connection. Please connect to it & try again.",
            fontSize: 14.spMax,
            padding: const EdgeInsets.symmetric(horizontal: 15),
            maxLines: 8,
            textAlign: TextAlign.center,
            fontWeight: FontWeight.w400,
            color: Colors.grey.shade600,
          ),
          sizedBoxH20,
          AppButton(
            width: 100,
            height: 40,
            borderRadius: BorderRadius.circular(8),
            text: "Cancel",
            fontWeight: FontWeight.bold,
            fontSize: 14,
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          sizedBoxH20,
        ],
      ),
    );
  }
}
