import 'package:uuid/uuid.dart';

String uniqueId() {
  var uuid = const Uuid();
  String uniqueId = uuid.v4();
  return uniqueId;
}
