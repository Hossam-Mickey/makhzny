import 'package:client_1/model/user_show_model/user_show_model.dart';
import 'package:client_1/provider/theme_pro/theme_pro.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../provider/lang_pro/lang_pro.dart';

class Preference {
  static Future setTheme(ThemeType val) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setInt("theme", val.index);
  }

  static Future<ThemeType> getTheme() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      var res = prefs.getInt("theme");
      return res != null ? ThemeType.values[res] : ThemeType.light;
    } catch (e) {
      return ThemeType.light;
    }
  }

  static Future setLang(LangType val) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setInt("Lang", val.index);
  }

  static Future<LangType> getLang() async {
    final prefs = await SharedPreferences.getInstance();
    var res = prefs.getInt("Lang");
    return res != null ? LangType.values[res] : LangType.eng;
  }

  static Future setLastAdShown(DateTime val) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString("ad_shown", val.toIso8601String());
  }

  static Future<DateTime> getLastAdShown() async {
    final prefs = await SharedPreferences.getInstance();
    var res = prefs.getString("ad_shown");
    return res != null ? DateTime.parse(res) : DateTime.now().subtract(7.hours);
  }

  // static Future setUser(UserModel val) async {
  //   final prefs = await SharedPreferences.getInstance();
  //   prefs.setString("user", val.toJson().toString());
  // }

  // static Future<UserModel?> getUser() async {
  //   final prefs = await SharedPreferences.getInstance();
  //   var res = prefs.getString("user");
  //   var json = jsonDecode(res ?? "");
  //   return res != null ? UserModel.fromJson(json) : null;
  // }

  static Future setUser(int? val) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setInt("user_", val ?? 0);
  }

  static Future<int?> getUser() async {
    final prefs = await SharedPreferences.getInstance();
    var res = prefs.getInt("user_");
    if (res == 0) return null;
    return res;
  }

  static Future setUserShow(UserShowModel? val) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString("user_show_1", val == null ? "" : val.toJson().toString());
  }

  static Future<UserShowModel?> getUserShow() async {
    final prefs = await SharedPreferences.getInstance();
    var res = prefs.getString("user_show_1");
    if (res == null || res.isEmpty) return null;
    res = res.substring(1, res.length - 1);

    // Split the string by commas
    List<String> pairs = res.split(', ');

    // Initialize an empty map
    Map<String, String> result = {};

    for (String pair in pairs) {
      List<String> keyValue = pair.split(': ');
      result[keyValue[0].trim()] = keyValue[1].trim();
    }

    return UserShowModel.fromJson(result);
  }
}
