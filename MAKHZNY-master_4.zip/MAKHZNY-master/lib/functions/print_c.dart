// ignore_for_file: avoid_print

import 'dart:developer';

import 'package:flutter/foundation.dart';

enum PColor {
  red,
  yellow,
  green,
  blue,
  white,
  black,
  cyan,
  magenta,
}

printC(dynamic data, {String from = '', PColor color = PColor.blue}) {
  String fromMes = "${_colorCode(color)}FROM :: $from\x1B[0m";
  String mes = "${_colorCode(color)}${data.toString()}\x1B[0m";
  if (!kDebugMode) return;
  var f = from.isNotEmpty ? "$fromMes :: " : "";
  log("$f$mes");
}

String _colorCode(PColor color) {
  switch (color) {
    case PColor.black:
      return "\x1B[30m";
    case PColor.red:
      return "\x1B[31m";
    case PColor.green:
      return "\x1B[32m";
    case PColor.yellow:
      return "\x1B[33m";
    case PColor.blue:
      return "\x1B[34m";
    case PColor.magenta:
      return "\x1B[35m";
    case PColor.cyan:
      return "\x1B[36m";
    case PColor.white:
      return "\x1B[37m";
    default:
      return "\x1B[37m";
  }
}
