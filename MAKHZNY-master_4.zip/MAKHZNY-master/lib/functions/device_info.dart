// import 'dart:io';

// import 'package:android_id/android_id.dart';
// import 'package:device_info_plus/device_info_plus.dart';
// import 'package:earnchat/firebase/firebase_notification.dart';
// import 'package:earnchat/get_it.dart';

// import '../models/user_login_info_model/user_login_info_model.dart';

// class DeviceInfo {
//   Future<UserLoginInfo> getInfo() async {
//     DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
//     String name;
//     String id;
//     String fcm = await getIt<FirebaseNotification>().getFCM();
//     late DeviceType type;
//     if (Platform.isAndroid) {
//       var android = await deviceInfo.androidInfo;
//       name = "${android.manufacturer} ${android.brand} ${android.model}";
//       id = await const AndroidId().getId() ?? android.id;
//       type = DeviceType.android;
//     } else {
//       var ios = await deviceInfo.iosInfo;
//       name = ios.utsname.machine;
//       id = ios.identifierForVendor ?? "";
//       type = DeviceType.ios;
//     }
//     return UserLoginInfo(
//       type: type,
//       device_id: id,
//       device_name: name,
//       fcm: fcm,
//       login_date: DateTime.now(),
//     );
//   }
// }
