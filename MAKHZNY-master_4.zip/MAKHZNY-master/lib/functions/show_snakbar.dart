import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../constants/sized_box.dart';
import '../main.dart';
import '../provider/theme_pro/theme_pro.dart';
import '../widgets/app_text.dart';
import 'package:provider/provider.dart';

class MySnackBar {
  static void show({
    required String title,
    Widget? child,
    Duration? duration,
  }) {
    var theme = messangerKey.currentContext!.read<ThemePro>();
    var bool = theme.theme.brightness == Brightness.light;
    var color = Colors.white;
    var color2 = bool ? Colors.black : Colors.grey.shade900;

    messangerKey.currentState?.showSnackBar(
      SnackBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        duration: duration ?? 5000.ms,
        behavior: SnackBarBehavior.floating,
        content: Column(
          children: [
            Container(
              constraints: const BoxConstraints(minHeight: 45),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color2,
                borderRadius: BorderRadius.circular(8),
              ),
              child: child ??
                  Row(
                    children: [
                      sizedBoxH5,
                      sizedBoxW10,
                      Flexible(
                        child: AppText(
                          title,
                          maxLines: 4,
                          color: color,
                          fontWeight: FontWeight.w500,
                          fontSize: 15,
                        ),
                      ),
                      sizedBoxW10,
                      sizedBoxH5,
                    ],
                  )
                      .animate()
                      .fade(duration: 0.5.seconds)
                      .moveY(duration: 0.5.seconds, begin: -100),
            ),
          ],
        ),
      ),
    );
  }
}
