import 'package:flutter/material.dart';
import '../constants/colors.dart';
import '../route.dart';
import '../widgets/app_text.dart';

showAlertdialogMessage(
  String? title,
  String? content,
  // List<Widget> actions,
  List<Widget> Function(BuildContext context) action, {
  Color titleColor = Colors.black,
  Color contentColor = MyColor.grey,
  double titleFontSize = 16,
  double contentFontSize = 14,
  Widget Function(BuildContext context)? child,
}) {
  showGeneralDialog(
    context: navigatorKey.currentContext!,
    // barrierDismissible: false,
    // barrierColor: Colors.transparent,
    pageBuilder: (context, animation, secondaryAnimation) => const SizedBox(),
    transitionDuration: const Duration(milliseconds: 200),
    transitionBuilder: (_, a1, a2, widget) {
      var textTheme = Theme.of(_).textTheme;

      return PopScope(
        // canPop: false,
        child: Transform.scale(
          scale: a1.value,
          child: Opacity(
            opacity: a1.value,
            child: child != null
                ? child(_)
                : AlertDialog(
                    backgroundColor: Theme.of(_).brightness == Brightness.dark
                        ? Colors.black
                        : Colors.white,
                    shadowColor: Colors.grey.withOpacity(0.3),
                    // surfaceTintColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 15,
                    alignment: Alignment.center,
                    title: title == null
                        ? null
                        : AppText(
                            title,
                            // textAlign: TextAlign.center,
                            color: textTheme.titleMedium?.color,
                            fontWeight: FontWeight.bold,
                            fontSize: titleFontSize,
                          ),
                    content: content == null
                        ? null
                        : AppText(
                            content,
                            color:
                                textTheme.titleMedium!.color?.withOpacity(0.7),
                            fontSize: contentFontSize,
                            fontWeight: FontWeight.w500,
                            // textAlign: TextAlign.center,
                            maxLines: 10,
                          ),
                    // actionsAlignment: MainAxisAlignment.center,
                    actionsPadding: const EdgeInsets.only(bottom: 15),
                    actions: action(_),
                  ),
          ),
        ),
      );
    },
  );
}
