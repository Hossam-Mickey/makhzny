import 'package:client_1/provider/lang_pro/lang_pro.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:glassmorphism/glassmorphism.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../constants/colors.dart';
import '../route.dart';
import '../widgets/app_button.dart';
import '../widgets/app_text.dart';

Future<dynamic> blurBottomSheet({
  required String title,
  String? continueText,
  required Function(BuildContext) onTap,
}) {
  return showModalBottomSheet(
    context: navigatorKey.currentContext!,
    useSafeArea: false,
    isScrollControlled: true,
    isDismissible: false,
    enableDrag: false,
    backgroundColor: Colors.transparent,
    builder: (_) {
      return AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle(
          systemNavigationBarColor: Theme.of(_).scaffoldBackgroundColor,
        ),
        child: DeleteDialog(
          dialogContext: _,
          continueText: continueText,
          title: title,
          onTap: () => onTap(_),
        ),
      );
    },
  );
}

class DeleteDialog extends StatelessWidget {
  final BuildContext dialogContext;
  final String title;
  final String? continueText;
  final Function onTap;
  const DeleteDialog({
    super.key,
    required this.dialogContext,
    required this.title,
    this.continueText,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    var lang = context.read<LangPro>().lang;

    return Stack(
      children: [
        const BlurDialogBg(),
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: 400.h,
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 30),
            decoration: BoxDecoration(
              color: Theme.of(context).scaffoldBackgroundColor,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  SizedBox(height: 100.h),
                  AppText(
                    title,
                    fontSize: 16.spMin,
                    maxLines: 3,
                    fontWeight: FontWeight.w400,
                  ),
                  SizedBox(height: 40.h),
                  AppButton(
                    text: continueText ?? lang.continue_text,
                    width: 260.w,
                    borderRadius: BorderRadius.circular(22.r),
                    fontWeight: FontWeight.w600,
                    fontSize: 14.spMin,
                    onPressed: () => onTap(),
                  ),
                  SizedBox(height: 20.h),
                  AppButton(
                    text: lang.cancel,
                    width: 260.w,
                    buttonColor: Colors.transparent,
                    border: Border.all(
                      color: MyColor.primary,
                      width: 1.5,
                    ),
                    fontColor: MyColor.primary,
                    borderRadius: BorderRadius.circular(22.r),
                    fontWeight: FontWeight.w600,
                    fontSize: 14.spMin,
                    onPressed: () => dialogContext.pop(),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class BlurDialogBg extends StatelessWidget {
  const BlurDialogBg({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    var color = Theme.of(context).brightness == Brightness.dark
        ? Colors.grey.shade600
        : Colors.white;
    return GlassmorphicContainer(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      borderRadius: 0,
      blur: 5,
      alignment: Alignment.bottomCenter,
      border: 0,
      linearGradient: LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          color.withOpacity(0.1),
          color.withOpacity(0.1),
        ],
      ),
      borderGradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          color.withOpacity(0.5),
          color.withOpacity(0.5),
        ],
      ),
    ).animate().fade(duration: 1000.ms);
  }
}
