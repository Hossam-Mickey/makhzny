import 'package:client_1/functions/print_c.dart';
import 'package:flutter/material.dart';

class AppLifecycleObserver with WidgetsBindingObserver {
  AppLifecycleObserver() {
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  Future<void> didChangeAppLifecycleState(AppLifecycleState state) async {
    super.didChangeAppLifecycleState(state);
    printC(state, color: PColor.green);
  }

  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
  }
}
