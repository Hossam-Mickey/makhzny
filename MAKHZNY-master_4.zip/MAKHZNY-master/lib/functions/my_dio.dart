import 'package:client_1/constants/api.dart';
import 'package:dio/dio.dart';

class MyDio {
  late Dio dio;
  MyDio() {
    dio = Dio(BaseOptions(baseUrl: API.baseUrl));
  }
}
