package com.makhzny.odoo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
