package com.makhzny.makhzny

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
